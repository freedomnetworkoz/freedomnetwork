# Security policy

## Reporting a vulnerability

Do not publish an exploitable vulnerability, private key, credential, mailbox, private message or user database in a public issue.

Until a dedicated security mailbox is announced, open a minimal GitHub issue stating that you have a security report and request a private contact channel. Include no exploit details in that issue.

## Trust boundary

Freedom Node does not contain the Authority private signing key, unrestricted administration credentials, mailbox database, user identity, AppData or WebView profile. Official names are accepted only when records verify against the packaged public trust root. A locally modified client cannot mint records accepted by unmodified clients without the Authority signing key.

The public bootstrap JSON is an availability aid, not a signing authority. A fetched list is accepted only over validated HTTPS, within strict size/schema limits, without redirects, and only while it retains a PeerID pinned in the packaged Node configuration.

Freedom is not anonymous. Direct peers may see one another's IP addresses, relays can observe metadata, and the current network does not provide traffic-analysis resistance or mature Sybil protection.

PHP restrictions are defence in depth rather than a hostile-code sandbox. Host only code you trust.
