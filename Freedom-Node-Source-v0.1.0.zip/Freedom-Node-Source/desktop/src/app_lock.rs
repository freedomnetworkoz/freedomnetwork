use std::{
    fs, io,
    path::{Path, PathBuf},
    sync::{Arc, Mutex},
    time::{Duration, Instant},
};

use anyhow::{Context, Result};
use serde::{Deserialize, Serialize};

const PASSWORD_MIN_BYTES: usize = 8;
const PASSWORD_MAX_BYTES: usize = 72;
const MAX_FAILED_ATTEMPTS: u32 = 5;
const FAILED_ATTEMPT_DELAY: Duration = Duration::from_secs(30);
pub const DEFAULT_IDLE_TIMEOUT: Duration = Duration::from_secs(30 * 60);

#[derive(Clone)]
pub struct AppLock {
    config_path: Arc<PathBuf>,
    idle_timeout: Duration,
    inner: Arc<Mutex<AppLockInner>>,
}

struct AppLockInner {
    password_hash: Option<String>,
    locked: bool,
    last_activity: Instant,
    failed_attempts: u32,
    blocked_until: Option<Instant>,
}

#[derive(Clone, Copy, Debug, Serialize, PartialEq, Eq)]
pub struct AppLockSnapshot {
    pub configured: bool,
    pub locked: bool,
    pub timeout_minutes: u64,
}

#[derive(Deserialize, Serialize)]
struct AppLockConfig {
    version: u16,
    password_hash: String,
}

impl AppLock {
    pub fn load(data_dir: &Path) -> Result<Self> {
        Self::load_with_timeout(data_dir, DEFAULT_IDLE_TIMEOUT)
    }

    fn load_with_timeout(data_dir: &Path, idle_timeout: Duration) -> Result<Self> {
        let config_path = data_dir.join("app-lock.json");
        let password_hash = if config_path.exists() {
            let config = serde_json::from_slice::<AppLockConfig>(
                &fs::read(&config_path).context("could not read app-lock configuration")?,
            )
            .context("app-lock configuration is invalid")?;
            if config.version != 1 || bcrypt::verify("", &config.password_hash).is_err() {
                anyhow::bail!("app-lock configuration is invalid");
            }
            Some(config.password_hash)
        } else {
            None
        };
        let locked = password_hash.is_some();
        Ok(Self {
            config_path: Arc::new(config_path),
            idle_timeout,
            inner: Arc::new(Mutex::new(AppLockInner {
                password_hash,
                locked,
                last_activity: Instant::now(),
                failed_attempts: 0,
                blocked_until: None,
            })),
        })
    }

    pub fn snapshot(&self) -> AppLockSnapshot {
        let mut inner = self.inner.lock().expect("app-lock mutex poisoned");
        self.apply_idle_timeout(&mut inner);
        self.snapshot_for(&inner)
    }

    pub fn is_locked(&self) -> bool {
        self.snapshot().locked
    }

    pub fn note_activity(&self) -> AppLockSnapshot {
        let mut inner = self.inner.lock().expect("app-lock mutex poisoned");
        self.apply_idle_timeout(&mut inner);
        if !inner.locked {
            inner.last_activity = Instant::now();
        }
        self.snapshot_for(&inner)
    }

    pub fn lock(&self) -> AppLockSnapshot {
        let mut inner = self.inner.lock().expect("app-lock mutex poisoned");
        if inner.password_hash.is_some() {
            inner.locked = true;
        }
        self.snapshot_for(&inner)
    }

    pub fn unlock(&self, password: &str) -> Result<AppLockSnapshot, String> {
        let hash = {
            let inner = self.inner.lock().map_err(|_| "app lock failed")?;
            if inner
                .blocked_until
                .is_some_and(|deadline| deadline > Instant::now())
            {
                return Err("Too many failed attempts. Wait 30 seconds and try again.".into());
            }
            inner
                .password_hash
                .clone()
                .ok_or_else(|| "No app password is configured".to_string())?
        };
        let accepted = bcrypt::verify(password, &hash).unwrap_or(false);
        let mut inner = self.inner.lock().map_err(|_| "app lock failed")?;
        if !accepted {
            inner.failed_attempts = inner.failed_attempts.saturating_add(1);
            if inner.failed_attempts >= MAX_FAILED_ATTEMPTS {
                inner.failed_attempts = 0;
                inner.blocked_until = Some(Instant::now() + FAILED_ATTEMPT_DELAY);
            }
            return Err("Incorrect app password".into());
        }
        inner.failed_attempts = 0;
        inner.blocked_until = None;
        inner.locked = false;
        inner.last_activity = Instant::now();
        Ok(self.snapshot_for(&inner))
    }

    pub fn set_password(
        &self,
        current_password: Option<&str>,
        new_password: &str,
    ) -> Result<AppLockSnapshot, String> {
        validate_password(new_password)?;
        let already_configured = self
            .inner
            .lock()
            .map_err(|_| "app lock failed")?
            .password_hash
            .is_some();
        if already_configured {
            self.unlock(current_password.unwrap_or_default())?;
        }
        let password_hash = bcrypt::hash(new_password, 12)
            .map_err(|_| "Could not protect the app password".to_string())?;
        write_config(&self.config_path, &password_hash).map_err(|error| error.to_string())?;
        let mut inner = self.inner.lock().map_err(|_| "app lock failed")?;
        inner.password_hash = Some(password_hash);
        inner.locked = false;
        inner.last_activity = Instant::now();
        inner.failed_attempts = 0;
        inner.blocked_until = None;
        Ok(self.snapshot_for(&inner))
    }

    pub fn remove_password(&self, current_password: &str) -> Result<AppLockSnapshot, String> {
        self.unlock(current_password)?;
        if self.config_path.exists() {
            fs::remove_file(self.config_path.as_ref())
                .map_err(|error| format!("Could not remove app password: {error}"))?;
        }
        let mut inner = self.inner.lock().map_err(|_| "app lock failed")?;
        inner.password_hash = None;
        inner.locked = false;
        inner.last_activity = Instant::now();
        Ok(self.snapshot_for(&inner))
    }

    fn apply_idle_timeout(&self, inner: &mut AppLockInner) {
        if inner.password_hash.is_some()
            && !inner.locked
            && inner.last_activity.elapsed() >= self.idle_timeout
        {
            inner.locked = true;
        }
    }

    fn snapshot_for(&self, inner: &AppLockInner) -> AppLockSnapshot {
        AppLockSnapshot {
            configured: inner.password_hash.is_some(),
            locked: inner.locked,
            timeout_minutes: self.idle_timeout.as_secs() / 60,
        }
    }
}

fn validate_password(password: &str) -> Result<(), String> {
    let length = password.len();
    if !(PASSWORD_MIN_BYTES..=PASSWORD_MAX_BYTES).contains(&length) {
        return Err("App password must be between 8 and 72 bytes".into());
    }
    Ok(())
}

fn write_config(path: &Path, password_hash: &str) -> io::Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let temporary = path.with_extension("tmp");
    let bytes = serde_json::to_vec_pretty(&AppLockConfig {
        version: 1,
        password_hash: password_hash.to_owned(),
    })
    .map_err(io::Error::other)?;
    fs::write(&temporary, bytes)?;
    if path.exists() {
        fs::remove_file(path)?;
    }
    fs::rename(temporary, path)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn password_is_hashed_persisted_and_required_after_restart() {
        let directory = tempfile::tempdir().unwrap();
        let lock = AppLock::load(directory.path()).unwrap();
        assert_eq!(
            lock.snapshot(),
            AppLockSnapshot {
                configured: false,
                locked: false,
                timeout_minutes: 30,
            }
        );
        lock.set_password(None, "correct horse battery staple")
            .unwrap();
        let stored = fs::read_to_string(directory.path().join("app-lock.json")).unwrap();
        assert!(!stored.contains("correct horse battery staple"));
        lock.lock();
        assert!(lock.unlock("wrong password").is_err());
        assert!(lock.snapshot().locked);
        lock.unlock("correct horse battery staple").unwrap();
        assert!(!lock.snapshot().locked);

        let restarted = AppLock::load(directory.path()).unwrap();
        assert!(restarted.snapshot().locked);
        restarted.unlock("correct horse battery staple").unwrap();
        restarted
            .remove_password("correct horse battery staple")
            .unwrap();
        assert!(!directory.path().join("app-lock.json").exists());
    }

    #[test]
    fn inactivity_locks_a_configured_app() {
        let directory = tempfile::tempdir().unwrap();
        let lock = AppLock::load_with_timeout(directory.path(), Duration::ZERO).unwrap();
        lock.set_password(None, "a-valid-password").unwrap();
        assert!(lock.snapshot().locked);
    }
}
