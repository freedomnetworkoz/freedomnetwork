#![cfg_attr(all(windows, not(debug_assertions)), windows_subsystem = "windows")]

mod app_lock;
mod gateway;
mod shell;

use std::{
    borrow::Cow,
    io::Write,
    path::{Path, PathBuf},
    thread,
};

use anyhow::{Context, Result, anyhow};
use directories::ProjectDirs;
use freedom_core::{
    ApplicationRole, InternetConfig, NodeConfig, default_manifest_path, parse_manual_peer,
    spawn_node,
};
#[cfg(windows)]
use serde::Deserialize;
use tracing_subscriber::EnvFilter;

#[derive(Clone, Debug)]
struct Arguments {
    headless: bool,
    display_name: Option<String>,
    data_dir: PathBuf,
    htdocs_dir: PathBuf,
    php_cgi: PathBuf,
    enable_mdns: bool,
    listen_port: u16,
    gateway_port: u16,
    sites: Vec<(String, PathBuf)>,
    connect: Vec<String>,
    role: ApplicationRole,
    authority_manifest: Option<PathBuf>,
    trusted_authority_signer: Option<String>,
    internet: InternetConfig,
    initial_address: String,
}

fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            EnvFilter::try_from_default_env().unwrap_or_else(|_| "freedom=info".into()),
        )
        .with_target(false)
        .compact()
        .init();
    let arguments = parse_arguments()?;
    if arguments.headless {
        run_headless(arguments)
    } else {
        run_desktop(arguments)
    }
}

fn parse_arguments() -> Result<Arguments> {
    let default_data = ProjectDirs::from("network", "Freedom", "Freedom")
        .map(|dirs| dirs.data_local_dir().to_path_buf())
        .unwrap_or_else(|| PathBuf::from("data"));
    let executable_directory = std::env::current_exe()
        .ok()
        .and_then(|path| path.parent().map(Path::to_path_buf));
    let default_htdocs = executable_directory
        .as_ref()
        .map(|directory| directory.join("htdocs"))
        .unwrap_or_else(|| default_data.join("htdocs"));
    let default_php_cgi = executable_directory
        .as_ref()
        .map(|directory| directory.join("runtime").join("php").join("php-cgi.exe"))
        .unwrap_or_else(|| PathBuf::from("runtime/php/php-cgi.exe"));
    let (packaged_manifest, packaged_signer) = executable_directory
        .as_deref()
        .map(packaged_authority_config)
        .unwrap_or_default();
    let internet = executable_directory
        .as_deref()
        .map(|directory| InternetConfig::load(&directory.join("config").join("internet.json")))
        .transpose()?
        .unwrap_or_default();
    let mut parsed = Arguments {
        headless: false,
        display_name: None,
        data_dir: default_data,
        htdocs_dir: default_htdocs,
        php_cgi: default_php_cgi,
        enable_mdns: true,
        listen_port: freedom_core::DEFAULT_FREEDOM_PORT,
        gateway_port: 8787,
        sites: Vec::new(),
        connect: Vec::new(),
        role: if cfg!(feature = "authority") {
            ApplicationRole::Authority
        } else {
            ApplicationRole::Node
        },
        authority_manifest: packaged_manifest,
        trusted_authority_signer: packaged_signer,
        internet,
        initial_address: "freedom://freedom.net/".into(),
    };
    let mut data_dir_was_explicit = false;
    let mut htdocs_dir_was_explicit = false;
    let mut arguments = std::env::args().skip(1);
    while let Some(argument) = arguments.next() {
        match argument.as_str() {
            "--headless" => parsed.headless = true,
            "--node" => {
                parsed.role = ApplicationRole::Node;
                parsed.internet.infrastructure = false;
            }
            "--authority" => {
                if cfg!(feature = "authority") {
                    parsed.role = ApplicationRole::Authority;
                } else {
                    return Err(anyhow!(
                        "this Freedom executable is the public Node edition and has no authority capabilities"
                    ));
                }
            }
            "--name" => parsed.display_name = Some(next_value(&mut arguments, "--name")?),
            "--data-dir" => {
                parsed.data_dir = next_value(&mut arguments, "--data-dir")?.into();
                data_dir_was_explicit = true;
            }
            "--htdocs-dir" => {
                parsed.htdocs_dir = next_value(&mut arguments, "--htdocs-dir")?.into();
                htdocs_dir_was_explicit = true;
            }
            "--php-cgi" => parsed.php_cgi = next_value(&mut arguments, "--php-cgi")?.into(),
            "--authority-manifest" => {
                parsed.authority_manifest =
                    Some(next_value(&mut arguments, "--authority-manifest")?.into())
            }
            "--authority-signer" => {
                parsed.trusted_authority_signer =
                    Some(next_value(&mut arguments, "--authority-signer")?)
            }
            "--open" => {
                parsed.initial_address =
                    normalize_launch_address(&next_value(&mut arguments, "--open")?)?
            }
            "--no-mdns" => parsed.enable_mdns = false,
            "--no-upnp" => parsed.internet.enable_upnp = false,
            "--bootstrap" => parsed
                .internet
                .add_bootstrap(&next_value(&mut arguments, "--bootstrap")?)?,
            "--relay" => parsed
                .internet
                .add_relay(&next_value(&mut arguments, "--relay")?)?,
            "--internet-service" => {
                if cfg!(feature = "authority") {
                    parsed.internet.infrastructure = true;
                } else {
                    return Err(anyhow!(
                        "Internet infrastructure mode is available only in the Freedom Authority edition"
                    ));
                }
            }
            "--listen-port" => {
                parsed.listen_port = next_value(&mut arguments, "--listen-port")?
                    .parse()
                    .context("invalid --listen-port")?
            }
            "--gateway-port" => {
                parsed.gateway_port = next_value(&mut arguments, "--gateway-port")?
                    .parse()
                    .context("invalid --gateway-port")?
            }
            "--connect" => parsed
                .connect
                .push(next_value(&mut arguments, "--connect")?),
            "--site" => {
                let value = next_value(&mut arguments, "--site")?;
                let (site_id, root) = value
                    .split_once('=')
                    .ok_or_else(|| anyhow!("--site must be site-id=directory"))?;
                parsed.sites.push((site_id.to_owned(), root.into()));
            }
            "--help" | "-h" => {
                println!(
                    "Freedom\n\n  [freedom://address | free://address]\n  --open <freedom-address>\n  --headless\n  --name <display-name>\n  --node\n  --authority (Authority edition only)\n  --authority-manifest <signed-json>\n  --authority-signer <PeerID>\n  --data-dir <directory>\n  --htdocs-dir <directory>\n  --php-cgi <php-cgi.exe>\n  --no-mdns\n  --no-upnp\n  --listen-port <port>\n  --gateway-port <port>\n  --bootstrap <tcp-or-quic-multiaddress/p2p/PeerID>\n  --relay <tcp-or-quic-multiaddress/p2p/PeerID>\n  --internet-service (Authority edition only)\n  --connect <address>\n  --site <site-id=directory>"
                );
                std::process::exit(0);
            }
            _ if is_freedom_address(&argument) => {
                parsed.initial_address = normalize_launch_address(&argument)?
            }
            _ => return Err(anyhow!("unknown argument: {argument}")),
        }
    }
    if data_dir_was_explicit && !htdocs_dir_was_explicit {
        parsed.htdocs_dir = parsed.data_dir.join("htdocs");
    }
    Ok(parsed)
}

fn packaged_authority_config(executable_directory: &Path) -> (Option<PathBuf>, Option<String>) {
    let manifest = default_manifest_path(executable_directory);
    let trust_path = executable_directory
        .join("config")
        .join("authority-trust-root.json");
    if !manifest.is_file() || !trust_path.is_file() {
        return (None, None);
    }
    let signer = std::fs::read(&trust_path)
        .ok()
        .and_then(|bytes| serde_json::from_slice::<serde_json::Value>(&bytes).ok())
        .and_then(|value| value.get("signer_peer_id")?.as_str().map(str::to_owned));
    match signer {
        Some(signer) => (Some(manifest), Some(signer)),
        None => (None, None),
    }
}

fn next_value(arguments: &mut impl Iterator<Item = String>, flag: &str) -> Result<String> {
    arguments
        .next()
        .ok_or_else(|| anyhow!("{flag} requires a value"))
}

fn is_freedom_address(value: &str) -> bool {
    value
        .get(..10)
        .is_some_and(|scheme| scheme.eq_ignore_ascii_case("freedom://"))
        || value
            .get(..7)
            .is_some_and(|scheme| scheme.eq_ignore_ascii_case("free://"))
}

fn normalize_launch_address(value: &str) -> Result<String> {
    let value = value.trim();
    if value
        .get(..10)
        .is_some_and(|scheme| scheme.eq_ignore_ascii_case("freedom://"))
    {
        return Ok(format!("freedom://{}", &value[10..]));
    }
    if value
        .get(..7)
        .is_some_and(|scheme| scheme.eq_ignore_ascii_case("free://"))
    {
        return Ok(format!("freedom://{}", &value[7..]));
    }
    Err(anyhow!("address must begin with freedom:// or free://"))
}

fn run_headless(arguments: Arguments) -> Result<()> {
    let display_name = arguments
        .display_name
        .clone()
        .or_else(|| existing_name(&arguments.data_dir))
        .or_else(|| (arguments.role == ApplicationRole::Authority).then(|| "UncleSam".to_owned()))
        .ok_or_else(|| anyhow!("first headless run requires --name <display-name>"))?;
    let runtime = tokio::runtime::Runtime::new()?;
    runtime.block_on(async move {
        let (node, info) = start_services(&arguments, display_name).await?;
        let snapshot = node.snapshot().await;
        println!(
            "Freedom node: {} · {}",
            snapshot.display_name, snapshot.short_id
        );
        println!("PeerId: {}", snapshot.peer_id);
        println!("Fingerprint: {}", snapshot.fingerprint);
        println!("Public gateway: http://{}/", info.public_address);
        println!("Press Ctrl+C to stop.");
        tokio::signal::ctrl_c().await?;
        node.shutdown().await?;
        Ok(())
    })
}

async fn start_services(
    arguments: &Arguments,
    display_name: String,
) -> Result<(freedom_core::NodeHandle, gateway::GatewayInfo)> {
    let node = spawn_node(NodeConfig {
        data_dir: arguments.data_dir.clone(),
        htdocs_dir: Some(arguments.htdocs_dir.clone()),
        php_cgi: Some(arguments.php_cgi.clone()),
        enable_mdns: arguments.enable_mdns,
        display_name,
        listen_port: arguments.listen_port,
        role: arguments.role,
        authority_manifest: arguments.authority_manifest.clone(),
        trusted_authority_signer: arguments.trusted_authority_signer.clone(),
        internet: arguments.internet.clone(),
    })
    .await?;
    for (site_id, root) in &arguments.sites {
        node.add_site(site_id, site_id, root).await?;
    }
    for address in &arguments.connect {
        node.dial(parse_manual_peer(address, None)?).await?;
    }
    let gateway = gateway::start_gateways(
        node.clone(),
        arguments.gateway_port,
        Some(&arguments.initial_address),
        &arguments.data_dir,
    )
    .await?;
    Ok((node, gateway))
}

fn existing_name(data_dir: &std::path::Path) -> Option<String> {
    let bytes = std::fs::read(data_dir.join("profile.json")).ok()?;
    let value: serde_json::Value = serde_json::from_slice(&bytes).ok()?;
    value.get("display_name")?.as_str().map(str::to_owned)
}

#[cfg(windows)]
fn run_desktop(arguments: Arguments) -> Result<()> {
    use winit::event_loop::EventLoop;

    reset_startup_log(&arguments.data_dir);
    append_startup_log(&arguments.data_dir, "desktop launch requested");
    if let Err(error) = register_protocols_for_current_executable() {
        append_startup_log(
            &arguments.data_dir,
            &format!("could not refresh URL protocol registration: {error}"),
        );
    }
    let event_loop = EventLoop::<DesktopEvent>::with_user_event().build()?;
    let proxy = event_loop.create_proxy();
    let existing = arguments
        .display_name
        .clone()
        .or_else(|| existing_name(&arguments.data_dir));
    let web_context = wry::WebContext::new(Some(arguments.data_dir.join("webview2")));
    let mut application = DesktopApplication {
        arguments,
        proxy,
        existing_name: existing,
        started: false,
        window: None,
        webview: None,
        web_context,
    };
    event_loop.run_app(&mut application)?;
    Ok(())
}

#[cfg(not(windows))]
fn run_desktop(_arguments: Arguments) -> Result<()> {
    Err(anyhow!(
        "the Freedom desktop shell currently targets Windows 10/11 x64"
    ))
}

#[cfg(windows)]
#[derive(Debug)]
enum DesktopEvent {
    Start(String),
    OpenHtdocs,
    OpenExternal(String),
    Ready(Result<String, String>),
    PageLoaded(&'static str),
    DomMetrics(String),
}

#[cfg(windows)]
struct DesktopApplication {
    arguments: Arguments,
    proxy: winit::event_loop::EventLoopProxy<DesktopEvent>,
    existing_name: Option<String>,
    started: bool,
    window: Option<winit::window::Window>,
    webview: Option<wry::WebView>,
    web_context: wry::WebContext,
}

#[cfg(windows)]
impl DesktopApplication {
    fn start(&mut self, display_name: String) {
        if self.started {
            return;
        }
        self.started = true;
        append_startup_log(
            &self.arguments.data_dir,
            "starting Freedom Core and gateways",
        );
        if let Some(webview) = &self.webview {
            let _ = webview.evaluate_script(
                "document.body.innerHTML='<div style=\"display:grid;place-items:center;height:100vh;background:#040a14;color:#eef5ff;font:16px Segoe UI\"><h2>Starting Freedom…</h2></div>'",
            );
        }
        let arguments = self.arguments.clone();
        let proxy = self.proxy.clone();
        thread::spawn(move || {
            let runtime = match tokio::runtime::Runtime::new() {
                Ok(runtime) => runtime,
                Err(error) => {
                    let _ = proxy.send_event(DesktopEvent::Ready(Err(error.to_string())));
                    return;
                }
            };
            let outcome = runtime.block_on(async {
                start_services(&arguments, display_name)
                    .await
                    .map(|(_, info)| info.control_url)
                    .map_err(|error| error.to_string())
            });
            append_startup_log(
                &arguments.data_dir,
                if outcome.is_ok() {
                    "core and gateways ready"
                } else {
                    "core or gateway startup failed"
                },
            );
            let running = outcome.is_ok();
            let _ = proxy.send_event(DesktopEvent::Ready(outcome));
            if running {
                runtime.block_on(std::future::pending::<()>());
            }
        });
    }
}

#[cfg(windows)]
impl winit::application::ApplicationHandler<DesktopEvent> for DesktopApplication {
    fn resumed(&mut self, event_loop: &winit::event_loop::ActiveEventLoop) {
        use wry::WebViewBuilderExtWindows;

        if self.window.is_some() {
            return;
        }
        let attributes = winit::window::Window::default_attributes()
            .with_title("Freedom")
            .with_inner_size(winit::dpi::LogicalSize::new(1180.0, 760.0))
            .with_min_inner_size(winit::dpi::LogicalSize::new(760.0, 560.0))
            .with_maximized(true);
        let window = event_loop
            .create_window(attributes)
            .expect("create Freedom window");
        let page_proxy = self.proxy.clone();
        let title_proxy = self.proxy.clone();
        let ipc_proxy = self.proxy.clone();
        let navigation_proxy = self.proxy.clone();
        let initial_html = if self.existing_name.is_some() {
            shell::LOADING_HTML.to_owned()
        } else {
            shell::FIRST_RUN_HTML.replace(
                "__DEFAULT_DISPLAY_NAME__",
                if self.arguments.role == ApplicationRole::Authority {
                    "UncleSam"
                } else {
                    ""
                },
            )
        };
        let physical_size = window.inner_size();
        let logical_size = physical_size.to_logical::<u32>(window.scale_factor());
        append_startup_log(
            &self.arguments.data_dir,
            &format!(
                "native window created: physical={}x{}, logical={}x{}, scale={}",
                physical_size.width,
                physical_size.height,
                logical_size.width,
                logical_size.height,
                window.scale_factor()
            ),
        );
        let bounds = wry::Rect {
            position: wry::dpi::LogicalPosition::new(0, 0).into(),
            size: wry::dpi::LogicalSize::new(logical_size.width, logical_size.height).into(),
        };
        let webview = wry::WebViewBuilder::new_with_web_context(&mut self.web_context)
            .with_bounds(bounds)
            .with_custom_protocol("freedomui".into(), move |_webview_id, _request| {
                wry::http::Response::builder()
                    .header(wry::http::header::CONTENT_TYPE, "text/html; charset=utf-8")
                    .header(wry::http::header::CACHE_CONTROL, "no-store")
                    .body(Cow::Owned(initial_html.clone().into_bytes()))
                    .expect("build embedded bootstrap response")
            })
            .with_url("freedomui://bootstrap")
            .with_background_color((7, 16, 24, 255))
            .with_visible(true)
            .with_additional_browser_args(
                "--disable-gpu --disable-gpu-compositing --disable-features=msWebOOUI,msPdfOOUI,msSmartScreenProtection",
            )
            .with_document_title_changed_handler(move |title| {
                if let Some(name) = title.strip_prefix("FREEDOM_START:") {
                    let name = name.trim();
                    if !name.is_empty()
                        && name.chars().count() <= 64
                        && !name.chars().any(char::is_control)
                    {
                        let _ = title_proxy.send_event(DesktopEvent::Start(name.to_owned()));
                    }
                } else if let Some(metric) = title.strip_prefix("FREEDOM_DIAG:") {
                    let _ = title_proxy.send_event(DesktopEvent::DomMetrics(metric.to_owned()));
                } else if title.starts_with("FREEDOM_OPEN_HTDOCS:") {
                    let _ = title_proxy.send_event(DesktopEvent::OpenHtdocs);
                }
            })
            .with_ipc_handler(move |request| {
                if !request
                    .uri()
                    .to_string()
                    .starts_with("http://app.freedom.localhost:")
                {
                    return;
                }
                let Ok(message) = serde_json::from_str::<DesktopIpcMessage>(request.body()) else {
                    return;
                };
                if message.action == "open_external" && safe_external_url(&message.url).is_some() {
                    let _ = ipc_proxy.send_event(DesktopEvent::OpenExternal(message.url));
                }
            })
            .with_navigation_handler(move |uri| {
                let allowed = uri.starts_with("http://app.freedom.localhost:")
                    || uri.starts_with("http://freedomui.")
                    || uri.starts_with("freedomui://")
                    || uri == "about:blank";
                if !allowed && safe_external_url(&uri).is_some() {
                    let _ = navigation_proxy.send_event(DesktopEvent::OpenExternal(uri));
                }
                allowed
            })
            .with_new_window_req_handler(|_, _| wry::NewWindowResponse::Deny)
            .with_on_page_load_handler(move |event, uri| {
                if matches!(event, wry::PageLoadEvent::Finished) {
                    let page = if uri.starts_with("http://app.freedom.localhost:") {
                        "control shell rendered"
                    } else {
                        "bootstrap page rendered"
                    };
                    let _ = page_proxy.send_event(DesktopEvent::PageLoaded(page));
                }
            })
            .build_as_child(&window)
            .expect("create Freedom WebView2 shell");
        if let Err(error) = webview.set_visible(true) {
            append_startup_log(
                &self.arguments.data_dir,
                &format!("WebView2 visibility error: {error}"),
            );
        }
        if let Err(error) = webview.set_bounds(bounds) {
            append_startup_log(
                &self.arguments.data_dir,
                &format!("WebView2 bounds error: {error}"),
            );
        }
        window.set_visible(true);
        window.request_redraw();
        append_startup_log(
            &self.arguments.data_dir,
            "WebView2 child created with explicit bounds",
        );
        self.window = Some(window);
        self.webview = Some(webview);
        if let Some(name) = self.existing_name.clone() {
            self.start(name);
        }
    }

    fn user_event(
        &mut self,
        _event_loop: &winit::event_loop::ActiveEventLoop,
        event: DesktopEvent,
    ) {
        match event {
            DesktopEvent::Start(name) => self.start(name),
            DesktopEvent::OpenHtdocs => {
                let htdocs = self.arguments.htdocs_dir.clone();
                if let Err(error) = std::fs::create_dir_all(&htdocs).and_then(|()| {
                    std::process::Command::new("explorer.exe")
                        .arg(&htdocs)
                        .spawn()
                        .map(|_| ())
                }) {
                    append_startup_log(
                        &self.arguments.data_dir,
                        &format!("could not open htdocs: {error}"),
                    );
                }
            }
            DesktopEvent::OpenExternal(url) => {
                if let Err(error) = open_external_url(&url) {
                    append_startup_log(
                        &self.arguments.data_dir,
                        &format!("could not open external URL: {error}"),
                    );
                }
            }
            DesktopEvent::Ready(Ok(url)) => {
                if let Some(webview) = &self.webview
                    && let Err(error) = webview.load_url(&url)
                {
                    tracing::error!(%error, "could not load Freedom desktop shell");
                    append_startup_log(&self.arguments.data_dir, "control shell navigation failed");
                }
            }
            DesktopEvent::Ready(Err(error)) => {
                if let Some(webview) = &self.webview {
                    let encoded = serde_json::to_string(&error)
                        .unwrap_or_else(|_| "\"unknown error\"".into());
                    let script = format!(
                        "document.body.innerHTML='<main style=\"padding:40px;background:#040a14;color:#fff;height:100vh;font:16px Segoe UI\"><h1>Freedom could not start</h1><pre id=\"e\" style=\"white-space:pre-wrap;color:#ff8497\"></pre></main>';document.getElementById('e').textContent={encoded};"
                    );
                    let _ = webview.evaluate_script(&script);
                }
                append_startup_log(&self.arguments.data_dir, &format!("startup error: {error}"));
            }
            DesktopEvent::PageLoaded(page) => {
                append_startup_log(&self.arguments.data_dir, page);
                if let Some(webview) = &self.webview {
                    let script = r#"(()=>{const body=document.body,root=document.documentElement;const metric={innerWidth:window.innerWidth,innerHeight:window.innerHeight,devicePixelRatio:window.devicePixelRatio,bodyWidth:body?body.getBoundingClientRect().width:0,bodyHeight:body?body.getBoundingClientRect().height:0,rootWidth:root?root.getBoundingClientRect().width:0,rootHeight:root?root.getBoundingClientRect().height:0,textLength:body?body.innerText.length:0,visibility:document.visibilityState};document.title='FREEDOM_DIAG:'+JSON.stringify(metric);})()"#;
                    if let Err(error) = webview.evaluate_script(script) {
                        append_startup_log(
                            &self.arguments.data_dir,
                            &format!("DOM diagnostic error: {error}"),
                        );
                    }
                }
            }
            DesktopEvent::DomMetrics(metric) => {
                append_startup_log(&self.arguments.data_dir, &format!("DOM metrics: {metric}"));
            }
        }
    }

    fn window_event(
        &mut self,
        event_loop: &winit::event_loop::ActiveEventLoop,
        _window_id: winit::window::WindowId,
        event: winit::event::WindowEvent,
    ) {
        match event {
            winit::event::WindowEvent::Resized(size) => {
                if let (Some(window), Some(webview)) = (&self.window, &self.webview) {
                    let size = size.to_logical::<u32>(window.scale_factor());
                    if let Err(error) = webview.set_bounds(wry::Rect {
                        position: wry::dpi::LogicalPosition::new(0, 0).into(),
                        size: wry::dpi::LogicalSize::new(size.width, size.height).into(),
                    }) {
                        tracing::error!(%error, "could not resize Freedom WebView2 child");
                    }
                }
            }
            winit::event::WindowEvent::CloseRequested => event_loop.exit(),
            _ => {}
        }
    }
}

#[cfg(windows)]
#[derive(Deserialize)]
struct DesktopIpcMessage {
    action: String,
    url: String,
}

fn safe_external_url(value: &str) -> Option<String> {
    if value.is_empty() || value.len() > 2048 || value.chars().any(char::is_control) {
        return None;
    }
    let parsed = url::Url::parse(value).ok()?;
    if !matches!(parsed.scheme(), "http" | "https")
        || parsed.host_str().is_none()
        || !parsed.username().is_empty()
        || parsed.password().is_some()
    {
        return None;
    }
    let host = parsed.host_str()?.to_ascii_lowercase();
    if host == "freedom.localhost" || host.ends_with(".freedom.localhost") {
        return None;
    }
    Some(parsed.to_string())
}

#[cfg(windows)]
fn open_external_url(value: &str) -> Result<()> {
    use windows_sys::Win32::UI::{Shell::ShellExecuteW, WindowsAndMessaging::SW_SHOWNORMAL};

    let url = safe_external_url(value).ok_or_else(|| anyhow!("invalid external URL"))?;
    let operation = "open\0".encode_utf16().collect::<Vec<_>>();
    let url = url.encode_utf16().chain(Some(0)).collect::<Vec<_>>();
    let result = unsafe {
        ShellExecuteW(
            std::ptr::null_mut(),
            operation.as_ptr(),
            url.as_ptr(),
            std::ptr::null(),
            std::ptr::null(),
            SW_SHOWNORMAL,
        )
    };
    if result as isize <= 32 {
        return Err(anyhow!("Windows could not open the default browser"));
    }
    Ok(())
}

#[cfg(windows)]
fn register_protocols_for_current_executable() -> Result<()> {
    let executable = std::env::current_exe().context("could not locate Freedom.exe")?;
    let executable = executable
        .to_str()
        .ok_or_else(|| anyhow!("Freedom.exe path is not valid Unicode"))?;
    for scheme in ["freedom", "free"] {
        let root = format!("Software\\Classes\\{scheme}");
        set_current_user_registry_string(
            &root,
            None,
            &format!("URL:Freedom Network {scheme} protocol"),
        )?;
        set_current_user_registry_string(&root, Some("URL Protocol"), "")?;
        set_current_user_registry_string(
            &format!("{root}\\DefaultIcon"),
            None,
            &format!("\"{executable}\",0"),
        )?;
        set_current_user_registry_string(
            &format!("{root}\\shell\\open\\command"),
            None,
            &format!("\"{executable}\" \"%1\""),
        )?;
    }
    Ok(())
}

#[cfg(windows)]
fn set_current_user_registry_string(path: &str, name: Option<&str>, value: &str) -> Result<()> {
    use windows_sys::Win32::{
        Foundation::ERROR_SUCCESS,
        System::Registry::{
            HKEY_CURRENT_USER, KEY_SET_VALUE, REG_OPTION_NON_VOLATILE, REG_SZ, RegCloseKey,
            RegCreateKeyExW, RegSetValueExW,
        },
    };

    let path = path.encode_utf16().chain(Some(0)).collect::<Vec<_>>();
    let name = name.map(|name| name.encode_utf16().chain(Some(0)).collect::<Vec<_>>());
    let value = value.encode_utf16().chain(Some(0)).collect::<Vec<_>>();
    let byte_length = u32::try_from(value.len() * std::mem::size_of::<u16>())
        .context("protocol registry value is too long")?;
    let mut key = std::ptr::null_mut();
    let opened = unsafe {
        RegCreateKeyExW(
            HKEY_CURRENT_USER,
            path.as_ptr(),
            0,
            std::ptr::null(),
            REG_OPTION_NON_VOLATILE,
            KEY_SET_VALUE,
            std::ptr::null(),
            &mut key,
            std::ptr::null_mut(),
        )
    };
    if opened != ERROR_SUCCESS {
        return Err(anyhow!(
            "could not create current-user protocol key ({opened})"
        ));
    }
    let name_ptr = name
        .as_ref()
        .map(|name| name.as_ptr())
        .unwrap_or(std::ptr::null());
    let written =
        unsafe { RegSetValueExW(key, name_ptr, 0, REG_SZ, value.as_ptr().cast(), byte_length) };
    unsafe {
        RegCloseKey(key);
    }
    if written != ERROR_SUCCESS {
        return Err(anyhow!(
            "could not write current-user protocol key ({written})"
        ));
    }
    Ok(())
}

fn reset_startup_log(data_dir: &Path) {
    if std::fs::create_dir_all(data_dir).is_ok() {
        let _ = std::fs::write(
            data_dir.join("startup.log"),
            "Freedom desktop startup diagnostics\n",
        );
    }
}

fn append_startup_log(data_dir: &Path, message: &str) {
    let Ok(mut file) = std::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(data_dir.join("startup.log"))
    else {
        return;
    };
    let seconds = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    let _ = writeln!(file, "{seconds}: {message}");
}

#[cfg(test)]
mod tests {
    use super::{is_freedom_address, normalize_launch_address, safe_external_url};

    #[test]
    fn launch_alias_is_normalized_to_the_canonical_origin() {
        assert_eq!(
            normalize_launch_address("free://mail.freedom.net/inbox").unwrap(),
            "freedom://mail.freedom.net/inbox"
        );
        assert_eq!(
            normalize_launch_address("FREEDOM://freedom.net/").unwrap(),
            "freedom://freedom.net/"
        );
        assert!(is_freedom_address("FREE://example/"));
        assert!(normalize_launch_address("https://example.com").is_err());
    }

    #[test]
    fn external_urls_are_strictly_limited_to_normal_web_addresses() {
        assert_eq!(
            safe_external_url("https://example.com/news?q=freedom#today").as_deref(),
            Some("https://example.com/news?q=freedom#today")
        );
        assert!(safe_external_url("http://example.com/").is_some());
        assert!(safe_external_url("https://user:secret@example.com/").is_none());
        assert!(safe_external_url("file:///C:/Windows/win.ini").is_none());
        assert!(safe_external_url("javascript:alert(1)").is_none());
        assert!(safe_external_url("http://site.freedom.localhost:1234/").is_none());
    }
}
