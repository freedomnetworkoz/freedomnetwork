use std::{
    fs,
    net::SocketAddr,
    path::{Component, Path as FsPath, PathBuf},
    sync::Arc,
};

use anyhow::{Context, Result};
use axum::{
    Json, Router,
    body::{Body, Bytes},
    extract::{DefaultBodyLimit, Path, RawQuery, State},
    http::{HeaderMap, HeaderName, HeaderValue, Method, StatusCode, header, uri::Authority},
    response::{Html, IntoResponse, Response},
    routing::{any, get, post},
};
use freedom_core::{
    MAX_SITE_FILE_BYTES, MAX_SITE_RANGE_BYTES, MAX_SITE_REQUEST_BYTES, NameRecord, NodeHandle,
    SiteHeader, SiteRequest, parse_manual_peer,
};
use rand::RngCore;
use serde::Deserialize;
use serde_json::json;
use sha2::{Digest, Sha256};
use tokio::net::TcpListener;
use tracing::{error, info};

use crate::{app_lock::AppLock, shell::APP_HTML};

#[derive(Clone)]
struct GatewayState {
    node: NodeHandle,
    app_lock: AppLock,
    capability: Option<Arc<str>>,
    public_origin: Arc<str>,
    initial_address: Arc<str>,
}

#[derive(Clone, Debug)]
pub struct GatewayInfo {
    pub public_address: SocketAddr,
    pub control_url: String,
}

pub async fn start_gateways(
    node: NodeHandle,
    public_port: u16,
    initial_address: Option<&str>,
    data_dir: &FsPath,
) -> Result<GatewayInfo> {
    let public_listener = TcpListener::bind(("127.0.0.1", public_port))
        .await
        .with_context(|| format!("could not bind public gateway port {public_port}"))?;
    let public_address = public_listener.local_addr()?;
    let public_origin: Arc<str> = format!("http://{public_address}").into();
    let initial_address: Arc<str> = initial_address
        .unwrap_or("freedom://freedom.net/")
        .to_owned()
        .into();
    let app_lock = AppLock::load(data_dir)?;

    let public_state = GatewayState {
        node: node.clone(),
        app_lock: app_lock.clone(),
        capability: None,
        public_origin: Arc::clone(&public_origin),
        initial_address: Arc::clone(&initial_address),
    };
    let public_router = Router::new()
        .route("/", any(public_root))
        .route("/status", get(public_status))
        .route("/site/{peer}/{site}", any(public_site_root))
        .route("/site/{peer}/{site}/", any(public_site_root))
        .route("/site/{peer}/{site}/{*path}", any(public_site_path))
        .route("/{*path}", any(public_origin_site_path))
        .layer(DefaultBodyLimit::max(MAX_SITE_REQUEST_BYTES))
        .with_state(public_state);
    tokio::spawn(async move {
        if let Err(error) = axum::serve(public_listener, public_router).await {
            error!(%error, "public gateway stopped");
        }
    });

    let capability = random_capability();
    let control_listener = TcpListener::bind(("127.0.0.1", 0)).await?;
    let control_address = control_listener.local_addr()?;
    let control_state = GatewayState {
        node,
        app_lock,
        capability: Some(Arc::from(capability.clone())),
        public_origin,
        initial_address,
    };
    let control_router = control_router(control_state);
    tokio::spawn(async move {
        if let Err(error) = axum::serve(control_listener, control_router).await {
            error!(%error, "desktop control service stopped");
        }
    });

    info!(%public_address, %control_address, "local gateways ready");
    Ok(GatewayInfo {
        public_address,
        control_url: format!(
            "http://app.freedom.localhost:{}/app/{capability}",
            control_address.port()
        ),
    })
}

fn control_router(state: GatewayState) -> Router {
    let router = Router::new()
        .route("/app/{capability}", get(app_shell))
        .route("/api/snapshot", get(snapshot))
        .route("/api/app-lock", get(app_lock_state).post(update_app_lock))
        .route("/api/network-fetch", post(network_fetch))
        .route("/api/connect", post(connect))
        .route("/api/message", post(message))
        .route("/api/conversation-read", post(mark_conversation_read))
        .route("/api/mail", post(send_mail))
        .route("/api/mail-read", post(mark_mail_read))
        .route("/api/sites", post(add_site))
        .route("/api/site-files", post(upload_site_file))
        .route(
            "/api/site-pages",
            get(list_site_pages).post(site_page_action),
        )
        .route("/api/site-page", get(read_site_page))
        .route("/api/site-folders", get(list_site_folders))
        .route("/api/site-protection", post(set_site_protection))
        .route("/api/site-state", post(set_site_state))
        .route("/api/contact", post(set_contact))
        .route("/api/profile", post(update_profile));
    #[cfg(feature = "authority")]
    let router = router.route("/api/authority-names", post(update_authority_name));
    router
        .layer(DefaultBodyLimit::max(MAX_SITE_FILE_BYTES as usize))
        .with_state(state)
}

async fn public_home() -> Html<&'static str> {
    Html(
        r#"<!doctype html><html><head><meta charset="utf-8"><title>Freedom Gateway</title>
<style>body{font:16px system-ui;background:#0a1118;color:#e7f5ef;max-width:760px;margin:12vh auto;padding:30px}code{color:#7ce0b3}small{color:#8ba39a}</style></head>
<body><h1>Freedom public gateway</h1><p>This loopback-only gateway reads public static content from peers reachable by your running Freedom node.</p>
<p><code>/site/&lt;peer-id&gt;/&lt;site-id&gt;/</code></p><small>Messages, private keys, contacts, identity administration and site administration are deliberately unavailable here.</small></body></html>"#,
    )
}

async fn public_root(
    State(state): State<GatewayState>,
    RawQuery(query): RawQuery,
    method: Method,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    if let Some((peer, site)) = site_identity_from_host(&headers) {
        let request = site_request(method, query, &headers, body);
        return serve_site(state, peer, site, String::new(), request).await;
    }
    if method == Method::GET {
        public_home().await.into_response()
    } else {
        StatusCode::NOT_FOUND.into_response()
    }
}

async fn public_origin_site_path(
    State(state): State<GatewayState>,
    Path(path): Path<String>,
    RawQuery(query): RawQuery,
    method: Method,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let Some((peer, site)) = site_identity_from_host(&headers) else {
        return StatusCode::NOT_FOUND.into_response();
    };
    let request = site_request(method, query, &headers, body);
    serve_site(state, peer, site, path, request).await
}

async fn public_status(State(state): State<GatewayState>) -> Json<serde_json::Value> {
    let snapshot = state.node.snapshot().await;
    Json(json!({
        "application": "Freedom",
        "network": "Freedom Network",
        "status": "running",
        "peer_id": snapshot.peer_id,
        "fingerprint": snapshot.fingerprint
    }))
}

async fn public_site_root(
    State(state): State<GatewayState>,
    Path((peer, site)): Path<(String, String)>,
    RawQuery(query): RawQuery,
    method: Method,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let request = site_request(method, query, &headers, body);
    serve_site(state, peer, site, String::new(), request).await
}

async fn public_site_path(
    State(state): State<GatewayState>,
    Path((peer, site, path)): Path<(String, String, String)>,
    RawQuery(query): RawQuery,
    method: Method,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    let request = site_request(method, query, &headers, body);
    serve_site(state, peer, site, path, request).await
}

async fn serve_site(
    state: GatewayState,
    peer: String,
    site: String,
    path: String,
    request: SiteRequest,
) -> Response {
    let head_only = request.method == "HEAD";
    let bridge_allowed = request.method == "GET"
        && !request
            .headers
            .iter()
            .any(|header| header.name.eq_ignore_ascii_case("range"));
    let first = state
        .node
        .request_site(&peer, &site, &path, request.clone())
        .await;
    let result = match first {
        Ok(file) => {
            if let Some(retry) = retry_unsatisfied_range(&request, file.status_code, &file.headers)
            {
                state.node.request_site(&peer, &site, &path, retry).await
            } else {
                Ok(file)
            }
        }
        error => error,
    };
    match result {
        Ok(mut file) => {
            if head_only {
                file.body.clear();
            }
            let bridge_injected = bridge_allowed
                && file.status_code != StatusCode::PARTIAL_CONTENT.as_u16()
                && is_html_content_type(&file.mime_type)
                && inject_site_navigation_bridge(&mut file.body);
            let response_hash = if bridge_injected {
                format!("{:x}", Sha256::digest(&file.body))
            } else {
                file.sha256
            };
            let mut response = Response::builder()
                .status(StatusCode::from_u16(file.status_code).unwrap_or(StatusCode::BAD_GATEWAY))
                .header(header::CONTENT_TYPE, file.mime_type)
                .header(header::X_CONTENT_TYPE_OPTIONS, "nosniff")
                .header(header::REFERRER_POLICY, "no-referrer")
                .header(
                    header::CONTENT_SECURITY_POLICY,
                    "frame-ancestors 'self' http://app.freedom.localhost:*",
                )
                .header(
                    "Permissions-Policy",
                    "camera=(), microphone=(), geolocation=()",
                )
                .header("X-Freedom-Content-SHA256", response_hash);
            if bridge_injected {
                response = response.header(header::CACHE_CONTROL, "no-store");
            }
            if let Some(challenge) = file.www_authenticate
                && challenge.len() <= 512
                && let Ok(challenge) = challenge.parse::<axum::http::HeaderValue>()
            {
                response = response.header(header::WWW_AUTHENTICATE, challenge);
            }
            for forwarded in file.headers {
                if bridge_injected
                    && matches!(
                        forwarded.name.to_ascii_lowercase().as_str(),
                        "cache-control"
                            | "content-length"
                            | "content-range"
                            | "etag"
                            | "expires"
                            | "last-modified"
                            | "pragma"
                    )
                {
                    continue;
                }
                if !response_header_allowed(&forwarded.name) {
                    continue;
                }
                let Ok(name) = HeaderName::try_from(forwarded.name) else {
                    continue;
                };
                let Ok(value) = HeaderValue::try_from(forwarded.value) else {
                    continue;
                };
                response = response.header(name, value);
            }
            response.body(Body::from(file.body)).unwrap()
        }
        Err(error) => {
            tracing::warn!(peer = %peer, site = %site, %error, "Freedom site is currently unreachable");
            offline_site_response(&site)
        }
    }
}

fn is_html_content_type(content_type: &str) -> bool {
    content_type
        .split(';')
        .next()
        .is_some_and(|kind| kind.trim().eq_ignore_ascii_case("text/html"))
}

fn inject_site_navigation_bridge(body: &mut Vec<u8>) -> bool {
    const MARKER: &str = "freedom-navigation-bridge";
    const BRIDGE: &str = r#"<script id="freedom-navigation-bridge">(()=>{let navigationToken=0;const report=()=>parent.postMessage({freedomLocation:{path:location.pathname,query:location.search,hash:location.hash,title:document.title,navigationToken}},'*');document.addEventListener('click',event=>{const link=event.target.closest?.('a[href]');if(!link)return;const target=(link.getAttribute('href')||'').trim();if(/^free(dom)?:\/\//i.test(target)){event.preventDefault();parent.postMessage({freedomNavigate:target,freedomNewTab:link.target==='_blank'},'*');return}if(/^https?:\/\//i.test(target)){event.preventDefault();parent.postMessage({freedomExternal:target},'*')}});addEventListener('message',event=>{const token=event.data?.freedomNavigationToken;if(event.source===parent&&Number.isSafeInteger(token)&&token>0){navigationToken=token;report()}});addEventListener('hashchange',report);addEventListener('popstate',report);const push=history.pushState.bind(history),replace=history.replaceState.bind(history);history.pushState=(...args)=>{push(...args);report()};history.replaceState=(...args)=>{replace(...args);report()};queueMicrotask(report)})()</script>"#;

    if body
        .windows(MARKER.len())
        .any(|candidate| candidate == MARKER.as_bytes())
    {
        return false;
    }
    body.extend_from_slice(BRIDGE.as_bytes());
    true
}

fn offline_site_response(site: &str) -> Response {
    let html = offline_site_html(site);
    Response::builder()
        .status(StatusCode::SERVICE_UNAVAILABLE)
        .header(header::CONTENT_TYPE, "text/html; charset=utf-8")
        .header(header::X_CONTENT_TYPE_OPTIONS, "nosniff")
        .header(header::REFERRER_POLICY, "no-referrer")
        .header(
            header::CONTENT_SECURITY_POLICY,
            "frame-ancestors 'self' http://app.freedom.localhost:*",
        )
        .header(header::CACHE_CONTROL, "no-store")
        .header(header::RETRY_AFTER, "15")
        .body(Body::from(html))
        .unwrap()
}

fn offline_site_html(site: &str) -> String {
    let site = site
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;");
    format!(
        r#"<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Site currently offline</title><style>:root{{color-scheme:dark;font:16px Inter,Segoe UI,system-ui,sans-serif}}*{{box-sizing:border-box}}body{{margin:0;min-height:100vh;display:grid;place-items:center;padding:28px;background:radial-gradient(circle at 20% 15%,#12345f,transparent 38%),#040a14;color:#eef5ff}}main{{width:min(620px,100%);padding:34px;border:1px solid #1c3b62;border-radius:20px;background:#071426e8;box-shadow:0 24px 80px #0008}}.status{{color:#58a9ff;font-size:12px;font-weight:800;letter-spacing:.13em;text-transform:uppercase}}h1{{margin:12px 0 8px;font-size:36px}}p{{color:#a9bdd8;line-height:1.6}}code{{color:#7fbdff}}button{{margin-top:10px;padding:11px 16px;border:0;border-radius:9px;background:#ef334f;color:#ffffff;font-weight:800;cursor:pointer}}</style></head><body><main><div class="status">Freedom Network</div><h1>Site currently offline</h1><p><code>{site}</code> is known, but its host node is not connected or cannot answer right now.</p><p>Please try again later when the user's node is connected.</p><button type="button" onclick="location.reload()">Try again</button></main></body></html>"#
    )
}

fn retry_unsatisfied_range(
    request: &SiteRequest,
    status_code: u16,
    response_headers: &[SiteHeader],
) -> Option<SiteRequest> {
    if status_code != StatusCode::RANGE_NOT_SATISFIABLE.as_u16() {
        return None;
    }
    let file_size = response_headers
        .iter()
        .find(|header| header.name.eq_ignore_ascii_case("content-range"))?
        .value
        .trim()
        .strip_prefix("bytes */")?
        .parse::<u64>()
        .ok()?;
    if file_size == 0 {
        return None;
    }
    let range_index = request
        .headers
        .iter()
        .position(|header| header.name.eq_ignore_ascii_case("range"))?;
    let range = request.headers[range_index]
        .value
        .trim()
        .strip_prefix("bytes=")?;
    if range.contains(',') {
        return None;
    }
    let (start, requested_end) = range.split_once('-')?;
    let start = start.parse::<u64>().ok()?;
    let requested_end = requested_end.parse::<u64>().ok()?;
    if start >= file_size || requested_end < file_size {
        return None;
    }
    let mut retry = request.clone();
    retry.headers[range_index].value = format!("bytes={start}-{}", file_size - 1);
    Some(retry)
}

fn site_request(
    method: Method,
    query: Option<String>,
    headers: &HeaderMap,
    body: Bytes,
) -> SiteRequest {
    let content_type = headers
        .get(header::CONTENT_TYPE)
        .and_then(|value| value.to_str().ok())
        .unwrap_or("");
    let authorization = headers
        .get(header::AUTHORIZATION)
        .and_then(|value| value.to_str().ok())
        .filter(|value| {
            value.len() <= 4096
                && value
                    .trim_start()
                    .get(..5)
                    .is_some_and(|scheme| scheme.eq_ignore_ascii_case("basic"))
        })
        .map(str::to_owned);
    let mut forwarded_headers = Vec::new();
    for name in [
        "accept",
        "accept-language",
        "cookie",
        "host",
        "if-modified-since",
        "if-none-match",
        "if-range",
        "origin",
        "range",
        "referer",
        "user-agent",
        "x-requested-with",
    ] {
        let Some(value) = headers.get(name).and_then(|value| value.to_str().ok()) else {
            continue;
        };
        if value.is_empty() || value.len() > 16 * 1024 {
            continue;
        }
        let value = if name == "range" {
            bounded_range(value).unwrap_or_else(|| value.to_owned())
        } else {
            value.to_owned()
        };
        forwarded_headers.push(SiteHeader {
            name: name.to_owned(),
            value,
        });
    }
    SiteRequest {
        method: method.as_str().to_owned(),
        query: query.unwrap_or_default(),
        content_type: content_type.to_owned(),
        authorization,
        headers: forwarded_headers,
        body: body.to_vec(),
    }
}

fn bounded_range(value: &str) -> Option<String> {
    let range = value.trim().strip_prefix("bytes=")?;
    if range.contains(',') {
        return None;
    }
    let (start, end) = range.split_once('-')?;
    if start.is_empty() {
        let suffix = end.parse::<u64>().ok()?.min(MAX_SITE_RANGE_BYTES);
        return (suffix > 0).then(|| format!("bytes=-{suffix}"));
    }
    let start = start.parse::<u64>().ok()?;
    let maximum_end = start.saturating_add(MAX_SITE_RANGE_BYTES - 1);
    let end = if end.is_empty() {
        maximum_end
    } else {
        end.parse::<u64>().ok()?.min(maximum_end)
    };
    (end >= start).then(|| format!("bytes={start}-{end}"))
}

fn response_header_allowed(name: &str) -> bool {
    matches!(
        name.to_ascii_lowercase().as_str(),
        "accept-ranges"
            | "cache-control"
            | "content-disposition"
            | "content-length"
            | "content-range"
            | "etag"
            | "expires"
            | "last-modified"
            | "link"
            | "location"
            | "pragma"
            | "refresh"
            | "set-cookie"
            | "vary"
    )
}

fn site_identity_from_host(headers: &HeaderMap) -> Option<(String, String)> {
    let authority = headers
        .get(header::HOST)?
        .to_str()
        .ok()?
        .parse::<Authority>()
        .ok()?;
    decode_site_origin(authority.host())
}

fn decode_site_origin(host: &str) -> Option<(String, String)> {
    let host = host.to_ascii_lowercase();
    let encoded_host = host
        .strip_suffix(".freedom.localhost")
        .or_else(|| host.strip_suffix(".localhost"))?;
    let mut labels = encoded_host.split('.');
    let first = labels.next()?.strip_prefix("f-")?;
    let mut encoded = first.to_owned();
    for label in labels {
        if label.is_empty() || label.len() > 63 {
            return None;
        }
        encoded.push_str(label);
    }
    let decoded = decode_base32(&encoded)?;
    let identity = String::from_utf8(decoded).ok()?;
    let mut components = identity.split('\0');
    let peer = components.next()?;
    let site = components.next()?;
    let origin_name = components.next();
    if peer.is_empty()
        || peer.len() > 128
        || site.is_empty()
        || site.len() > 48
        || components.next().is_some()
        || origin_name.is_some_and(|name| {
            name.is_empty()
                || name.len() > 253
                || name != name.to_ascii_lowercase()
                || name.split('.').any(|label| {
                    label.is_empty()
                        || label.len() > 63
                        || !label.bytes().all(|byte| {
                            byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-'
                        })
                })
        })
    {
        return None;
    }
    Some((peer.to_owned(), site.to_owned()))
}

fn decode_base32(encoded: &str) -> Option<Vec<u8>> {
    let mut output = Vec::with_capacity(encoded.len() * 5 / 8);
    let mut buffer = 0_u32;
    let mut bits = 0_u8;
    for byte in encoded.bytes() {
        let value = match byte {
            b'a'..=b'z' => byte - b'a',
            b'2'..=b'7' => byte - b'2' + 26,
            _ => return None,
        };
        buffer = (buffer << 5) | u32::from(value);
        bits += 5;
        if bits >= 8 {
            bits -= 8;
            output.push((buffer >> bits) as u8);
            buffer &= (1_u32 << bits) - 1;
        }
    }
    (bits == 0 || buffer == 0).then_some(output)
}

async fn app_shell(State(state): State<GatewayState>, Path(capability): Path<String>) -> Response {
    if state.capability.as_deref() != Some(capability.as_str()) {
        return StatusCode::NOT_FOUND.into_response();
    }
    let html = APP_HTML
        .replace("__FREEDOM_CAPABILITY__", &capability)
        .replace("__FREEDOM_PUBLIC_ORIGIN__", &state.public_origin)
        .replace(
            "__FREEDOM_INITIAL_ADDRESS__",
            &serde_json::to_string(state.initial_address.as_ref())
                .expect("serialize initial Freedom address"),
        );
    (
        [
            (header::CACHE_CONTROL, "no-store"),
            (header::X_CONTENT_TYPE_OPTIONS, "nosniff"),
            (header::REFERRER_POLICY, "no-referrer"),
        ],
        Html(html),
    )
        .into_response()
}

async fn snapshot(State(state): State<GatewayState>, headers: HeaderMap) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    Json(state.node.snapshot().await).into_response()
}

const MAX_NETWORK_FETCH_BYTES: usize = 2 * 1024 * 1024;

#[derive(Deserialize)]
struct NetworkFetchInput {
    address: String,
}

struct ResolvedNetworkLocation {
    peer_id: String,
    site_id: String,
    path: String,
    query: String,
}

async fn network_fetch(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<NetworkFetchInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let snapshot = state.node.snapshot().await;
    let location = match resolve_network_location(&input.address, &snapshot.names) {
        Ok(location) => location,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let request = SiteRequest {
        method: "GET".into(),
        query: location.query,
        content_type: String::new(),
        authorization: None,
        headers: Vec::new(),
        body: Vec::new(),
    };
    let file = match state
        .node
        .request_site(
            &location.peer_id,
            &location.site_id,
            &location.path,
            request,
        )
        .await
    {
        Ok(file) => file,
        Err(error) => return api_error(StatusCode::BAD_GATEWAY, &error.to_string()),
    };
    if !(200..300).contains(&file.status_code) {
        return api_error(
            StatusCode::BAD_GATEWAY,
            &format!("Freedom site returned status {}", file.status_code),
        );
    }
    if file.body.len() > MAX_NETWORK_FETCH_BYTES {
        return api_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "Freedom page exceeds the 2 MiB search-index limit",
        );
    }
    let content_kind = file
        .mime_type
        .split(';')
        .next()
        .unwrap_or("")
        .trim()
        .to_ascii_lowercase();
    if !content_kind.starts_with("text/") && content_kind != "application/xhtml+xml" {
        return api_error(
            StatusCode::UNSUPPORTED_MEDIA_TYPE,
            "Freedom search can index only text and HTML pages",
        );
    }
    Json(json!({
        "ok": true,
        "address": input.address,
        "content_type": file.mime_type,
        "body": String::from_utf8_lossy(&file.body),
    }))
    .into_response()
}

fn resolve_network_location(
    address: &str,
    names: &[NameRecord],
) -> Result<ResolvedNetworkLocation, String> {
    let mut normalized = address.trim().to_owned();
    if normalized.is_empty() || normalized.len() > 2048 || normalized.chars().any(char::is_control)
    {
        return Err("Enter a valid Freedom address".into());
    }
    if !normalized.contains("://") && normalized.contains('.') {
        normalized.insert_str(0, "freedom://");
    }
    if normalized
        .get(..7)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("free://"))
    {
        normalized.replace_range(..7, "freedom://");
    }
    if !normalized
        .get(..10)
        .is_some_and(|prefix| prefix.eq_ignore_ascii_case("freedom://"))
    {
        return Err("Only freedom:// addresses can be fetched".into());
    }
    let mut target = normalized[10..].to_owned();
    if let Some(fragment) = target.find('#') {
        target.truncate(fragment);
    }
    let query = if let Some(query_at) = target.find('?') {
        let query = target[query_at + 1..].to_owned();
        target.truncate(query_at);
        query
    } else {
        String::new()
    };
    if query.len() > 4096 {
        return Err("Freedom address query is too long".into());
    }
    let (host, remainder) = target.split_once('/').unwrap_or((&target, ""));
    if host.is_empty() || host.contains(['@', ':', '\\']) {
        return Err("Freedom address host is invalid".into());
    }
    if let Some(record) = names
        .iter()
        .find(|record| record.hostname.eq_ignore_ascii_case(host))
    {
        if !record.active {
            return Err(format!("{} is reserved but not active", record.hostname));
        }
        let peer_id = record
            .peer_id
            .clone()
            .ok_or_else(|| format!("{} has no destination PeerID", record.hostname))?;
        let site_id = record
            .site_id
            .clone()
            .ok_or_else(|| format!("{} has no destination site", record.hostname))?;
        return Ok(ResolvedNetworkLocation {
            peer_id,
            site_id,
            path: join_network_path(&record.path, remainder),
            query,
        });
    }
    let (site_id, path) = remainder
        .split_once('/')
        .map_or((remainder, ""), |(site, path)| (site, path));
    if site_id.is_empty() {
        return Err("Unknown name; direct addresses require a PeerID and site folder".into());
    }
    Ok(ResolvedNetworkLocation {
        peer_id: host.to_owned(),
        site_id: site_id.to_owned(),
        path: path.to_owned(),
        query,
    })
}

fn join_network_path(prefix: &str, suffix: &str) -> String {
    let prefix = prefix.trim_start_matches('/');
    let suffix = suffix.trim_start_matches('/');
    if prefix.is_empty() {
        suffix.to_owned()
    } else if suffix.is_empty() || prefix.ends_with('/') {
        format!("{prefix}{suffix}")
    } else {
        format!("{prefix}/{suffix}")
    }
}

async fn app_lock_state(State(state): State<GatewayState>, headers: HeaderMap) -> Response {
    if !capability_authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    Json(state.app_lock.snapshot()).into_response()
}

#[derive(Deserialize)]
struct AppLockInput {
    action: String,
    password: Option<String>,
    current_password: Option<String>,
    new_password: Option<String>,
}

async fn update_app_lock(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<AppLockInput>,
) -> Response {
    if !capability_authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let result = match input.action.as_str() {
        "activity" => Ok(state.app_lock.note_activity()),
        "lock" => Ok(state.app_lock.lock()),
        "unlock" => state
            .app_lock
            .unlock(input.password.as_deref().unwrap_or_default()),
        "set_password" => state.app_lock.set_password(
            input.current_password.as_deref(),
            input.new_password.as_deref().unwrap_or_default(),
        ),
        "remove_password" => state
            .app_lock
            .remove_password(input.current_password.as_deref().unwrap_or_default()),
        _ => Err("unsupported app-lock action".into()),
    };
    match result {
        Ok(status) => Json(json!({ "ok": true, "lock": status })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error),
    }
}

#[derive(Deserialize)]
struct ConnectInput {
    address: String,
    expected_fingerprint: Option<String>,
}

async fn connect(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<ConnectInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let peer = match parse_manual_peer(&input.address, input.expected_fingerprint.as_deref()) {
        Ok(peer) => peer,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    };
    match state.node.dial(peer).await {
        Ok(status) => Json(json!({ "ok": true, "status": status })).into_response(),
        Err(error) => api_error(StatusCode::BAD_GATEWAY, &error.to_string()),
    }
}

#[derive(Deserialize)]
struct MessageInput {
    peer_id: String,
    body: String,
}

#[derive(Deserialize)]
struct ConversationReadInput {
    peer_id: String,
}

#[derive(Deserialize)]
struct MailInput {
    recipient: String,
    subject: String,
    body: String,
}

#[derive(Deserialize)]
struct MailReadInput {
    message_id: String,
}

#[cfg(feature = "authority")]
#[derive(Deserialize)]
struct AuthorityNameInput {
    action: String,
    hostname: String,
    peer_id: Option<String>,
    site_id: Option<String>,
    path: Option<String>,
}

#[cfg(feature = "authority")]
async fn update_authority_name(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<AuthorityNameInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    if state.node.snapshot().await.application_role != "authority" {
        return api_error(StatusCode::FORBIDDEN, "Freedom Authority is required");
    }
    let hostname = input.hostname.trim().to_ascii_lowercase();
    let result = match input.action.as_str() {
        "delete" => state.node.remove_authority_name(&hostname).await,
        "save" => {
            let peer_id = input.peer_id.unwrap_or_default().trim().to_owned();
            let site_id = input
                .site_id
                .unwrap_or_default()
                .trim()
                .to_ascii_lowercase();
            let path = input.path.unwrap_or_else(|| "/".into());
            state
                .node
                .set_authority_name(NameRecord {
                    hostname,
                    record_type: "site".into(),
                    peer_id: Some(peer_id),
                    site_id: Some(site_id),
                    path,
                    official: true,
                    active: true,
                })
                .await
        }
        _ => return api_error(StatusCode::BAD_REQUEST, "unsupported DNS action"),
    };
    match result {
        Ok(sequence) => {
            let snapshot = state.node.snapshot().await;
            Json(json!({ "ok": true, "sequence": sequence, "names": snapshot.names }))
                .into_response()
        }
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

async fn message(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<MessageInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state.node.send_message(&input.peer_id, &input.body).await {
        Ok(message_id) => Json(json!({ "ok": true, "message_id": message_id })).into_response(),
        Err(error) => api_error(StatusCode::BAD_GATEWAY, &error.to_string()),
    }
}

async fn mark_conversation_read(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<ConversationReadInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state.node.mark_conversation_read(&input.peer_id).await {
        Ok(updated) => Json(json!({ "ok": true, "updated": updated })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

async fn send_mail(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<MailInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state
        .node
        .send_mail(&input.recipient, &input.subject, &input.body)
        .await
    {
        Ok(message_id) => Json(json!({ "ok": true, "message_id": message_id })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

async fn mark_mail_read(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<MailReadInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state.node.mark_mail_read(&input.message_id).await {
        Ok(updated) => Json(json!({ "ok": true, "updated": updated })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

#[derive(Deserialize)]
struct SiteInput {
    site_id: String,
    name: String,
    root: Option<PathBuf>,
}

async fn add_site(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<SiteInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let result = if let Some(root) = input.root {
        state
            .node
            .add_site(&input.site_id, &input.name, &root)
            .await
    } else {
        state.node.create_site(&input.site_id, &input.name).await
    };
    match result {
        Ok(site) => Json(json!({ "ok": true, "site": site })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

async fn upload_site_file(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    body: Bytes,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let Some(site_id) = required_header(&headers, "x-freedom-site") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Site header");
    };
    let Some(path) = required_header(&headers, "x-freedom-path") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Path header");
    };
    if body.len() as u64 > MAX_SITE_FILE_BYTES {
        return api_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "site file exceeds the 128 MiB limit",
        );
    }
    match state
        .node
        .upload_site_file(site_id, path, body.to_vec())
        .await
    {
        Ok(file) => Json(json!({ "ok": true, "file": file })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

const MAX_EDITOR_PAGE_BYTES: u64 = 2 * 1024 * 1024;
const PROTECTION_BEGIN: &str = "# BEGIN FREEDOM FOLDER PROTECTION";
const PROTECTION_END: &str = "# END FREEDOM FOLDER PROTECTION";

async fn managed_site_root(node: &NodeHandle, site_id: &str) -> Result<PathBuf, String> {
    let snapshot = node.snapshot().await;
    let site = snapshot
        .sites
        .iter()
        .find(|site| site.site_id == site_id)
        .ok_or_else(|| "site was not found".to_owned())?;
    let root = fs::canonicalize(&site.root).map_err(|_| "site folder is unavailable".to_owned())?;
    if !root.is_dir() {
        return Err("site folder is unavailable".to_owned());
    }
    Ok(root)
}

fn editor_page_name(value: &str) -> Result<String, String> {
    let name = value.trim();
    if name.is_empty() || name.len() > 80 || name.contains('/') || name.contains('\\') {
        return Err("page names must be simple .html filenames".to_owned());
    }
    let path = FsPath::new(name);
    if path.components().count() != 1
        || !path
            .extension()
            .and_then(|value| value.to_str())
            .is_some_and(|value| value.eq_ignore_ascii_case("html"))
    {
        return Err("page name must end in .html".to_owned());
    }
    let Some(stem) = path.file_stem().and_then(|value| value.to_str()) else {
        return Err("page name is invalid".to_owned());
    };
    if stem.is_empty()
        || !stem
            .chars()
            .all(|character| character.is_ascii_alphanumeric() || matches!(character, '-' | '_'))
    {
        return Err("use only letters, numbers, hyphens and underscores in page names".to_owned());
    }
    Ok(name.to_owned())
}

async fn list_site_pages(State(state): State<GatewayState>, headers: HeaderMap) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let Some(site_id) = required_header(&headers, "x-freedom-site") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Site header");
    };
    let root = match managed_site_root(&state.node, site_id).await {
        Ok(root) => root,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let entries = match fs::read_dir(root) {
        Ok(entries) => entries,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    };
    let mut pages = entries
        .filter_map(|entry| entry.ok())
        .filter(|entry| entry.file_type().is_ok_and(|kind| kind.is_file()))
        .filter_map(|entry| entry.file_name().into_string().ok())
        .filter(|name| editor_page_name(name).is_ok())
        .collect::<Vec<_>>();
    pages.sort_by(|left, right| {
        match (
            left.eq_ignore_ascii_case("index.html"),
            right.eq_ignore_ascii_case("index.html"),
        ) {
            (true, false) => std::cmp::Ordering::Less,
            (false, true) => std::cmp::Ordering::Greater,
            _ => left.to_ascii_lowercase().cmp(&right.to_ascii_lowercase()),
        }
    });
    Json(json!({ "ok": true, "pages": pages })).into_response()
}

async fn read_site_page(State(state): State<GatewayState>, headers: HeaderMap) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let Some(site_id) = required_header(&headers, "x-freedom-site") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Site header");
    };
    let Some(page) = required_header(&headers, "x-freedom-page") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Page header");
    };
    let page = match editor_page_name(page) {
        Ok(page) => page,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let root = match managed_site_root(&state.node, site_id).await {
        Ok(root) => root,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let path = root.join(&page);
    let metadata = match fs::symlink_metadata(&path) {
        Ok(metadata) if metadata.file_type().is_file() => metadata,
        _ => return api_error(StatusCode::NOT_FOUND, "page was not found"),
    };
    if metadata.len() > MAX_EDITOR_PAGE_BYTES {
        return api_error(
            StatusCode::PAYLOAD_TOO_LARGE,
            "page is too large for the built-in editor",
        );
    }
    match fs::read_to_string(path) {
        Ok(source) => Json(json!({ "ok": true, "page": page, "source": source })).into_response(),
        Err(error) if error.kind() == std::io::ErrorKind::InvalidData => api_error(
            StatusCode::BAD_REQUEST,
            "page is not UTF-8 HTML and cannot be edited visually",
        ),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

#[derive(Deserialize)]
struct SitePageAction {
    site_id: String,
    action: String,
    page: String,
    new_page: Option<String>,
}

async fn site_page_action(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<SitePageAction>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let page = match editor_page_name(&input.page) {
        Ok(page) => page,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let root = match managed_site_root(&state.node, &input.site_id).await {
        Ok(root) => root,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let current = root.join(&page);
    match input.action.as_str() {
        "create" => {
            if current.exists() {
                return api_error(StatusCode::CONFLICT, "a page with that name already exists");
            }
            let title = FsPath::new(&page)
                .file_stem()
                .and_then(|value| value.to_str())
                .unwrap_or("New page");
            let source = format!(
                "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>{title}</title></head><body><h1>{title}</h1><p>Start building your page.</p></body></html>"
            );
            match state
                .node
                .upload_site_file(&input.site_id, &page, source.into_bytes())
                .await
            {
                Ok(_) => Json(json!({ "ok": true, "page": page })).into_response(),
                Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
            }
        }
        "rename" => {
            if page.eq_ignore_ascii_case("index.html") {
                return api_error(StatusCode::BAD_REQUEST, "index.html cannot be renamed");
            }
            let Some(new_page) = input.new_page.as_deref() else {
                return api_error(StatusCode::BAD_REQUEST, "enter the new page name");
            };
            let new_page = match editor_page_name(new_page) {
                Ok(page) => page,
                Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
            };
            let destination = root.join(&new_page);
            if destination.exists() {
                return api_error(StatusCode::CONFLICT, "a page with that name already exists");
            }
            if !fs::symlink_metadata(&current).is_ok_and(|value| value.file_type().is_file()) {
                return api_error(StatusCode::NOT_FOUND, "page was not found");
            }
            match fs::rename(current, destination) {
                Ok(()) => Json(json!({ "ok": true, "page": new_page })).into_response(),
                Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
            }
        }
        "delete" => {
            if page.eq_ignore_ascii_case("index.html") {
                return api_error(StatusCode::BAD_REQUEST, "index.html cannot be deleted");
            }
            if !fs::symlink_metadata(&current).is_ok_and(|value| value.file_type().is_file()) {
                return api_error(StatusCode::NOT_FOUND, "page was not found");
            }
            match fs::remove_file(current) {
                Ok(()) => Json(json!({ "ok": true })).into_response(),
                Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
            }
        }
        _ => api_error(StatusCode::BAD_REQUEST, "unknown page action"),
    }
}

fn safe_site_folder(root: &FsPath, requested: &str) -> Result<PathBuf, String> {
    let requested = requested.trim().replace('\\', "/");
    let relative = requested.trim_matches('/');
    let mut path = PathBuf::new();
    if !relative.is_empty() && relative != "." {
        for component in FsPath::new(relative).components() {
            match component {
                Component::Normal(part) if !part.to_string_lossy().starts_with('.') => {
                    path.push(part)
                }
                _ => return Err("folder path is unsafe".to_owned()),
            }
        }
    }
    let resolved =
        fs::canonicalize(root.join(path)).map_err(|_| "folder was not found".to_owned())?;
    if !resolved.starts_with(root) || !resolved.is_dir() {
        return Err("folder path is unsafe".to_owned());
    }
    Ok(resolved)
}

fn folder_protection(directory: &FsPath) -> (bool, Option<String>) {
    let access = fs::read_to_string(directory.join(".htaccess")).unwrap_or_default();
    let mut basic = false;
    let mut user = None;
    for line in access.lines() {
        let parts = line.split_whitespace().collect::<Vec<_>>();
        if parts.len() >= 2 && parts[0].eq_ignore_ascii_case("AuthType") {
            basic = parts[1].eq_ignore_ascii_case("Basic");
        }
        if parts.len() >= 3
            && parts[0].eq_ignore_ascii_case("Require")
            && parts[1].eq_ignore_ascii_case("user")
        {
            user = Some(parts[2].to_owned());
        }
    }
    if basic && user.is_none() {
        user = fs::read_to_string(directory.join(".htpasswd"))
            .ok()
            .and_then(|contents| {
                contents
                    .lines()
                    .find_map(|line| line.split_once(':').map(|(name, _)| name.trim().to_owned()))
            })
            .filter(|name| !name.is_empty());
    }
    (basic, user)
}

fn collect_site_folders(
    root: &FsPath,
    current: &FsPath,
    depth: usize,
    output: &mut Vec<serde_json::Value>,
) {
    if output.len() >= 250 || depth > 8 {
        return;
    }
    let relative = current
        .strip_prefix(root)
        .unwrap_or(FsPath::new(""))
        .to_string_lossy()
        .replace('\\', "/");
    let (protected, user) = folder_protection(current);
    output.push(json!({ "path": relative, "protected": protected, "username": user }));
    let Ok(entries) = fs::read_dir(current) else {
        return;
    };
    let mut directories = entries
        .filter_map(|entry| entry.ok())
        .filter(|entry| {
            !entry.file_name().to_string_lossy().starts_with('.')
                && entry.file_type().is_ok_and(|kind| kind.is_dir())
        })
        .collect::<Vec<_>>();
    directories.sort_by_key(|entry| entry.file_name().to_string_lossy().to_ascii_lowercase());
    for entry in directories {
        collect_site_folders(root, &entry.path(), depth + 1, output);
    }
}

async fn list_site_folders(State(state): State<GatewayState>, headers: HeaderMap) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let Some(site_id) = required_header(&headers, "x-freedom-site") else {
        return api_error(StatusCode::BAD_REQUEST, "missing X-Freedom-Site header");
    };
    let root = match managed_site_root(&state.node, site_id).await {
        Ok(root) => root,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let mut folders = Vec::new();
    collect_site_folders(&root, &root, 0, &mut folders);
    Json(json!({ "ok": true, "folders": folders })).into_response()
}

fn remove_folder_auth_rules(source: &str) -> String {
    let mut output = Vec::new();
    let mut inside_managed = false;
    for line in source.lines() {
        let trimmed = line.trim();
        if trimmed == PROTECTION_BEGIN {
            inside_managed = true;
            continue;
        }
        if trimmed == PROTECTION_END {
            inside_managed = false;
            continue;
        }
        if inside_managed {
            continue;
        }
        let mut parts = trimmed.split_whitespace();
        let directive = parts.next().unwrap_or("");
        let argument = parts.next().unwrap_or("");
        if directive.eq_ignore_ascii_case("AuthType")
            || directive.eq_ignore_ascii_case("AuthName")
            || directive.eq_ignore_ascii_case("AuthUserFile")
            || (directive.eq_ignore_ascii_case("Require")
                && (argument.eq_ignore_ascii_case("valid-user")
                    || argument.eq_ignore_ascii_case("user")))
        {
            continue;
        }
        output.push(line);
    }
    output.join("\n").trim().to_owned()
}

#[derive(Deserialize)]
struct SiteProtectionInput {
    site_id: String,
    folder: String,
    enabled: bool,
    username: Option<String>,
    password: Option<String>,
}

async fn set_site_protection(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<SiteProtectionInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    let root = match managed_site_root(&state.node, &input.site_id).await {
        Ok(root) => root,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let folder = match safe_site_folder(&root, &input.folder) {
        Ok(folder) => folder,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error),
    };
    let access_path = folder.join(".htaccess");
    let password_path = folder.join(".htpasswd");
    let existing = fs::read_to_string(&access_path).unwrap_or_default();
    let remaining = remove_folder_auth_rules(&existing);

    if !input.enabled {
        let access_result = if remaining.is_empty() {
            if access_path.exists() {
                fs::remove_file(&access_path)
            } else {
                Ok(())
            }
        } else {
            fs::write(&access_path, format!("{remaining}\n"))
        };
        if let Err(error) = access_result {
            return api_error(StatusCode::BAD_REQUEST, &error.to_string());
        }
        if password_path.exists()
            && let Err(error) = fs::remove_file(&password_path)
        {
            return api_error(StatusCode::BAD_REQUEST, &error.to_string());
        }
        return Json(json!({ "ok": true, "enabled": false })).into_response();
    }

    let username = input.username.unwrap_or_default().trim().to_owned();
    if username.is_empty()
        || username.len() > 64
        || !username.chars().all(|character| {
            character.is_ascii_alphanumeric() || matches!(character, '_' | '-' | '.' | '@')
        })
    {
        return api_error(
            StatusCode::BAD_REQUEST,
            "username may use letters, numbers, dots, @, hyphens and underscores",
        );
    }
    let password = input.password.unwrap_or_default();
    if password.len() < 8 || password.len() > 72 {
        return api_error(
            StatusCode::BAD_REQUEST,
            "password must be 8 to 72 bytes long",
        );
    }
    let hash = match bcrypt::hash(password, 10) {
        Ok(hash) => hash,
        Err(error) => return api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    };
    let mut access = remaining;
    if !access.is_empty() {
        access.push_str("\n\n");
    }
    access.push_str(&format!(
        "{PROTECTION_BEGIN}\nAuthType Basic\nAuthName \"Freedom protected folder\"\nAuthUserFile .htpasswd\nRequire user {username}\n{PROTECTION_END}\n"
    ));
    if let Err(error) = fs::write(&password_path, format!("{username}:{hash}\n"))
        .and_then(|()| fs::write(&access_path, access))
    {
        return api_error(StatusCode::BAD_REQUEST, &error.to_string());
    }
    Json(json!({ "ok": true, "enabled": true, "username": username })).into_response()
}

fn required_header<'a>(headers: &'a HeaderMap, name: &str) -> Option<&'a str> {
    headers
        .get(name)?
        .to_str()
        .ok()
        .filter(|value| !value.is_empty())
}

#[derive(Deserialize)]
struct SiteStateInput {
    site_id: String,
    enabled: bool,
}

async fn set_site_state(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<SiteStateInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state
        .node
        .set_site_enabled(&input.site_id, input.enabled)
        .await
    {
        Ok(site) => Json(json!({ "ok": true, "site": site })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

#[derive(Deserialize)]
struct ContactInput {
    peer_id: String,
    alias: Option<String>,
    trust_state: String,
    muted: bool,
}

async fn set_contact(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<ContactInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state
        .node
        .set_contact(
            &input.peer_id,
            input.alias.as_deref(),
            &input.trust_state,
            input.muted,
        )
        .await
    {
        Ok(contact) => Json(json!({ "ok": true, "contact": contact })).into_response(),
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

#[derive(Deserialize)]
struct ProfileInput {
    display_name: String,
}

async fn update_profile(
    State(state): State<GatewayState>,
    headers: HeaderMap,
    Json(input): Json<ProfileInput>,
) -> Response {
    if !authorized(&state, &headers) {
        return StatusCode::UNAUTHORIZED.into_response();
    }
    match state.node.update_display_name(&input.display_name).await {
        Ok(display_name) => {
            Json(json!({ "ok": true, "display_name": display_name })).into_response()
        }
        Err(error) => api_error(StatusCode::BAD_REQUEST, &error.to_string()),
    }
}

fn authorized(state: &GatewayState, headers: &HeaderMap) -> bool {
    capability_authorized(state, headers) && !state.app_lock.is_locked()
}

fn capability_authorized(state: &GatewayState, headers: &HeaderMap) -> bool {
    let Some(capability) = &state.capability else {
        return false;
    };
    headers
        .get(header::AUTHORIZATION)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.strip_prefix("Bearer "))
        .is_some_and(|value| value.as_bytes() == capability.as_bytes())
}

fn api_error(status: StatusCode, message: &str) -> Response {
    (status, Json(json!({ "ok": false, "error": message }))).into_response()
}

fn random_capability() -> String {
    let mut bytes = [0_u8; 32];
    rand::rng().fill_bytes(&mut bytes);
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use axum::http::Request;
    use freedom_core::{NodeConfig, spawn_node};
    use tower::ServiceExt;

    #[test]
    fn public_gateway_forwards_only_bounded_basic_authorization() {
        let mut headers = HeaderMap::new();
        headers.insert(
            header::AUTHORIZATION,
            "Basic dXNlcjpwYXNzd29yZA==".parse().unwrap(),
        );
        let request = site_request(Method::GET, None, &headers, Bytes::new());
        assert_eq!(
            request.authorization.as_deref(),
            Some("Basic dXNlcjpwYXNzd29yZA==")
        );

        headers.insert(header::AUTHORIZATION, "Bearer secret".parse().unwrap());
        let request = site_request(Method::GET, None, &headers, Bytes::new());
        assert_eq!(request.authorization, None);
    }

    #[test]
    fn site_requests_forward_browser_state_and_bound_open_ranges() {
        let mut headers = HeaderMap::new();
        headers.insert(header::COOKIE, "PHPSESSID=session-1".parse().unwrap());
        headers.insert(header::RANGE, "bytes=100-".parse().unwrap());
        headers.insert("x-requested-with", "XMLHttpRequest".parse().unwrap());
        headers.insert("x-untrusted-header", "not-forwarded".parse().unwrap());
        let request = site_request(Method::GET, None, &headers, Bytes::new());
        assert!(request.headers.contains(&SiteHeader {
            name: "cookie".into(),
            value: "PHPSESSID=session-1".into(),
        }));
        assert!(request.headers.contains(&SiteHeader {
            name: "range".into(),
            value: format!("bytes=100-{}", 100 + MAX_SITE_RANGE_BYTES - 1),
        }));
        assert!(request.headers.contains(&SiteHeader {
            name: "x-requested-with".into(),
            value: "XMLHttpRequest".into(),
        }));
        assert!(
            !request
                .headers
                .iter()
                .any(|header| header.name == "x-untrusted-header")
        );
    }

    #[test]
    fn retries_a_bounded_range_when_legacy_php_rejects_an_end_past_eof() {
        let mut headers = HeaderMap::new();
        headers.insert(header::RANGE, "bytes=0-".parse().unwrap());
        let request = site_request(Method::GET, None, &headers, Bytes::new());
        let response_headers = vec![SiteHeader {
            name: "content-range".into(),
            value: "bytes */4071168".into(),
        }];
        let retry = retry_unsatisfied_range(
            &request,
            StatusCode::RANGE_NOT_SATISFIABLE.as_u16(),
            &response_headers,
        )
        .unwrap();
        assert!(retry.headers.contains(&SiteHeader {
            name: "range".into(),
            value: "bytes=0-4071167".into(),
        }));
        assert!(retry_unsatisfied_range(&request, 206, &response_headers).is_none());
    }

    #[test]
    fn html_pages_receive_the_navigation_bridge_once() {
        let mut body = b"<!doctype html><html><body><h1>Page</h1></body></html>".to_vec();
        assert!(inject_site_navigation_bridge(&mut body));
        let html = String::from_utf8(body).unwrap();
        assert!(html.contains("id=\"freedom-navigation-bridge\""));
        assert!(html.contains("freedomLocation"));
        assert!(html.contains("freedomNavigate"));
        assert!(html.contains("freedomNavigationToken"));
        let mut body = html.into_bytes();
        assert!(!inject_site_navigation_bridge(&mut body));
        assert_eq!(
            String::from_utf8(body)
                .unwrap()
                .matches("id=\"freedom-navigation-bridge\"")
                .count(),
            1
        );
    }

    #[test]
    fn network_fetch_resolves_signed_names_aliases_and_subpages() {
        let names = vec![NameRecord {
            hostname: "mail.freedom.net".into(),
            record_type: "mail".into(),
            peer_id: Some("12D3KooWTest".into()),
            site_id: Some("freedom".into()),
            path: "/mail/".into(),
            official: true,
            active: true,
        }];
        let named = resolve_network_location(
            "free://mail.freedom.net/index.php?view=inbox#message",
            &names,
        )
        .unwrap();
        assert_eq!(named.peer_id, "12D3KooWTest");
        assert_eq!(named.site_id, "freedom");
        assert_eq!(named.path, "mail/index.php");
        assert_eq!(named.query, "view=inbox");

        let direct = resolve_network_location(
            "freedom://12D3KooWDirect/freecode/docs/start.html?q=rust",
            &names,
        )
        .unwrap();
        assert_eq!(direct.peer_id, "12D3KooWDirect");
        assert_eq!(direct.site_id, "freecode");
        assert_eq!(direct.path, "docs/start.html");
        assert_eq!(direct.query, "q=rust");
        assert!(resolve_network_location("http://example.com", &names).is_err());
    }

    #[test]
    fn isolated_site_origin_round_trips_peer_and_site_identity() {
        fn encode_base32(value: &[u8]) -> String {
            let mut output = String::new();
            let mut buffer = 0_u32;
            let mut bits = 0_u8;
            for byte in value {
                buffer = (buffer << 8) | u32::from(*byte);
                bits += 8;
                while bits >= 5 {
                    bits -= 5;
                    output.push(
                        b"abcdefghijklmnopqrstuvwxyz234567"[((buffer >> bits) & 31) as usize]
                            as char,
                    );
                    buffer &= (1_u32 << bits) - 1;
                }
            }
            if bits > 0 {
                output.push(
                    b"abcdefghijklmnopqrstuvwxyz234567"[((buffer << (5 - bits)) & 31) as usize]
                        as char,
                );
            }
            output
        }

        let peer = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id()
            .to_string();
        let site = "welcome";
        let encoded = encode_base32(format!("{peer}\0{site}").as_bytes());
        let mut labels = vec![format!("f-{}", &encoded[..encoded.len().min(61)])];
        for chunk in encoded.as_bytes()[encoded.len().min(61)..].chunks(63) {
            labels.push(String::from_utf8(chunk.to_vec()).unwrap());
        }
        let host = format!("{}.freedom.localhost", labels.join("."));
        assert_eq!(decode_site_origin(&host), Some((peer, site.to_owned())));
        assert!(labels.iter().all(|label| label.len() <= 63));

        let peer = "12D3KooWNamed";
        let site = "freedom";
        let encoded = encode_base32(format!("{peer}\0{site}\0mail.freedom.net").as_bytes());
        let mut labels = vec![format!("f-{}", &encoded[..encoded.len().min(61)])];
        for chunk in encoded.as_bytes()[encoded.len().min(61)..].chunks(63) {
            labels.push(String::from_utf8(chunk.to_vec()).unwrap());
        }
        let host = format!("{}.freedom.localhost", labels.join("."));
        assert_eq!(
            decode_site_origin(&host),
            Some((peer.to_owned(), site.to_owned()))
        );
    }

    #[test]
    fn offline_site_page_is_clear_and_does_not_reflect_html() {
        let html = offline_site_html("<games>");
        assert!(html.contains("Site currently offline"));
        assert!(html.contains("Please try again later"));
        assert!(html.contains("&lt;games&gt;"));
        assert!(!html.contains("<games>"));
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn control_api_creates_managed_site_and_uploads_file() {
        let data = tempfile::tempdir().unwrap();
        let node = spawn_node(NodeConfig {
            data_dir: data.path().to_owned(),
            htdocs_dir: None,
            php_cgi: None,
            enable_mdns: false,
            display_name: "Site owner".into(),
            listen_port: 0,
            role: freedom_core::ApplicationRole::Node,
            authority_manifest: None,
            trusted_authority_signer: None,
            internet: freedom_core::InternetConfig::default(),
        })
        .await
        .unwrap();
        let capability = "test-capability";
        let app = control_router(GatewayState {
            node: node.clone(),
            app_lock: AppLock::load(data.path()).unwrap(),
            capability: Some(Arc::from(capability)),
            public_origin: Arc::from("http://127.0.0.1:8787"),
            initial_address: Arc::from("freedom://freedom.net/"),
        });

        let create_body = br#"{"site_id":"home","name":"My Home"}"#;
        let created = app
            .clone()
            .oneshot(
                Request::post("/api/sites")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(create_body.as_slice()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(created.status(), StatusCode::OK);

        let body = b"<!doctype html><h1>Uploaded in Freedom</h1>";
        let uploaded = app
            .clone()
            .oneshot(
                Request::post("/api/site-files")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/octet-stream")
                    .header("X-Freedom-Site", "home")
                    .header("X-Freedom-Path", "index.html")
                    .body(Body::from(body.as_slice()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(uploaded.status(), StatusCode::OK);

        let file = node
            .fetch_site(&node.local_peer_id().to_string(), "home", "")
            .await
            .unwrap();
        assert_eq!(file.body, body);
        assert!(data.path().join("htdocs/home/index.html").is_file());

        let pages = app
            .clone()
            .oneshot(
                Request::get("/api/site-pages")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header("X-Freedom-Site", "home")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(pages.status(), StatusCode::OK);

        let read_page = app
            .clone()
            .oneshot(
                Request::get("/api/site-page")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header("X-Freedom-Site", "home")
                    .header("X-Freedom-Page", "index.html")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(read_page.status(), StatusCode::OK);

        let create_page = app
            .clone()
            .oneshot(
                Request::post("/api/site-pages")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        r#"{"site_id":"home","action":"create","page":"about.html"}"#,
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(create_page.status(), StatusCode::OK);
        assert!(data.path().join("htdocs/home/about.html").is_file());

        let rename_page = app
            .clone()
            .oneshot(
                Request::post("/api/site-pages")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        r#"{"site_id":"home","action":"rename","page":"about.html","new_page":"links.html"}"#,
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(rename_page.status(), StatusCode::OK);
        assert!(data.path().join("htdocs/home/links.html").is_file());
        assert!(!data.path().join("htdocs/home/about.html").exists());

        let protected_folder = data.path().join("htdocs/home/private");
        fs::create_dir(&protected_folder).unwrap();
        fs::write(
            protected_folder.join(".htaccess"),
            "<FilesMatch \\.sqlite$>\nRequire all denied\n</FilesMatch>\n",
        )
        .unwrap();
        let protect = app
            .clone()
            .oneshot(
                Request::post("/api/site-protection")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        r#"{"site_id":"home","folder":"private","enabled":true,"username":"owner","password":"correct horse battery staple"}"#,
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(protect.status(), StatusCode::OK);
        let access = fs::read_to_string(protected_folder.join(".htaccess")).unwrap();
        assert!(access.contains("Require all denied"));
        assert!(access.contains(PROTECTION_BEGIN));
        let password = fs::read_to_string(protected_folder.join(".htpasswd")).unwrap();
        let hash = password.trim().strip_prefix("owner:").unwrap();
        assert!(bcrypt::verify("correct horse battery staple", hash).unwrap());

        let unprotect = app
            .clone()
            .oneshot(
                Request::post("/api/site-protection")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        r#"{"site_id":"home","folder":"private","enabled":false}"#,
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(unprotect.status(), StatusCode::OK);
        let access = fs::read_to_string(protected_folder.join(".htaccess")).unwrap();
        assert!(access.contains("Require all denied"));
        assert!(!access.contains(PROTECTION_BEGIN));
        assert!(!protected_folder.join(".htpasswd").exists());

        let delete_page = app
            .clone()
            .oneshot(
                Request::post("/api/site-pages")
                    .header(header::AUTHORIZATION, format!("Bearer {capability}"))
                    .header(header::CONTENT_TYPE, "application/json")
                    .body(Body::from(
                        r#"{"site_id":"home","action":"delete","page":"links.html"}"#,
                    ))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(delete_page.status(), StatusCode::OK);
        assert!(!data.path().join("htdocs/home/links.html").exists());

        let unauthorized = app
            .oneshot(
                Request::post("/api/site-files")
                    .body(Body::empty())
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(unauthorized.status(), StatusCode::UNAUTHORIZED);
        node.shutdown().await.unwrap();
    }
}
