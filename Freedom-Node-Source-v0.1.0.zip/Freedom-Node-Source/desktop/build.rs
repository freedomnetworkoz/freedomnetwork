use std::{env, path::PathBuf, process::Command};

fn main() {
    println!("cargo:rerun-if-changed=resources/freedom.rc");
    println!("cargo:rerun-if-changed=resources/freedom.manifest");
    if env::var("CARGO_CFG_WINDOWS").is_err() {
        return;
    }

    let manifest_dir = PathBuf::from(env::var_os("CARGO_MANIFEST_DIR").expect("manifest dir"));
    let output =
        PathBuf::from(env::var_os("OUT_DIR").expect("output dir")).join("freedom-resources.o");
    let status = Command::new("x86_64-w64-mingw32-windres.exe")
        .current_dir(&manifest_dir)
        .args([
            "--input",
            "resources/freedom.rc",
            "--output-format",
            "coff",
            "--output",
        ])
        .arg(&output)
        .status()
        .expect("run x86_64-w64-mingw32-windres.exe");
    assert!(status.success(), "windres failed with {status}");
    println!("cargo:rustc-link-arg-bin=Freedom={}", output.display());
}
