# Third-party Rust dependencies

Generated from `cargo metadata --locked --filter-platform x86_64-pc-windows-gnullvm` on 1 October 2026. Cargo reported a licence expression for every resolved third-party package. `Cargo.lock` is the authoritative version lock.

This inventory records upstream package declarations; it is not an independent legal conclusion. Copyright and licence texts remain those supplied by each dependency. The packaged PHP runtime carries its own `license.txt` and redistribution notices. Microsoft WebView2 components remain subject to Microsoft terms.

| Package | Version | Declared licence | Upstream |
|---|---:|---|---|
| aead | 0.5.2 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/traits |
| aes | 0.8.4 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/block-ciphers |
| aes-gcm | 0.10.3 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/AEADs |
| aho-corasick | 1.1.5 | `Unlicense OR MIT` | https://github.com/BurntSushi/aho-corasick |
| anyhow | 1.0.104 | `MIT OR Apache-2.0` | https://github.com/dtolnay/anyhow |
| arrayref | 0.3.9 | `BSD-2-Clause` | https://github.com/droundy/arrayref |
| asn1-rs | 0.7.2 | `MIT OR Apache-2.0` | https://github.com/rusticata/asn1-rs.git |
| asn1-rs-derive | 0.6.0 | `MIT OR Apache-2.0` | https://github.com/rusticata/asn1-rs.git |
| asn1-rs-impl | 0.2.0 | `MIT/Apache-2.0` | https://github.com/rusticata/asn1-rs.git |
| async-trait | 0.1.92 | `MIT OR Apache-2.0` | https://github.com/dtolnay/async-trait |
| asynchronous-codec | 0.7.0 | `MIT` | https://github.com/mxinden/asynchronous-codec |
| atomic-waker | 1.1.2 | `Apache-2.0 OR MIT` | https://github.com/smol-rs/atomic-waker |
| attohttpc | 0.30.1 | `MPL-2.0` | https://github.com/sbstp/attohttpc |
| autocfg | 1.5.1 | `Apache-2.0 OR MIT` | https://github.com/cuviper/autocfg |
| axum | 0.8.9 | `MIT` | https://github.com/tokio-rs/axum |
| axum-core | 0.5.6 | `MIT` | https://github.com/tokio-rs/axum |
| base-x | 0.2.11 | `MIT` | https://github.com/OrKoN/base-x-rs |
| base256emoji | 1.0.2 | `MIT` | https://github.com/Jorropo/base256emoji/ |
| base45 | 3.2.0 | `MIT` | https://github.com/opendevtools/base45 |
| base64 | 0.22.1 | `MIT OR Apache-2.0` | https://github.com/marshallpierce/rust-base64 |
| base64ct | 1.8.3 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/formats |
| bcrypt | 0.17.1 | `MIT` | https://github.com/Keats/rust-bcrypt |
| bitflags | 2.13.1 | `MIT OR Apache-2.0` | https://github.com/bitflags/bitflags |
| blake2 | 0.10.6 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/hashes |
| block-buffer | 0.10.4 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/utils |
| blowfish | 0.9.1 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/block-ciphers |
| bs58 | 0.5.1 | `MIT/Apache-2.0` | https://github.com/Nullus157/bs58-rs |
| byteorder | 1.5.0 | `Unlicense OR MIT` | https://github.com/BurntSushi/byteorder |
| bytes | 1.12.1 | `MIT` | https://github.com/tokio-rs/bytes |
| cbor4ii | 0.3.3 | `MIT` | https://github.com/quininer/cbor4ii |
| cc | 1.4.5 | `MIT OR Apache-2.0` | https://github.com/rust-lang/cc-rs |
| cfg_aliases | 0.2.2 | `MIT` | https://github.com/katharostech/cfg_aliases |
| cfg-if | 1.0.4 | `MIT OR Apache-2.0` | https://github.com/rust-lang/cfg-if |
| chacha20 | 0.10.2 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/stream-ciphers |
| chacha20 | 0.9.1 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/stream-ciphers |
| chacha20poly1305 | 0.10.1 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/AEADs/tree/master/chacha20poly1305 |
| cipher | 0.4.4 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/traits |
| const-oid | 0.9.6 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/formats/tree/master/const-oid |
| const-str | 0.4.3 | `MIT` | https://github.com/Nugine/const-str |
| cookie | 0.18.2 | `MIT OR Apache-2.0` | https://github.com/SergioBenitez/cookie-rs |
| cpufeatures | 0.2.17 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/utils |
| cpufeatures | 0.3.1 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/utils |
| critical-section | 1.2.0 | `MIT OR Apache-2.0` | https://github.com/rust-embedded/critical-section |
| crossbeam-channel | 0.5.17 | `MIT OR Apache-2.0` | https://github.com/crossbeam-rs/crossbeam |
| crossbeam-epoch | 0.9.21 | `MIT OR Apache-2.0` | https://github.com/crossbeam-rs/crossbeam |
| crossbeam-utils | 0.8.23 | `MIT OR Apache-2.0` | https://github.com/crossbeam-rs/crossbeam |
| crunchy | 0.2.4 | `MIT` | https://github.com/eira-fransham/crunchy |
| crypto-common | 0.1.7 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/traits |
| ctr | 0.9.2 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/block-modes |
| cursor-icon | 1.2.0 | `MIT OR Apache-2.0 OR Zlib` | https://github.com/rust-windowing/cursor-icon |
| curve25519-dalek | 4.1.3 | `BSD-3-Clause` | https://github.com/dalek-cryptography/curve25519-dalek/tree/main/curve25519-dalek |
| curve25519-dalek-derive | 0.1.1 | `MIT/Apache-2.0` | https://github.com/dalek-cryptography/curve25519-dalek |
| data-encoding | 2.11.1 | `MIT` | https://github.com/ia0/data-encoding |
| data-encoding-macro | 0.1.21 | `MIT` | https://github.com/ia0/data-encoding |
| data-encoding-macro-internal | 0.1.19 | `MIT` | https://github.com/ia0/data-encoding |
| der | 0.7.10 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/formats/tree/master/der |
| der-parser | 10.0.0 | `MIT OR Apache-2.0` | https://github.com/rusticata/der-parser.git |
| deranged | 0.5.8 | `MIT OR Apache-2.0` | https://github.com/jhpratt/deranged |
| digest | 0.10.7 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/traits |
| directories | 6.0.0 | `MIT OR Apache-2.0` | https://github.com/soc/directories-rs |
| dirs-sys | 0.5.0 | `MIT OR Apache-2.0` | https://github.com/dirs-dev/dirs-sys-rs |
| displaydoc | 0.2.7 | `MIT OR Apache-2.0` | https://github.com/yaahc/displaydoc |
| dpi | 0.1.2 | `Apache-2.0 AND MIT` | https://github.com/rust-windowing/winit |
| dtoa | 1.0.11 | `MIT OR Apache-2.0` | https://github.com/dtolnay/dtoa |
| dunce | 1.0.5 | `CC0-1.0 OR MIT-0 OR Apache-2.0` | https://gitlab.com/kornelski/dunce |
| ed25519 | 2.2.3 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/signatures/tree/master/ed25519 |
| ed25519-dalek | 2.2.0 | `BSD-3-Clause` | https://github.com/dalek-cryptography/curve25519-dalek/tree/main/ed25519-dalek |
| either | 1.18.0 | `MIT OR Apache-2.0` | https://github.com/rayon-rs/either |
| enum-as-inner | 0.6.1 | `MIT/Apache-2.0` | https://github.com/bluejekyll/enum-as-inner |
| equivalent | 1.0.2 | `Apache-2.0 OR MIT` | https://github.com/indexmap-rs/equivalent |
| fallible-iterator | 0.3.0 | `MIT/Apache-2.0` | https://github.com/sfackler/rust-fallible-iterator |
| fallible-streaming-iterator | 0.1.9 | `MIT/Apache-2.0` | https://github.com/sfackler/fallible-streaming-iterator |
| fastbloom | 0.17.0 | `MIT OR Apache-2.0` | https://github.com/tomtomwombat/fastbloom/ |
| fastrand | 2.5.0 | `Apache-2.0 OR MIT` | https://github.com/smol-rs/fastrand |
| find-msvc-tools | 0.1.12 | `MIT OR Apache-2.0` | https://github.com/rust-lang/cc-rs |
| fnv | 1.0.7 | `Apache-2.0 / MIT` | https://github.com/servo/rust-fnv |
| foldhash | 0.1.5 | `Zlib` | https://github.com/orlp/foldhash |
| foldhash | 0.2.0 | `Zlib` | https://github.com/orlp/foldhash |
| form_urlencoded | 1.2.2 | `MIT OR Apache-2.0` | https://github.com/servo/rust-url |
| futures | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-bounded | 0.2.4 | `MIT` | https://github.com/thomaseizinger/rust-futures-bounded |
| futures-channel | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-core | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-executor | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-io | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-macro | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-rustls | 0.26.0 | `MIT/Apache-2.0` | https://github.com/quininer/futures-rustls |
| futures-sink | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-task | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| futures-timer | 3.0.4 | `MIT/Apache-2.0` | https://github.com/async-rs/futures-timer |
| futures-util | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/futures-rs |
| generic-array | 0.14.7 | `MIT` | https://github.com/fizyk20/generic-array.git |
| getrandom | 0.2.17 | `MIT OR Apache-2.0` | https://github.com/rust-random/getrandom |
| getrandom | 0.3.4 | `MIT OR Apache-2.0` | https://github.com/rust-random/getrandom |
| getrandom | 0.4.3 | `MIT OR Apache-2.0` | https://github.com/rust-random/getrandom |
| ghash | 0.5.1 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/universal-hashes |
| h2 | 0.4.19 | `MIT` | https://github.com/hyperium/h2 |
| hashbrown | 0.15.5 | `MIT OR Apache-2.0` | https://github.com/rust-lang/hashbrown |
| hashbrown | 0.17.1 | `MIT OR Apache-2.0` | https://github.com/rust-lang/hashbrown |
| hashlink | 0.10.0 | `MIT OR Apache-2.0` | https://github.com/kyren/hashlink |
| hashlink | 0.12.2 | `MIT OR Apache-2.0` | https://github.com/djc/hashlink |
| heck | 0.5.0 | `MIT OR Apache-2.0` | https://github.com/withoutboats/heck |
| hex | 0.4.3 | `MIT OR Apache-2.0` | https://github.com/KokaKiwi/rust-hex |
| hickory-proto | 0.25.2 | `MIT OR Apache-2.0` | https://github.com/hickory-dns/hickory-dns |
| hickory-resolver | 0.25.2 | `MIT OR Apache-2.0` | https://github.com/hickory-dns/hickory-dns |
| hkdf | 0.12.4 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/KDFs/ |
| hmac | 0.12.1 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/MACs |
| http | 1.5.0 | `MIT OR Apache-2.0` | https://github.com/hyperium/http |
| http-body | 1.1.0 | `MIT` | https://github.com/hyperium/http-body |
| http-body-util | 0.1.5 | `MIT` | https://github.com/hyperium/http-body |
| httparse | 1.10.1 | `MIT OR Apache-2.0` | https://github.com/seanmonstar/httparse |
| httpdate | 1.0.3 | `MIT OR Apache-2.0` | https://github.com/pyfisch/httpdate |
| hyper | 1.11.1 | `MIT` | https://github.com/hyperium/hyper |
| hyper-util | 0.1.20 | `MIT` | https://github.com/hyperium/hyper-util |
| icu_collections | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_locale_core | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_normalizer | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_normalizer_data | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_properties | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_properties_data | 2.3.0 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| icu_provider | 2.3.1 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| idna | 1.1.0 | `MIT OR Apache-2.0` | https://github.com/servo/rust-url/ |
| idna_adapter | 1.2.2 | `Apache-2.0 OR MIT` | https://github.com/hsivonen/idna_adapter |
| if-addrs | 0.15.0 | `MIT OR BSD-3-Clause` | https://github.com/messense/if-addrs |
| if-watch | 3.2.2 | `MIT OR Apache-2.0` | https://github.com/libp2p/if-watch |
| igd-next | 0.16.2 | `MIT` | https://github.com/dariusc93/rust-igd |
| indexmap | 2.14.2 | `Apache-2.0 OR MIT` | https://github.com/indexmap-rs/indexmap |
| inout | 0.1.4 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/utils |
| ipconfig | 0.3.4 | `MIT/Apache-2.0` | https://github.com/liranringel/ipconfig |
| ipnet | 2.12.2 | `MIT OR Apache-2.0` | https://github.com/krisprice/ipnet |
| itertools | 0.14.0 | `MIT OR Apache-2.0` | https://github.com/rust-itertools/itertools |
| itoa | 1.0.18 | `MIT OR Apache-2.0` | https://github.com/dtolnay/itoa |
| jobserver | 0.1.35 | `MIT OR Apache-2.0` | https://github.com/rust-lang/jobserver-rs |
| lazy_static | 1.5.0 | `MIT OR Apache-2.0` | https://github.com/rust-lang-nursery/lazy-static.rs |
| libc | 0.2.189 | `MIT OR Apache-2.0` | https://github.com/rust-lang/libc |
| libm | 0.2.16 | `MIT` | https://github.com/rust-lang/compiler-builtins |
| libp2p | 0.56.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-allow-block-list | 0.6.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-autonat | 0.15.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-connection-limits | 0.6.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-core | 0.43.2 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-dcutr | 0.14.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-dns | 0.44.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-identify | 0.47.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-identity | 0.2.14 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-kad | 0.48.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-mdns | 0.48.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-metrics | 0.17.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-noise | 0.46.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-ping | 0.47.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-quic | 0.13.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-relay | 0.21.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-request-response | 0.29.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-swarm | 0.47.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-swarm-derive | 0.35.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-tcp | 0.44.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-tls | 0.6.2 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-upnp | 0.5.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libp2p-yamux | 0.47.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| libsqlite3-sys | 0.38.2 | `MIT` | https://github.com/rusqlite/rusqlite |
| litemap | 0.8.3 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| lock_api | 0.4.14 | `MIT OR Apache-2.0` | https://github.com/Amanieu/parking_lot |
| log | 0.4.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/log |
| lru-slab | 0.1.2 | `MIT OR Apache-2.0 OR Zlib` | https://github.com/Ralith/lru-slab |
| match-lookup | 0.1.3 | `MIT` | https://github.com/mriise/smol-base-x |
| matchers | 0.2.0 | `MIT` | https://github.com/hawkw/matchers |
| matchit | 0.8.4 | `MIT AND BSD-3-Clause` | https://github.com/ibraheemdev/matchit |
| md-5 | 0.10.6 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/hashes |
| memchr | 2.8.3 | `Unlicense OR MIT` | https://github.com/BurntSushi/memchr |
| mime | 0.3.17 | `MIT OR Apache-2.0` | https://github.com/hyperium/mime |
| mime_guess | 2.0.5 | `MIT` | https://github.com/abonander/mime_guess |
| minimal-lexical | 0.2.1 | `MIT/Apache-2.0` | https://github.com/Alexhuszagh/minimal-lexical |
| mio | 1.2.3 | `MIT` | https://github.com/tokio-rs/mio |
| moka | 0.12.16 | `(MIT OR Apache-2.0) AND Apache-2.0` | https://github.com/moka-rs/moka |
| multiaddr | 0.18.2 | `MIT` | https://github.com/multiformats/rust-multiaddr |
| multibase | 0.9.3 | `MIT` | https://github.com/multiformats/rust-multibase |
| multihash | 0.19.5 | `MIT` | https://github.com/multiformats/rust-multihash |
| multistream-select | 0.13.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| nohash-hasher | 0.2.0 | `Apache-2.0 OR MIT` | https://github.com/paritytech/nohash-hasher |
| nom | 7.1.3 | `MIT` | https://github.com/Geal/nom |
| nu-ansi-term | 0.50.3 | `MIT` | https://github.com/nushell/nu-ansi-term |
| num-bigint | 0.4.8 | `MIT OR Apache-2.0` | https://github.com/rust-num/num-bigint |
| num-conv | 0.2.2 | `MIT OR Apache-2.0` | https://github.com/jhpratt/num-conv |
| num-integer | 0.1.47 | `MIT OR Apache-2.0` | https://github.com/rust-num/num-integer |
| num-traits | 0.2.19 | `MIT OR Apache-2.0` | https://github.com/rust-num/num-traits |
| oid-registry | 0.8.1 | `MIT OR Apache-2.0` | https://github.com/rusticata/oid-registry.git |
| once_cell | 1.21.4 | `MIT OR Apache-2.0` | https://github.com/matklad/once_cell |
| opaque-debug | 0.3.1 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/utils |
| option-ext | 0.2.0 | `MPL-2.0` | https://github.com/soc/option-ext.git |
| parking_lot | 0.12.5 | `MIT OR Apache-2.0` | https://github.com/Amanieu/parking_lot |
| parking_lot_core | 0.9.12 | `MIT OR Apache-2.0` | https://github.com/Amanieu/parking_lot |
| pem | 3.0.6 | `MIT` | https://github.com/jcreekmore/pem-rs.git |
| percent-encoding | 2.3.2 | `MIT OR Apache-2.0` | https://github.com/servo/rust-url/ |
| pin-project | 1.1.13 | `Apache-2.0 OR MIT` | https://github.com/taiki-e/pin-project |
| pin-project-internal | 1.1.13 | `Apache-2.0 OR MIT` | https://github.com/taiki-e/pin-project |
| pin-project-lite | 0.2.17 | `Apache-2.0 OR MIT` | https://github.com/taiki-e/pin-project-lite |
| pkcs8 | 0.10.2 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/formats/tree/master/pkcs8 |
| pkg-config | 0.3.34 | `MIT OR Apache-2.0` | https://github.com/rust-lang/pkg-config-rs |
| poly1305 | 0.8.0 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/universal-hashes |
| polyval | 0.6.2 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/universal-hashes |
| portable-atomic | 1.15.0 | `Apache-2.0 OR MIT` | https://github.com/taiki-e/portable-atomic |
| potential_utf | 0.1.6 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| powerfmt | 0.2.0 | `MIT OR Apache-2.0` | https://github.com/jhpratt/powerfmt |
| ppv-lite86 | 0.2.21 | `MIT OR Apache-2.0` | https://github.com/cryptocorrosion/cryptocorrosion |
| proc-macro2 | 1.0.107 | `MIT OR Apache-2.0` | https://github.com/dtolnay/proc-macro2 |
| prometheus-client | 0.23.1 | `Apache-2.0 OR MIT` | https://github.com/prometheus/client_rust |
| prometheus-client-derive-encode | 0.4.2 | `Apache-2.0 OR MIT` | https://github.com/prometheus/client_rust |
| prost | 0.14.4 | `Apache-2.0` | https://github.com/tokio-rs/prost |
| prost-derive | 0.14.4 | `Apache-2.0` | https://github.com/tokio-rs/prost |
| quick-protobuf | 0.8.1 | `MIT` | https://github.com/tafia/quick-protobuf |
| quick-protobuf-codec | 0.3.1 | `MIT` | https://github.com/libp2p/rust-libp2p |
| quinn | 0.11.11 | `MIT OR Apache-2.0` | https://github.com/quinn-rs/quinn |
| quinn-proto | 0.11.17 | `MIT OR Apache-2.0` | https://github.com/quinn-rs/quinn |
| quinn-udp | 0.5.15 | `MIT OR Apache-2.0` | https://github.com/quinn-rs/quinn |
| quote | 1.0.47 | `MIT OR Apache-2.0` | https://github.com/dtolnay/quote |
| rand | 0.10.2 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand | 0.8.8 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand | 0.9.5 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand_chacha | 0.3.1 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand_chacha | 0.9.0 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand_core | 0.10.1 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand_core |
| rand_core | 0.6.4 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand_core | 0.9.5 | `MIT OR Apache-2.0` | https://github.com/rust-random/rand |
| rand_pcg | 0.10.2 | `MIT OR Apache-2.0` | https://github.com/rust-random/rngs |
| raw-window-handle | 0.6.2 | `MIT OR Apache-2.0 OR Zlib` | https://github.com/rust-windowing/raw-window-handle |
| rcgen | 0.13.2 | `MIT OR Apache-2.0` | https://github.com/rustls/rcgen |
| regex-automata | 0.4.18 | `MIT OR Apache-2.0` | https://github.com/rust-lang/regex |
| regex-syntax | 0.8.11 | `MIT OR Apache-2.0` | https://github.com/rust-lang/regex |
| resolv-conf | 0.7.6 | `MIT OR Apache-2.0` | https://github.com/hickory-dns/resolv-conf |
| ring | 0.17.14 | `Apache-2.0 AND ISC` | https://github.com/briansmith/ring |
| rusqlite | 0.40.2 | `MIT` | https://github.com/rusqlite/rusqlite |
| rustc_version | 0.4.1 | `MIT OR Apache-2.0` | https://github.com/djc/rustc-version-rs |
| rustc-hash | 2.1.3 | `Apache-2.0 OR MIT` | https://github.com/rust-lang/rustc-hash |
| rusticata-macros | 4.1.0 | `MIT/Apache-2.0` | https://github.com/rusticata/rusticata-macros.git |
| rustls | 0.23.44 | `Apache-2.0 OR ISC OR MIT` | https://github.com/rustls/rustls |
| rustls-pki-types | 1.15.1 | `MIT OR Apache-2.0` | https://github.com/rustls/pki-types |
| rustls-webpki | 0.103.15 | `ISC` | https://github.com/rustls/webpki |
| rw-stream-sink | 0.4.0 | `MIT` | https://github.com/libp2p/rust-libp2p |
| ryu | 1.0.23 | `Apache-2.0 OR BSL-1.0` | https://github.com/dtolnay/ryu |
| scopeguard | 1.2.0 | `MIT OR Apache-2.0` | https://github.com/bluss/scopeguard |
| semver | 1.0.28 | `MIT OR Apache-2.0` | https://github.com/dtolnay/semver |
| serde | 1.0.229 | `MIT OR Apache-2.0` | https://github.com/serde-rs/serde |
| serde_core | 1.0.229 | `MIT OR Apache-2.0` | https://github.com/serde-rs/serde |
| serde_derive | 1.0.229 | `MIT OR Apache-2.0` | https://github.com/serde-rs/serde |
| serde_json | 1.0.151 | `MIT OR Apache-2.0` | https://github.com/serde-rs/json |
| serde_path_to_error | 0.1.20 | `MIT OR Apache-2.0` | https://github.com/dtolnay/path-to-error |
| serde_urlencoded | 0.7.1 | `MIT/Apache-2.0` | https://github.com/nox/serde_urlencoded |
| sha1 | 0.10.7 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/hashes |
| sha2 | 0.10.9 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/hashes |
| sharded-slab | 0.1.7 | `MIT` | https://github.com/hawkw/sharded-slab |
| shlex | 2.0.1 | `MIT OR Apache-2.0` | https://github.com/comex/rust-shlex |
| signature | 2.2.0 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/traits/tree/master/signature |
| siphasher | 1.0.3 | `MIT/Apache-2.0` | https://github.com/jedisct1/rust-siphash |
| slab | 0.4.12 | `MIT` | https://github.com/tokio-rs/slab |
| smallvec | 1.16.0 | `MIT OR Apache-2.0` | https://github.com/servo/rust-smallvec |
| smol_str | 0.2.2 | `MIT OR Apache-2.0` | https://github.com/rust-analyzer/smol_str |
| snow | 0.9.6 | `Apache-2.0 OR MIT` | https://github.com/mcginty/snow |
| socket2 | 0.5.10 | `MIT OR Apache-2.0` | https://github.com/rust-lang/socket2 |
| socket2 | 0.6.5 | `MIT OR Apache-2.0` | https://github.com/rust-lang/socket2 |
| spki | 0.7.3 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/formats/tree/master/spki |
| stable_deref_trait | 1.2.1 | `MIT OR Apache-2.0` | https://github.com/storyyeller/stable_deref_trait |
| static_assertions | 1.1.0 | `MIT OR Apache-2.0` | https://github.com/nvzqz/static-assertions-rs |
| subtle | 2.6.1 | `BSD-3-Clause` | https://github.com/dalek-cryptography/subtle |
| syn | 2.0.119 | `MIT OR Apache-2.0` | https://github.com/dtolnay/syn |
| syn | 3.0.5 | `MIT OR Apache-2.0` | https://github.com/dtolnay/syn |
| sync_wrapper | 1.0.2 | `Apache-2.0` | https://github.com/Actyx/sync_wrapper |
| synstructure | 0.13.2 | `MIT` | https://github.com/mystor/synstructure |
| tagptr | 0.2.0 | `MIT/Apache-2.0` | https://github.com/oliver-giersch/tagptr.git |
| tempfile | 3.27.0 | `MIT OR Apache-2.0` | https://github.com/Stebalien/tempfile |
| thiserror | 1.0.69 | `MIT OR Apache-2.0` | https://github.com/dtolnay/thiserror |
| thiserror | 2.0.20 | `MIT OR Apache-2.0` | https://github.com/dtolnay/thiserror |
| thiserror-impl | 1.0.69 | `MIT OR Apache-2.0` | https://github.com/dtolnay/thiserror |
| thiserror-impl | 2.0.20 | `MIT OR Apache-2.0` | https://github.com/dtolnay/thiserror |
| thread_local | 1.1.10 | `MIT OR Apache-2.0` | https://github.com/Amanieu/thread_local-rs |
| time | 0.3.55 | `MIT OR Apache-2.0` | https://github.com/time-rs/time |
| time-core | 0.1.9 | `MIT OR Apache-2.0` | https://github.com/time-rs/time |
| time-macros | 0.2.32 | `MIT OR Apache-2.0` | https://github.com/time-rs/time |
| tinystr | 0.8.4 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| tinyvec | 1.13.2 | `Zlib OR Apache-2.0 OR MIT` | https://github.com/Lokathor/tinyvec |
| tinyvec_macros | 0.1.1 | `MIT OR Apache-2.0 OR Zlib` | https://github.com/Soveu/tinyvec_macros |
| tokio | 1.53.1 | `MIT` | https://github.com/tokio-rs/tokio |
| tokio-macros | 2.7.2 | `MIT` | https://github.com/tokio-rs/tokio |
| tokio-util | 0.7.19 | `MIT` | https://github.com/tokio-rs/tokio |
| tower | 0.5.3 | `MIT` | https://github.com/tower-rs/tower |
| tower-layer | 0.3.3 | `MIT` | https://github.com/tower-rs/tower |
| tower-service | 0.3.3 | `MIT` | https://github.com/tower-rs/tower |
| tracing | 0.1.44 | `MIT` | https://github.com/tokio-rs/tracing |
| tracing-attributes | 0.1.31 | `MIT` | https://github.com/tokio-rs/tracing |
| tracing-core | 0.1.36 | `MIT` | https://github.com/tokio-rs/tracing |
| tracing-log | 0.2.0 | `MIT` | https://github.com/tokio-rs/tracing |
| tracing-subscriber | 0.3.23 | `MIT` | https://github.com/tokio-rs/tracing |
| try-lock | 0.2.5 | `MIT` | https://github.com/seanmonstar/try-lock |
| typenum | 1.20.1 | `MIT OR Apache-2.0` | https://github.com/paholg/typenum |
| uint | 0.10.1 | `MIT OR Apache-2.0` | https://github.com/paritytech/parity-common |
| unicase | 2.9.0 | `MIT OR Apache-2.0` | https://github.com/seanmonstar/unicase |
| unicode-ident | 1.0.24 | `(MIT OR Apache-2.0) AND Unicode-3.0` | https://github.com/dtolnay/unicode-ident |
| unicode-segmentation | 1.13.3 | `MIT OR Apache-2.0` | https://github.com/unicode-rs/unicode-segmentation |
| universal-hash | 0.5.1 | `MIT OR Apache-2.0` | https://github.com/RustCrypto/traits |
| unsigned-varint | 0.7.2 | `MIT` | https://github.com/paritytech/unsigned-varint |
| unsigned-varint | 0.8.0 | `MIT` | https://github.com/paritytech/unsigned-varint |
| untrusted | 0.9.0 | `ISC` | https://github.com/briansmith/untrusted |
| url | 2.5.8 | `MIT OR Apache-2.0` | https://github.com/servo/rust-url |
| utf8_iter | 1.0.4 | `Apache-2.0 OR MIT` | https://github.com/hsivonen/utf8_iter |
| uuid | 1.26.0 | `Apache-2.0 OR MIT` | https://github.com/uuid-rs/uuid |
| vcpkg | 0.2.15 | `MIT/Apache-2.0` | https://github.com/mcgoo/vcpkg-rs |
| version_check | 0.9.5 | `MIT/Apache-2.0` | https://github.com/SergioBenitez/version_check |
| want | 0.3.1 | `MIT` | https://github.com/seanmonstar/want |
| web-time | 1.1.0 | `MIT OR Apache-2.0` | https://github.com/daxpedda/web-time |
| webpki-roots | 1.0.9 | `CDLA-Permissive-2.0` | https://github.com/rustls/webpki-roots |
| webview2-com | 0.38.2 | `MIT` | https://github.com/wravery/webview2-rs |
| webview2-com-macros | 0.8.1 | `MIT` | https://github.com/wravery/webview2-rs |
| webview2-com-sys | 0.38.2 | `MIT` | https://github.com/wravery/webview2-rs |
| widestring | 1.2.1 | `MIT OR Apache-2.0` | https://github.com/VoidStarKat/widestring-rs |
| windows | 0.61.3 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows | 0.62.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows_x86_64_gnullvm | 0.52.6 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-collections | 0.2.0 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-collections | 0.3.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-core | 0.61.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-core | 0.62.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-future | 0.2.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-future | 0.3.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-implement | 0.60.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-interface | 0.59.3 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-link | 0.1.3 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-link | 0.2.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-numerics | 0.2.0 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-numerics | 0.3.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-registry | 0.6.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-result | 0.3.4 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-result | 0.4.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-strings | 0.4.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-strings | 0.5.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-sys | 0.52.0 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-sys | 0.61.2 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-targets | 0.52.6 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-threading | 0.1.0 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-threading | 0.2.1 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| windows-version | 0.1.7 | `MIT OR Apache-2.0` | https://github.com/microsoft/windows-rs |
| winit | 0.30.13 | `Apache-2.0` | https://github.com/rust-windowing/winit |
| writeable | 0.6.4 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| wry | 0.56.1 | `Apache-2.0 OR MIT` | https://github.com/tauri-apps/wry |
| x25519-dalek | 2.0.1 | `BSD-3-Clause` | https://github.com/dalek-cryptography/curve25519-dalek/tree/main/x25519-dalek |
| x509-parser | 0.17.0 | `MIT OR Apache-2.0` | https://github.com/rusticata/x509-parser.git |
| xml-rs | 0.8.29 | `MIT` | https://github.com/kornelski/xml-rs |
| xmltree | 0.10.3 | `MIT` | https://github.com/eminence/xmltree-rs |
| yamux | 0.12.1 | `Apache-2.0 OR MIT` | https://github.com/paritytech/yamux |
| yamux | 0.13.10 | `Apache-2.0 OR MIT` | https://github.com/paritytech/yamux |
| yasna | 0.5.2 | `MIT OR Apache-2.0` | https://github.com/qnighy/yasna.rs |
| yoke | 0.8.3 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| yoke-derive | 0.8.2 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zerocopy | 0.8.57 | `BSD-2-Clause OR Apache-2.0 OR MIT` | https://github.com/google/zerocopy |
| zerofrom | 0.1.8 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zerofrom-derive | 0.1.7 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zeroize | 1.9.0 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/utils |
| zeroize_derive | 1.5.0 | `Apache-2.0 OR MIT` | https://github.com/RustCrypto/utils |
| zerotrie | 0.2.5 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zerovec | 0.11.8 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zerovec-derive | 0.11.6 | `Unicode-3.0` | https://github.com/unicode-org/icu4x |
| zmij | 1.0.23 | `MIT` | https://github.com/dtolnay/zmij |

Resolved third-party Rust packages: 360. Packages without a declared licence expression: 0.

