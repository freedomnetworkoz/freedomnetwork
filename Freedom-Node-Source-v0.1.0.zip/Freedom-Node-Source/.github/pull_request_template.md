## Summary

Describe the public Node change and why it is needed.

## Security impact

- [ ] No private key, credential, database, log, AppData, WebView profile or live site data is included.
- [ ] Signed-name verification and pinned trust are not weakened.
- [ ] Network and file inputs remain bounded and fail closed.

## Verification

- [ ] `cargo fmt` passed.
- [ ] Node tests passed.
- [ ] Clippy passed without warnings.
