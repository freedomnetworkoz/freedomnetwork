# Freedom Node

Freedom Node is the public Windows application for browsing and hosting Freedom sites, contact-based messaging, friendly internal mail and peer-to-peer network participation.

This is an early Internet preview. It supports encrypted Noise connections over TCP and QUIC, LAN discovery, a private Freedom DHT, known-peer reconnect, UPnP, Circuit Relay v2, DCUtR, HTTPS bootstrap recovery, multiple isolated website origins, bundled PHP hosting and the `freedom://` address scheme. It is not yet a complete anonymity or global-resilience system.

## Download

Download the Windows x64 ZIP from the repository's **Releases** page. Verify its SHA-256 value against the checksum published with the release, extract the complete folder and run `Freedom.exe`.

Do not move an existing Node identity between computers and run both copies. Each new computer should begin with a fresh installation and a distinct PeerID.

## First run

- Windows 10 or Windows 11, x64.
- Microsoft Edge WebView2 Runtime must be available (normally already installed on supported Windows systems).
- No XAMPP installation is required; the release includes its PHP runtime.
- Freedom is for adults aged 18 or over.
- The application creates its private identity and data outside the release archive on first run.

Freedom checks the packaged infrastructure endpoints immediately and retrieves the bounded public bootstrap list from `https://fenixstudio.org/bootstrap/peers.json`. If the website is unavailable, packaged and last-known-good peers remain available.

## Build the public Node

The project targets `x86_64-pc-windows-gnullvm` with Rust 1.88 or newer and LLVM-MinGW. Install a compatible toolchain or set `FREEDOM_TOOLCHAIN_ROOT` to a private toolchain directory containing Cargo, rustup and LLVM-MinGW.

```powershell
.\tools\fetch-php.ps1
.\tools\cargo.ps1 test --workspace
.\tools\cargo.ps1 clippy --workspace --all-targets
.\tools\package-node.ps1 -Configuration release
```

The package is written to `dist\node-release`. The owner-controlled Authority edition is deliberately not a supported build of this public repository.

## Important safety notes

- Freedom is not anonymous. Directly connected peers may see your IP address.
- Display names are not unique; PeerIDs and fingerprints identify peers.
- Hosted PHP executes as your Windows user. Host only code you trust.
- HTTP and HTTPS links leave Freedom only after confirmation and open in the normal Windows browser.
- Do not publish private keys, databases, mailboxes, logs, AppData or WebView profiles.

Read [SECURITY.md](SECURITY.md), [docs/threat-model.md](docs/threat-model.md), [docs/internet-connectivity.md](docs/internet-connectivity.md) and [docs/testing.md](docs/testing.md) before operating infrastructure or distributing a modified build.

## Licence and official branding

Freedom Node is free software licensed under `AGPL-3.0-only`; see [LICENSE](LICENSE). Modified versions used to interact with users over a network must provide those users access to the corresponding source as required by AGPLv3.

The licence does not make modified builds official Freedom Network releases and does not grant rights to impersonate the project. See [TRADEMARKS.md](TRADEMARKS.md), [NOTICE.md](NOTICE.md) and [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md).
