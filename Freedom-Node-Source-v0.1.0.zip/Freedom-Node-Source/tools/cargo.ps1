$ErrorActionPreference = 'Stop'

$projectRoot = Split-Path -Parent $PSScriptRoot
$localToolchain = Join-Path $projectRoot '.toolchains'
$toolchainRoot = if (-not [string]::IsNullOrWhiteSpace($env:FREEDOM_TOOLCHAIN_ROOT)) {
    [IO.Path]::GetFullPath($env:FREEDOM_TOOLCHAIN_ROOT)
}
elseif (Test-Path -LiteralPath (Join-Path $localToolchain 'cargo\bin\cargo.exe') -PathType Leaf) {
    $localToolchain
}
else {
    $null
}

if ($toolchainRoot) {
    $toolchainCargoHome = Join-Path $toolchainRoot 'cargo'
    $cargoHome = if (-not [string]::IsNullOrWhiteSpace($env:FREEDOM_CARGO_HOME)) {
        [IO.Path]::GetFullPath($env:FREEDOM_CARGO_HOME)
    }
    else {
        $toolchainCargoHome
    }
    $rustupHome = Join-Path $toolchainRoot 'rustup'
    $cargo = Join-Path $toolchainCargoHome 'bin\cargo.exe'
    $llvmRoot = Get-ChildItem -LiteralPath $toolchainRoot -Directory -Filter 'llvm-mingw-*' |
        Sort-Object Name -Descending |
        Select-Object -First 1
    if (-not (Test-Path -LiteralPath $cargo -PathType Leaf) -or -not $llvmRoot) {
        throw "FREEDOM_TOOLCHAIN_ROOT is not a complete Rust/LLVM toolchain: $toolchainRoot"
    }
    $env:CARGO_HOME = $cargoHome
    $env:RUSTUP_HOME = $rustupHome
    $env:PATH = (Join-Path $llvmRoot.FullName 'bin') + ';' + (Join-Path $toolchainCargoHome 'bin') + ';' + $env:PATH
    $env:CC_x86_64_pc_windows_gnullvm = 'x86_64-w64-mingw32-clang.exe'
    $env:CXX_x86_64_pc_windows_gnullvm = 'x86_64-w64-mingw32-clang++.exe'
    $env:AR_x86_64_pc_windows_gnullvm = 'llvm-ar.exe'
    $separator = [char]0x1f
    $freedomRemaps = @(
        "--remap-path-prefix=$toolchainRoot=FreedomToolchain",
        "--remap-path-prefix=$projectRoot=FreedomSource"
    )
    $remapFlags = @()
    if (-not [string]::IsNullOrWhiteSpace($env:CARGO_ENCODED_RUSTFLAGS)) {
        $remapFlags += @($env:CARGO_ENCODED_RUSTFLAGS -split $separator | Where-Object { $freedomRemaps -notcontains $_ })
    }
    $remapFlags += $freedomRemaps
    $env:CARGO_ENCODED_RUSTFLAGS = $remapFlags -join $separator
    & $cargo '+stable-x86_64-pc-windows-gnullvm' @args
    exit $LASTEXITCODE
}

$cargoCommand = Get-Command cargo.exe -ErrorAction SilentlyContinue
$linkerCommand = Get-Command x86_64-w64-mingw32-clang.exe -ErrorAction SilentlyContinue
if (-not $cargoCommand -or -not $linkerCommand) {
    throw 'A Rust gnullvm toolchain was not found. Install it or set FREEDOM_TOOLCHAIN_ROOT to the bundled cargo/rustup/llvm-mingw directory.'
}
$env:CC_x86_64_pc_windows_gnullvm = 'x86_64-w64-mingw32-clang.exe'
$env:CXX_x86_64_pc_windows_gnullvm = 'x86_64-w64-mingw32-clang++.exe'
$env:AR_x86_64_pc_windows_gnullvm = 'llvm-ar.exe'
$separator = [char]0x1f
$freedomRemaps = @("--remap-path-prefix=$projectRoot=FreedomSource")
$remapFlags = @()
if (-not [string]::IsNullOrWhiteSpace($env:CARGO_ENCODED_RUSTFLAGS)) {
    $remapFlags += @($env:CARGO_ENCODED_RUSTFLAGS -split $separator | Where-Object { $freedomRemaps -notcontains $_ })
}
$remapFlags += $freedomRemaps
$env:CARGO_ENCODED_RUSTFLAGS = $remapFlags -join $separator
& $cargoCommand.Source @args
exit $LASTEXITCODE
