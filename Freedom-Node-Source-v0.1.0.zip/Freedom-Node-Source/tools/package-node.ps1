param(
    [ValidateSet('debug', 'release')]
    [string]$Configuration = 'release'
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$cargoScript = Join-Path $PSScriptRoot 'cargo.ps1'
$cargoArguments = @('build', '-p', 'freedom-desktop')
if ($Configuration -eq 'release') {
    $cargoArguments += '--release'
}

& $cargoScript @cargoArguments
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }

$targetBase = if ([string]::IsNullOrWhiteSpace($env:CARGO_TARGET_DIR)) {
    Join-Path $projectRoot 'target'
}
else {
    [IO.Path]::GetFullPath($env:CARGO_TARGET_DIR)
}
$targetRoot = Join-Path $targetBase "x86_64-pc-windows-gnullvm\$Configuration"
$distribution = Join-Path $projectRoot "dist\node-$Configuration"
New-Item -ItemType Directory -Force -Path $distribution | Out-Null

# Preserve only a user's app-adjacent websites and public configuration when
# rebuilding an existing local package. Everything else is regenerated.
Get-ChildItem -LiteralPath $distribution -Force | Where-Object {
    $_.Name -notin @('htdocs', 'config')
} | Remove-Item -Recurse -Force

$loader = Get-ChildItem -LiteralPath $targetRoot -Recurse -Filter 'WebView2Loader.dll' -File |
    Where-Object { $_.DirectoryName -like '*\out\x64' } |
    Select-Object -First 1
if (-not $loader) { throw 'WebView2Loader.dll was not produced by the build.' }

$toolchainCandidates = @()
if (-not [string]::IsNullOrWhiteSpace($env:FREEDOM_TOOLCHAIN_ROOT)) {
    $toolchainCandidates += [IO.Path]::GetFullPath($env:FREEDOM_TOOLCHAIN_ROOT)
}
$toolchainCandidates += Join-Path $projectRoot '.toolchains'
$unwind = $null
foreach ($candidate in $toolchainCandidates) {
    if (-not (Test-Path -LiteralPath $candidate -PathType Container)) { continue }
    $unwind = Get-ChildItem -LiteralPath $candidate -Recurse -Filter 'libunwind.dll' -File |
        Where-Object { $_.DirectoryName -like '*x86_64-w64-mingw32\bin' } |
        Select-Object -First 1
    if ($unwind) { break }
}
if (-not $unwind) {
    foreach ($pathEntry in ($env:PATH -split ';')) {
        if ([string]::IsNullOrWhiteSpace($pathEntry)) { continue }
        $candidate = Join-Path $pathEntry 'libunwind.dll'
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            $unwind = Get-Item -LiteralPath $candidate
            break
        }
    }
}
if (-not $unwind) {
    throw 'libunwind.dll was not found in FREEDOM_TOOLCHAIN_ROOT, .toolchains, or PATH.'
}

Copy-Item -LiteralPath (Join-Path $targetRoot 'Freedom.exe') -Destination $distribution -Force
Copy-Item -LiteralPath $loader.FullName -Destination $distribution -Force
Copy-Item -LiteralPath $unwind.FullName -Destination $distribution -Force

$phpSource = Join-Path $projectRoot '.runtime\php'
$phpExecutable = Join-Path $phpSource 'php-cgi.exe'
$requiredPhpRuntimeFiles = @('php-cgi.exe', 'php8.dll', 'vcruntime140.dll', 'vcruntime140_1.dll', 'msvcp140.dll')
$missingPhpRuntimeFiles = @($requiredPhpRuntimeFiles | Where-Object {
    -not (Test-Path -LiteralPath (Join-Path $phpSource $_) -PathType Leaf)
})
if ($missingPhpRuntimeFiles.Count -gt 0) {
    throw "The bundled PHP runtime is incomplete. Run tools\fetch-php.ps1 first. Missing: $($missingPhpRuntimeFiles -join ', ')"
}
$phpVersionOutput = @(& $phpExecutable -n -v 2>&1)
if ($LASTEXITCODE -ne 0 -or ($phpVersionOutput -join "`n") -match '(?i)(not compatible|warning|fatal)') {
    throw "The bundled PHP runtime failed its startup check:`n$($phpVersionOutput -join "`n")"
}
$phpDistribution = Join-Path $distribution 'runtime\php'
New-Item -ItemType Directory -Force -Path $phpDistribution | Out-Null
Get-ChildItem -LiteralPath $phpSource -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $phpDistribution -Recurse -Force
}

New-Item -ItemType Directory -Force -Path (Join-Path $distribution 'htdocs') | Out-Null
$config = Join-Path $distribution 'config'
New-Item -ItemType Directory -Force -Path $config | Out-Null
$internetConfig = Join-Path $config 'internet.json'
if (-not (Test-Path -LiteralPath $internetConfig -PathType Leaf)) {
    Copy-Item -LiteralPath (Join-Path $projectRoot 'assets\config\internet.json') -Destination $internetConfig
}
foreach ($publicNameFile in @('authority-name-manifest.json', 'authority-trust-root.json')) {
    $publicNameDestination = Join-Path $config $publicNameFile
    if (-not (Test-Path -LiteralPath $publicNameDestination -PathType Leaf)) {
        Copy-Item -LiteralPath (Join-Path $projectRoot "assets\config\$publicNameFile") -Destination $publicNameDestination
    }
}
[IO.File]::WriteAllText(
    (Join-Path $distribution 'EDITION.txt'),
    "Freedom Node`r`n",
    [Text.UTF8Encoding]::new($false)
)

foreach ($legalFile in @('LICENSE', 'NOTICE.md', 'TRADEMARKS.md', 'THIRD_PARTY_LICENSES.md')) {
    $legalSource = Join-Path $projectRoot $legalFile
    if (-not (Test-Path -LiteralPath $legalSource -PathType Leaf)) {
        throw "Required legal file is missing: $legalSource"
    }
    Copy-Item -LiteralPath $legalSource -Destination (Join-Path $distribution $legalFile) -Force
}

$checksumLines = foreach ($runtimeFile in Get-ChildItem -LiteralPath $distribution -Recurse -File | Where-Object { $_.Name -ne 'SHA256SUMS.txt' }) {
    $relative = [IO.Path]::GetRelativePath($distribution, $runtimeFile.FullName).Replace('\', '/')
    if ($relative.StartsWith('htdocs/', [StringComparison]::OrdinalIgnoreCase) -or
        $relative.StartsWith('Freedom.exe.WebView2/', [StringComparison]::OrdinalIgnoreCase)) {
        continue
    }
    $hash = (Get-FileHash -LiteralPath $runtimeFile.FullName -Algorithm SHA256).Hash
    "$hash  $relative"
}
[IO.File]::WriteAllLines(
    (Join-Path $distribution 'SHA256SUMS.txt'),
    [string[]]$checksumLines,
    [Text.UTF8Encoding]::new($false)
)

Write-Output "Packaged Freedom Node in $distribution"
