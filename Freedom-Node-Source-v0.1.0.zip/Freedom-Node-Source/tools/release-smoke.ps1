param(
    [string]$PackageDirectory = (Join-Path (Split-Path -Parent $PSScriptRoot) 'dist\node-release')
)

$ErrorActionPreference = 'Stop'
$executable = Join-Path $PackageDirectory 'Freedom.exe'
$siteRoot = Join-Path (Split-Path -Parent $PSScriptRoot) 'examples\hello-site'
if (-not (Test-Path -LiteralPath $executable -PathType Leaf)) {
    throw "Packaged executable was not found: $executable"
}

function Get-FreeTcpPort {
    $listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, 0)
    $listener.Start()
    try {
        return ([Net.IPEndPoint]$listener.LocalEndpoint).Port
    }
    finally {
        $listener.Stop()
    }
}

function Wait-Json(
    [string]$Uri,
    [Diagnostics.Process]$Process,
    [string]$DataDirectory
) {
    for ($attempt = 0; $attempt -lt 60; $attempt++) {
        if ($null -ne $Process -and $Process.HasExited) {
            $logPath = Join-Path $DataDirectory 'startup.log'
            $details = @()
            foreach ($diagnostic in @($logPath, (Join-Path $DataDirectory 'stderr.log'), (Join-Path $DataDirectory 'stdout.log'))) {
                if (Test-Path -LiteralPath $diagnostic -PathType Leaf) {
                    $rawContent = Get-Content -LiteralPath $diagnostic -Raw
                    $content = if ($null -eq $rawContent) { '' } else { $rawContent.ToString().Trim() }
                    if (-not [string]::IsNullOrWhiteSpace($content)) { $details += $content }
                }
            }
            if ($details.Count -eq 0) { $details = @('No startup diagnostic was written.') }
            throw "Freedom process exited with code $($Process.ExitCode) before $Uri was ready. $($details -join ' | ')"
        }
        try {
            return Invoke-RestMethod -Uri $Uri -TimeoutSec 1
        }
        catch {
            Start-Sleep -Milliseconds 200
        }
    }
    throw "Timed out waiting for $Uri"
}

function Wait-Site([string]$Uri) {
    for ($attempt = 0; $attempt -lt 100; $attempt++) {
        try {
            $response = Invoke-WebRequest -Uri $Uri -UseBasicParsing -TimeoutSec 1
            if ($response.StatusCode -eq 200) {
                return $response
            }
        }
        catch {
            Start-Sleep -Milliseconds 200
        }
    }
    throw "Timed out retrieving $Uri"
}

$temporaryRoot = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
$smokeRoot = [IO.Path]::GetFullPath(
    (Join-Path $temporaryRoot ("freedom-release-smoke-" + [guid]::NewGuid().ToString('N')))
)
if (-not $smokeRoot.StartsWith($temporaryRoot, [StringComparison]::OrdinalIgnoreCase) -or
    -not ([IO.Path]::GetFileName($smokeRoot)).StartsWith('freedom-release-smoke-')) {
    throw "Refusing unsafe smoke directory: $smokeRoot"
}

$nodeA = $null
$nodeB = $null
try {
    $dataA = Join-Path $smokeRoot 'alice'
    $dataB = Join-Path $smokeRoot 'bob'
    $phpSite = Join-Path $smokeRoot 'php-site'
    $protectedSite = Join-Path $smokeRoot 'protected-site'
    $protectedAdmin = Join-Path $protectedSite 'admin'
    $protectedData = Join-Path $protectedSite 'data'
    New-Item -ItemType Directory -Force -Path $dataA, $dataB, $phpSite, $protectedAdmin, $protectedData | Out-Null
    [IO.File]::WriteAllText(
        (Join-Path $phpSite 'index.php'),
        "<?php header('Content-Type: application/json'); echo json_encode(['engine' => PHP_VERSION, 'name' => `$_GET['name'] ?? '', 'posted' => `$_POST['message'] ?? '']);",
        [Text.UTF8Encoding]::new($false)
    )
    [IO.File]::WriteAllText((Join-Path $protectedAdmin 'index.html'), 'protected admin', [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText(
        (Join-Path $protectedAdmin '.htaccess'),
        "AuthType Basic`nAuthName `"Release Smoke Admin`"`nAuthUserFile .htpasswd`nRequire valid-user`n",
        [Text.UTF8Encoding]::new($false)
    )
    [IO.File]::WriteAllText(
        (Join-Path $protectedAdmin '.htpasswd'),
        "user1:`$apr1`$gxNb79DX`$6wi9QaGNM5TA0kBKiC4710`n",
        [Text.UTF8Encoding]::new($false)
    )
    [IO.File]::WriteAllText((Join-Path $protectedData 'site.sqlite'), 'must not download', [Text.UTF8Encoding]::new($false))
    [IO.File]::WriteAllText((Join-Path $protectedData '.htaccess'), "Require all denied`n", [Text.UTF8Encoding]::new($false))

    $listenA = Get-FreeTcpPort
    $listenB = Get-FreeTcpPort
    $gatewayA = Get-FreeTcpPort
    $gatewayB = Get-FreeTcpPort

    $nodeB = Start-Process -FilePath $executable -ArgumentList @(
        '--headless', '--node', '--name', 'Bob', '--data-dir', $dataB,
        '--no-mdns',
        '--listen-port', $listenB, '--gateway-port', $gatewayB,
        '--site', "home=$siteRoot", '--site', "php=$phpSite", '--site', "protected=$protectedSite"
    ) -WindowStyle Hidden -RedirectStandardError (Join-Path $dataB 'stderr.log') -RedirectStandardOutput (Join-Path $dataB 'stdout.log') -PassThru
    $statusB = Wait-Json "http://127.0.0.1:$gatewayB/status" $nodeB $dataB
    $quicAddress = @($statusB.listen_addresses | Where-Object { $_ -match '/udp/[0-9]+/quic-v1/p2p/' } | Select-Object -First 1)
    if ($quicAddress.Count -ne 1) {
        throw 'The packaged node did not publish a QUIC listener.'
    }
    $quicAddress = ([string]$quicAddress[0]).Replace('/ip4/0.0.0.0/', '/ip4/127.0.0.1/')

    $nodeA = Start-Process -FilePath $executable -ArgumentList @(
        '--headless', '--node', '--name', 'Alice', '--data-dir', $dataA,
        '--no-mdns',
        '--listen-port', $listenA, '--gateway-port', $gatewayA,
        '--connect', $quicAddress
    ) -WindowStyle Hidden -RedirectStandardError (Join-Path $dataA 'stderr.log') -RedirectStandardOutput (Join-Path $dataA 'stdout.log') -PassThru
    $statusA = Wait-Json "http://127.0.0.1:$gatewayA/status" $nodeA $dataA

    $siteUri = "http://127.0.0.1:$gatewayA/site/$($statusB.peer_id)/home/"
    $siteResponse = Wait-Site $siteUri
    $expectedHash = (Get-FileHash -LiteralPath (Join-Path $siteRoot 'index.html') -Algorithm SHA256).Hash.ToLowerInvariant()
    $receivedHash = [string]$siteResponse.Headers['X-Freedom-Content-SHA256']
    if ($receivedHash -ne $expectedHash) {
        throw "Gateway hash mismatch: expected $expectedHash, received $receivedHash"
    }
    if ($siteResponse.Content -notmatch 'Freedom Sites') {
        throw 'Gateway response did not contain the expected site content.'
    }

    $phpUri = "http://127.0.0.1:$gatewayA/site/$($statusB.peer_id)/php/?name=Alice"
    $phpGet = Invoke-RestMethod -Uri $phpUri -TimeoutSec 10
    if ($phpGet.name -ne 'Alice' -or -not ([string]$phpGet.engine).StartsWith('8.5.')) {
        throw 'Bundled PHP GET/query-string smoke failed.'
    }
    $phpPost = Invoke-RestMethod -Uri $phpUri -Method Post -Body @{ message = 'hello Freedom' } -TimeoutSec 10
    if ($phpPost.posted -ne 'hello Freedom') {
        throw 'Bundled PHP POST smoke failed.'
    }

    $adminUri = "http://127.0.0.1:$gatewayA/site/$($statusB.peer_id)/protected/admin/"
    $challengeStatus = 0
    try {
        Invoke-WebRequest -Uri $adminUri -UseBasicParsing -TimeoutSec 10 | Out-Null
    }
    catch {
        $challengeStatus = [int]$_.Exception.Response.StatusCode
    }
    if ($challengeStatus -ne 401) {
        throw "Protected folder did not return an HTTP Basic challenge (received $challengeStatus)."
    }
    $basic = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes('user1:mickey5'))
    $adminResponse = Invoke-WebRequest -Uri $adminUri -UseBasicParsing -Headers @{ Authorization = "Basic $basic" } -TimeoutSec 10
    if ($adminResponse.StatusCode -ne 200 -or $adminResponse.Content -notmatch 'protected admin') {
        throw 'Existing .htaccess/.htpasswd folder authentication failed.'
    }
    $databaseStatus = 0
    try {
        Invoke-WebRequest -Uri "http://127.0.0.1:$gatewayA/site/$($statusB.peer_id)/protected/data/site.sqlite" -UseBasicParsing -TimeoutSec 10 | Out-Null
    }
    catch {
        $databaseStatus = [int]$_.Exception.Response.StatusCode
    }
    if ($databaseStatus -ne 403) {
        throw "Protected database path was not denied (received $databaseStatus)."
    }

    [pscustomobject]@{
        AlicePeerId = $statusA.peer_id
        BobPeerId = $statusB.peer_id
        Transport = 'QUIC + Noise'
        SiteStatus = $siteResponse.StatusCode
        SiteSha256 = $receivedHash
        PhpVersion = $phpGet.engine
        PhpGet = $phpGet.name
        PhpPost = $phpPost.posted
        HtaccessChallenge = $challengeStatus
        HtaccessAuthenticated = $adminResponse.StatusCode
        DatabaseDenied = $databaseStatus
        Result = 'PASS'
    }
}
finally {
    foreach ($process in @($nodeA, $nodeB)) {
        if ($null -ne $process -and -not $process.HasExited) {
            Stop-Process -Id $process.Id -Force -ErrorAction SilentlyContinue
            $process.WaitForExit(3000) | Out-Null
        }
    }
    if (Test-Path -LiteralPath $smokeRoot) {
        Remove-Item -LiteralPath $smokeRoot -Recurse -Force
    }
}
