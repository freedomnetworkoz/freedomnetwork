param()

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$runtimeRoot = [IO.Path]::GetFullPath((Join-Path $projectRoot '.runtime'))
$phpRoot = Join-Path $runtimeRoot 'php'
$phpCgi = Join-Path $phpRoot 'php-cgi.exe'
$archive = Join-Path $runtimeRoot 'php-8.5.10-nts-Win32-vs17-x64.zip'
$source = 'https://downloads.php.net/~windows/releases/archives/php-8.5.10-nts-Win32-vs17-x64.zip'
$expectedSha256 = '22ec430195984d233eb9e62c637a945bbcda06efca2f392d9d96d62c6acd34f8'

if (Test-Path -LiteralPath $phpCgi -PathType Leaf) {
    Write-Output "PHP runtime already present: $phpCgi"
    exit 0
}
if (Test-Path -LiteralPath $phpRoot) {
    throw "Incomplete PHP runtime exists; inspect it before retrying: $phpRoot"
}

New-Item -ItemType Directory -Force -Path $runtimeRoot | Out-Null
Invoke-WebRequest -Uri $source -OutFile $archive
$actualSha256 = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
if ($actualSha256 -ne $expectedSha256) {
    throw "PHP archive checksum mismatch: expected $expectedSha256, received $actualSha256"
}

Expand-Archive -LiteralPath $archive -DestinationPath $phpRoot
if (-not (Test-Path -LiteralPath $phpCgi -PathType Leaf)) {
    throw 'Verified PHP archive did not contain php-cgi.exe.'
}
Remove-Item -LiteralPath $archive
Write-Output "Installed verified PHP 8.5.10 NTS runtime in $phpRoot"
