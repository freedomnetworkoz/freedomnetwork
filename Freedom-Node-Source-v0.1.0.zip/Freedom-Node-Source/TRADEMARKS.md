# Freedom Network trademark policy

The Freedom Network, Freedom Node and Freedom Authority names, associated logos, slogans and distinctive product presentation are project marks. The `AGPL-3.0-only` software licence grants copyright permissions; it does not grant trademark rights or permission to impersonate an official release.

You may use the names truthfully to describe compatibility, identify the upstream project, discuss the software, report bugs or state that your work is derived from Freedom Node. You may also retain factual copyright and licence notices required by the AGPL.

You may not use project branding in a way that is likely to suggest that a modified build, service, website or network is produced, approved or operated by the Freedom Network project when it is not. Publicly distributed modified builds should use clearly different product branding and must prominently identify themselves as unofficial modifications.

Nothing in this policy limits fair, nominative or otherwise lawful use. Permission for uses outside this policy must come from the applicable rights holder. This policy concerns branding only and does not add restrictions to the AGPL-licensed source code.
