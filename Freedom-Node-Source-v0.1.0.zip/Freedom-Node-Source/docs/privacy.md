# Privacy

The current capability is direct authenticated encryption. It protects payload contents in transit and authenticates the direct peer, but exposes peer IP addresses to counterparts and network observers. It is not anonymous or traffic-analysis resistant.

Private routing must be a separate reviewed layer with end-to-end payload encryption, route expiry/rotation, relay isolation, failure recovery, and abuse controls before the UI may offer `PRIVATE` or `HARDENED` modes.

