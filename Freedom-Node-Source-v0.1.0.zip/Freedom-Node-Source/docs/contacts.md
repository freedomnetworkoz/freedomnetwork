# Contacts and blocking

Contacts are private local metadata keyed by cryptographic PeerId. A record contains an optional local alias, one of `unverified`, `trusted`, or `blocked`, a mute flag, and its creation time. Display names and aliases are not unique identities. Users should compare the full fingerprint over an independent channel before choosing `trusted`.

Blocking is enforced inside Freedom Core. A blocked PeerId is refused on authenticated connection, ignored during mDNS and Identify handling, omitted from peer introductions and reconnect candidates, rejected by manual dialing when the PeerId is present, and denied for inbound/outbound application requests. Connections already open are disconnected when the block is saved.

Mute is persisted for future notification workflows. This slice does not issue operating-system notifications, so mute currently records intent without suppressing any notification mechanism.
