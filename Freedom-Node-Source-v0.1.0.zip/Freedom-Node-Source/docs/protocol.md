# Protocols

All peer protocols use authenticated libp2p Noise connections. The remote PeerID comes from that authenticated connection rather than a display-name or payload claim.

- `/freedom/exchange/1`: bounded direct messages and HTML/PHP site requests/responses.
- `/freedom/peer-exchange/1`: bounded profile and peer-introduction hints. Introductions are not transitive trust.
- `/freedom/mail/1`: bounded friendly or direct Freedom mail delivery and acknowledgement.
- `/freedom/authority-records/1`: reserved typed signed-record request/response structures; no live administration handler yet.
- `/freedom/identity/1`: Identify protocol version string.

Messages and mail are UUID-deduplicated in SQLite. Direct messages stay keyed to authenticated PeerIDs. Site requests carry a site ID, contained relative path, supported method and bounded headers/body. Site responses include SHA-256 integrity metadata; media requests use bounded byte ranges.

Friendly `name@freedom.net` addresses route only when a verified official manifest identifies an active mail provider. The Authority provider validates active accounts and authorized sending PeerIDs before storage. Legacy peer-encoded addresses remain an internal direct-routing compatibility form, separate from the friendly UI.

PHP `mail()` talks only to a random-port adapter on `127.0.0.1`. It is not Internet SMTP and is not exposed to the LAN. The adapter validates and bounds submissions before handing them to the normal persistent mail queue.

`freedom://` is the browser-level canonical address scheme. `free://` is rewritten immediately to the canonical scheme and never creates a separate site origin.
