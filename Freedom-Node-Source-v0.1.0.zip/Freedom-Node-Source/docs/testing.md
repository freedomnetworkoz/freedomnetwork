# Testing

Run from the Freedom source root:

```powershell
.\tools\cargo.ps1 fmt --all -- --check
.\tools\cargo.ps1 test --workspace
.\tools\cargo.ps1 clippy --workspace --all-targets
.\tools\package-node.ps1 -Configuration release
.\tools\release-smoke.ps1 -PackageDirectory .\dist\node-release
```

Tests cover persistent identities/profile, storage migration, reconnect/backoff, contact-only conversations, message requests and unread state; bounded TCP/QUIC/relay endpoint validation, HTTPS bootstrap-manifest policy, response framing and cache replacement; bounded peer introductions; direct messaging; mail routing/delivery/deduplication/account limits/bans; signed name-manifest generation, trust pinning and tamper rejection; site containment/uploads/editor controls; PHP source non-disclosure, GET/POST/session/upload/extensions; `.htaccess` and `.htpasswd`; media ranges; browser tabs/origins/address parsing; alias normalization; hosted-page navigation/address reporting; confirmed external-browser handoff; bounded Freedom-only search fetching; F5-safe control-shell routing; first-run acknowledgement; optional hashed app-password persistence/startup/inactivity locking; and Settings-only diagnostics.

For GUI acceptance, set an app password under **Settings & identity**, press **Lock**, verify an incorrect password is rejected and the correct password unlocks the UI, then restart Freedom and verify it opens locked. Removing the password must disable startup, manual and inactivity locking. Press F5 on the main shell and verify it reloads Freedom without navigating to `/app` or showing a loopback 404.

For browser/search acceptance, follow relative links and submit a GET form inside a hosted site; the address bar must show the current friendly Freedom address, subpath and query. From `freedom://freedom.net/`, open its Mail link and verify it routes to `freedom://mail.freedom.net/`. In Search Admin → Crawler, queue an active Freedom address and run one step; the node should fetch and index the page without an HTTP URL or outbound PHP access.

For external-link acceptance, follow an absolute HTTPS link from a Freedom site. The Freedom shell must show the outside-network confirmation, then open the exact address in the Windows default browser only after approval. Cancel must do nothing. Addresses containing credentials, non-HTTP schemes or `*.freedom.localhost` must be rejected.

For Internet acceptance, first follow `docs\internet-connectivity.md` and place two public infrastructure endpoints in the HTTPS manifest. On a Node using a different Internet connection, start with an empty private data directory and verify the Network page reports the public manifest **Online**, at least one DHT peer and one relay reservation. Stop the Authority or its port forward, wait for the Node to lose all peers, and verify recovery checks recur while the cached and packaged peers remain available. Restart the Authority and verify the Node reconnects without changing or rebuilding its software. Connect two NATed Nodes through a relay, exchange messages and fetch a static, PHP and byte-range media response. If DCUtR succeeds, verify the log reports a direct upgrade; if it cannot, the relay path must continue working. Stop the first infrastructure server and verify the second remains usable. Run this separately from the LAN test so mDNS cannot hide an Internet-routing failure.

For hosted-site security acceptance, verify databases, dotfiles, configuration files, backups, internal include folders and PHP source are denied. Verify an uploaded `.php` file cannot execute from a media upload folder. Login failures should be rate-limited, successful login should rotate the session ID and state-changing administration POSTs should require a CSRF token.

`release-smoke.ps1` starts two packaged processes explicitly in Node role with mDNS disabled, dials them directly, retrieves static and PHP sites, tests HTTP Basic authentication and verifies that database files remain denied. It creates one uniquely named directory under the system temporary folder and removes only that directory.

Machine/toolchain failures must be recorded separately from code assertion failures. In restricted automation accounts, Windows DPAPI can fail even when the same test passes in the interactive Windows account. Do not weaken production identity protection or install XAMPP to hide such a failure. The package includes the app-local Microsoft VC runtime required by PHP 8.5.10, and packaging must fail if `runtime\php\php-cgi.exe -n -v` emits a warning or cannot start.

For physical acceptance, copy a whole release folder to each Windows PC. Verify fresh, different PeerIDs; compare fingerprints; connect over LAN; save contacts and message both ways; host and retrieve HTML/PHP/media; test sessions and seeking; then confirm traversal, oversized requests, PHP source fallback and protected-file access fail. For public infrastructure hosts, open only the intended Freedom TCP/UDP port and monitor relay resource use; ordinary client machines should retain their normal firewall policy.
