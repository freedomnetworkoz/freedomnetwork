# Partitions

LAN mDNS, manual IP dialing, direct messaging, HTML/PHP sites, and the local browser gateway do not assume global connectivity. SQLite state survives restarts. Multi-peer reconciliation, queued messages, replication, and the required 20-node partition/rejoin convergence harness are deferred until those data types exist; no central merge authority is introduced.
