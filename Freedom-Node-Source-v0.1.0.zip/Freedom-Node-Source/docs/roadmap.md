# Roadmap

Implemented:

1. Independent Freedom application identity, data paths, protocols, origins, database and packaging.
2. Public Node role with owner Authority capabilities excluded from the supported public build.
3. Fresh local identities and verification of separately signed Authority records.
4. Canonical `freedom://` plus immediate `free://` normalization.
5. Contact-only messaging, sites, bundled PHP, access controls and media ranges.
6. Friendly Freedom Mail transport and PHP webmail access through the separately operated provider.
7. Signed official-name manifest/trust-root format and local verification.
8. Typed authority audit storage and future signed-record protocol structures.
9. TCP and QUIC listeners, a private Freedom DHT, configurable Internet bootstrap/relay peers, AutoNAT, UPnP and DCUtR.
10. Bounded relay reservations/circuits and no general remote administration channel.
11. Confirmed HTTP/HTTPS handoff from Freedom sites to the user's default browser.

Next validation and network phases:

1. Two-physical-PC acceptance and longer restart/reconnect tests.
2. Authenticated publication, expiry and rollback-resistant distribution of signed name manifests.
3. Signed rotating bootstrap manifests, multi-server deployment, relay abuse controls and Internet soak testing.
4. Mail provider replication/failover, attachments, spam/abuse controls and backups.
5. Signed `.free` allocation records and a separate, narrowly scoped management tool.
6. Site manifests, content addressing, cache/replication and distributed search.
7. Separately reviewed private routing and stronger OS isolation for dynamic hosting.
8. Group-chat protocol/UI using the reserved role and moderation-event storage.

No future phase should introduce an invisible master bypass. Authority changes must be typed, signed and auditable.
