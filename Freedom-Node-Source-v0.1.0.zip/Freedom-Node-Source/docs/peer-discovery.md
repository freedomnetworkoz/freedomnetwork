# Peer discovery

Five methods are implemented: mDNS on the LAN, manual entry, bounded introductions from an authenticated peer, configured Internet bootstrap peers, and a private Freedom Kademlia DHT. Manual input accepts IPv4, IPv4 with port, bare/bracketed IPv6, hostname with optional port, or a full libp2p multiaddress. Port `42100` is the default. Bootstrap and relay endpoints accept bounded TCP or QUIC multiaddresses ending in the expected PeerID.

mDNS peers are dialled directly. Successful authenticated connections, Identify metadata, validated introductions and DHT routes feed only syntactically bounded addresses into dialing. Offline known peers are retried in batches of four with persisted exponential backoff from 5 seconds to 30 minutes. Successful authentication resets the failure counter; stale `connected` flags are cleared at startup. Blocked peers are neither shared nor retried. There are no compiled-in infrastructure PeerIDs: `config\internet.json` supplies the deployment's bootstrap and relay endpoints.

The implemented bootstrap layer is discovery, not a content or identity authority. Static package configuration is intentionally replaceable without recompiling, and ordinary DNS hostnames can move between public IP addresses. Signed, expiring, rotating bootstrap manifests remain a later hardening step.

An introduction is not an endorsement. It proves only that the connected introducer supplied a syntactically valid record. The eventual Noise handshake authenticates the introduced PeerId. A malicious introducer can still supply unreachable or adversarial identities; list and database bounds limit growth but do not solve Sybil or eclipse attacks.
