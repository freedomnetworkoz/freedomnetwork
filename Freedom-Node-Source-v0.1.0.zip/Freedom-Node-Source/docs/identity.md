# Identity

First run displays the adults-only network purpose, responsibility/privacy warning and 18+ acknowledgement before generating an Ed25519 keypair locally. The same disclaimer and usage guide remain available under Help. The keypair's protobuf encoding is encrypted with current-user Windows DPAPI and atomically stored. Restarting loads the same identity. A grouped 15-character base32 digest of PeerId bytes is the human-readable fingerprint; the first three characters are the short ID. Display names are explicitly non-unique and can be edited without rotating the key. Profile writes use a recoverable temporary/backup replacement, and the current name is announced to connected peers over the versioned peer-exchange protocol.

This milestone uses one long-term transport/device identity. Device authorization and rotating transport/session identifiers are future work and are not presented as implemented.
