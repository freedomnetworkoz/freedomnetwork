# Architecture

```text
Freedom Node (public build)
  Freedom.exe + Freedom product metadata
  WebView2 shell -> capability-protected loopback control API
  site-only loopback gateway -> isolated *.freedom.localhost origins
  Freedom Core
    DPAPI-protected peer identity + freedom.db
    TCP + QUIC + Noise, private DHT and relay client
    contact messaging, sites, PHP and mail transport
    verified official-name manifest consumer

Freedom Authority (separate private build and operational boundary)
  everything in Freedom Node
  separate DPAPI-protected authority signing identity
  signed official-name manifest/trust-root output
  official friendly-mailbox provider and fresh webmail template
  explicitly bounded DHT/bootstrap/relay infrastructure role
```

The public repository deliberately rejects compilation with the internal `authority` Cargo feature. A public binary rejects `--authority`; it has no authority signing key, private signing configuration or unrestricted administration credential. Node protocol types can verify signed public records without possessing the signer.

Peer private state lives under `%LOCALAPPDATA%\Freedom\Freedom\data`. Authority signing state lives below that data root in a separate `authority\signer` identity. Website roots remain beside packaged executables under `htdocs`. Authority and peer key material is never placed in the package, source tree or public manifest.

The core runs independently of the desktop event loop. The network stack is TCP + QUIC + Noise + Yamux, mDNS, Identify, a private Freedom Kademlia DHT, AutoNAT, UPnP, Circuit Relay v2 and DCUtR, with bounded request/response protocols. Public Nodes are DHT and relay clients only. Authority infrastructure mode adds the server behaviours but no administration protocol. The public loopback server exposes only public status and site routes; the desktop control API runs on a separate random port guarded by a random per-process capability.

Name manifests are typed JSON records signed by the Authority signing identity. Verification checks the signature, encoded public key, derived signer PeerID, pinned signer, complete reserved-name set and record shapes. Compatible connected peers poll, verify, cache and relay newer signed sequences. Initial trust-root and bootstrap endpoint installation remains an explicit packaging step.
