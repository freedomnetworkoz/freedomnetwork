# Internet connectivity

Freedom's desktop network stack supports direct TCP and QUIC, a private Freedom Kademlia DHT, AutoNAT reachability checks, DCUtR direct-connection upgrades, UPnP port mapping and Circuit Relay v2. The DHT uses `/freedom/kad/1.0.0`; it does not join the public IPFS DHT. All application traffic still uses Freedom's Noise-authenticated protocols.

The packaged Authority defaults to infrastructure-server mode. The public Node never enables the relay-server or DHT-server role. Infrastructure mode uses the Authority installation's ordinary transport PeerID, not its separate DNS signing key, and exposes no remote administration interface.

## What the server needs

The Authority computer is not publicly reachable merely because infrastructure mode is enabled. To make it an Internet bootstrap and relay server:

1. Keep the Authority installation and its transport identity stable.
2. Give the server a stable public DNS hostname or public IP address.
3. Permit and forward both TCP and UDP port `42100` to the Authority computer. TCP carries encrypted streams and relay traffic; UDP carries QUIC.
4. Permit `Freedom.exe` through Windows Firewall for the intended network profiles.
5. Keep the Authority process running.

The transport PeerID is shown under **Settings & identity**. A public endpoint has one of these forms:

```text
/dns4/bootstrap.example.net/tcp/42100/p2p/<AUTHORITY-TRANSPORT-PEERID>
/dns4/bootstrap.example.net/udp/42100/quic-v1/p2p/<AUTHORITY-TRANSPORT-PEERID>
```

Use a real public hostname owned by the operator. Changing that hostname's ordinary Internet DNS address does not require a Freedom software update. Changing the server's transport identity does require publishing a new endpoint because the Noise handshake must match the configured PeerID.

## Configure public Nodes

Each release has an editable `config\internet.json` beside `Freedom.exe`. Put at least one stable infrastructure endpoint in `bootstrap_peers`; put a TCP endpoint for each Circuit Relay server in `relay_peers`. The same Authority endpoint may appear in both lists:

```json
{
  "version": 1,
  "enable_upnp": true,
  "infrastructure": false,
  "bootstrap_peers": [
    "/dns4/bootstrap.example.net/tcp/42100/p2p/<AUTHORITY-TRANSPORT-PEERID>",
    "/dns4/bootstrap.example.net/udp/42100/quic-v1/p2p/<AUTHORITY-TRANSPORT-PEERID>"
  ],
  "relay_peers": [
    "/dns4/bootstrap.example.net/tcp/42100/p2p/<AUTHORITY-TRANSPORT-PEERID>"
  ],
  "bootstrap_manifests": [
    "https://fenixstudio.org/bootstrap/peers.json"
  ]
}
```

Restart Freedom after editing the file. Invalid, oversized or unsupported endpoints fail closed at startup. Public releases should distribute a reviewed, checksum-tracked configuration and must never bundle a private identity.

## Initial public bootstrap seed

The initial Authority transport PeerID is `12D3KooWAVYmZhCMnQFXjVFk4z2z1inyQQrzifgjTaB7XvaDeniD` at static public IPv4 address `159.196.22.133`. The distributable Node package is seeded with its TCP, QUIC and relay endpoints on port `42100`.

`bootstrap\peers.json` contains the same client configuration. Its deployed copy is:

```text
https://fenixstudio.org/bootstrap/peers.json
```

Nodes use the checksum-tracked local peers immediately, then fetch this HTTPS manifest asynchronously at startup. They refresh it every six hours while connected and every five minutes when no peer remains connected. Known Internet peers are also redialled every 30 seconds while unavailable. A successfully verified response is cached beneath the installation's private data directory and used on later starts when the website is unavailable.

The response is restricted to HTTPS with normal public certificate validation, no redirects, no credentials/query/fragment, a 64 KiB maximum, a strict versioned JSON schema and bounded TCP/QUIC endpoints. Remote data cannot enable infrastructure mode or supply another manifest URL. It must retain at least one PeerID already pinned in the packaged configuration; therefore control of the web host alone cannot silently replace the network's trust root. This is a safe interim discovery mechanism, but the file itself is not yet cryptographically signed or sequenced. A future format should add an offline-pinned signing key, monotonic sequence and expiry while retaining the last-known-good behavior.

For resilience, deploy at least two independently hosted infrastructure peers with different transport identities and list both. A second Authority binary can operate as a normal network node plus bootstrap/relay server. It does not become a second DNS signer unless a separate, explicitly designed signing-key replication system is added later.

The Network page reports the selected mode, configured server counts, DHT peers, NAT reachability, relay reservations, manifest status, last check time and recovery-check count. Freedom Authority also reports whether its TCP/QUIC listeners are active, whether its transport PeerID appears in the live manifest and how many infrastructure peers the manifest contains. `Bootstrap online` means the local Authority listeners are running; a Node connected from another Internet service remains the decisive port-forwarding test.

## External web links

Freedom sites may contain absolute `http://` or `https://` links. The hosted-page bridge sends those links to the trusted shell, which displays a confirmation and then asks Windows to open the URL in the user's default browser. Freedom does not load public websites inside a Freedom site origin. URLs containing credentials, control characters, unsupported schemes or internal `*.freedom.localhost` hosts are rejected.

## Remaining boundary

This is an operational Internet transport layer, not anonymity or private routing. Direct peers can see each other's IP addresses; relays can observe connection metadata and traffic volume. DHT discovery remains exposed to Sybil and eclipse attacks. Cryptographically signed rotating bootstrap manifests, relay reputation/quotas, multiple DNS signers, site replication, mail-provider failover and private routing remain separate work.
