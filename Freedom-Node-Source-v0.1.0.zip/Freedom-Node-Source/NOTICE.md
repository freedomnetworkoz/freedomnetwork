# Freedom Node legal notice

Copyright © 2026 Freedom Network contributors.

Freedom Node is free software licensed under the GNU Affero General Public License, version 3 only (`AGPL-3.0-only`). The complete licence is in [LICENSE](LICENSE). Freedom Node is provided without warranty, to the extent permitted by applicable law.

The Freedom Authority, private signing keys, live hosted sites, operational databases and owner-only administration tooling are separate from this public Freedom Node repository and are not licensed by this repository.

The software licence does not grant permission to imply that a modified build is an official Freedom Network release. Names, logos and other project branding are addressed separately in [TRADEMARKS.md](TRADEMARKS.md).

The downloadable package contains third-party components under their own licences, including Rust dependencies, Microsoft WebView2 loader components and PHP. See [THIRD_PARTY_LICENSES.md](THIRD_PARTY_LICENSES.md) and the licence/readme files shipped with the PHP runtime.
