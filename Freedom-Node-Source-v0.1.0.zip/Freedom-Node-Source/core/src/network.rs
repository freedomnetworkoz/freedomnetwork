use std::{
    collections::{HashMap, HashSet, VecDeque},
    path::{Path, PathBuf},
    str::FromStr,
    sync::Arc,
    time::{Duration, Instant, UNIX_EPOCH},
};

use anyhow::{Context, Result, bail};
use futures::StreamExt;
use libp2p::{
    Multiaddr, PeerId, StreamProtocol, Swarm, SwarmBuilder, autonat, dcutr, identify, kad, mdns,
    noise, ping, relay,
    request_response::{self, OutboundRequestId, ProtocolSupport},
    swarm::{NetworkBehaviour, SwarmEvent, behaviour::toggle::Toggle},
    tcp, upnp, yamux,
};
use tokio::sync::{RwLock, mpsc, oneshot};
use tracing::{debug, info, warn};
use uuid::Uuid;

#[cfg(feature = "authority")]
use crate::mail::OfficialMailProvider;
#[cfg(feature = "authority")]
use crate::naming::{
    load_authority_name_records, merge_authority_name_records, store_authority_manifest,
    store_authority_name_records,
};
use crate::{
    address::{ManualPeer, normalize_fingerprint},
    identity::{FreedomIdentity, fingerprint_for_peer},
    internet::{
        InternetConfig, InternetEndpoint, fetch_bootstrap_manifest, store_bootstrap_manifest_cache,
    },
    mail::{SubmittedMail, mailbox_address, route_mailbox, start_submission_server},
    models::{
        ContactRecord, MailRecord, MessageRecord, NameRecord, NodeSnapshot, PeerRecord, SiteConfig,
    },
    naming::{
        SignedNameManifest, load_verified_manifest, official_name_records,
        store_verified_manifest_cache,
    },
    php::{PhpRequest, PhpRuntime},
    protocol::{
        AUTHORITY_RECORDS_PROTOCOL, AuthorityRecordsRequest, AuthorityRecordsResponse,
        EXCHANGE_PROTOCOL, FreedomRequest, FreedomResponse, MAIL_PROTOCOL,
        MAX_AUTHORITY_MANIFEST_BYTES, MAX_MAIL_BODY_BYTES, MAX_MAIL_SUBJECT_BYTES,
        MAX_MESSAGE_BYTES, MAX_PEER_ADVERTISEMENTS, MAX_SITE_REQUEST_BYTES,
        MAX_SITE_RESPONSE_BYTES, MailRequest, MailResponse, PEER_EXCHANGE_PROTOCOL,
        PeerAdvertisement, PeerExchangeRequest, PeerExchangeResponse, SiteHeader,
    },
    sites::{
        AccessPolicy, HostedFile, SiteRegistry, UploadedFile, authorize_basic, basic_credentials,
        verify_hash,
    },
    storage::{Storage, unix_timestamp},
};

const MAX_RECENT_EVENTS: usize = 80;

#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum ApplicationRole {
    #[default]
    Node,
    Authority,
}

impl ApplicationRole {
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Node => "node",
            Self::Authority => "authority",
        }
    }
}

#[derive(Clone, Debug)]
pub struct NodeConfig {
    pub data_dir: PathBuf,
    pub htdocs_dir: Option<PathBuf>,
    pub php_cgi: Option<PathBuf>,
    pub enable_mdns: bool,
    pub display_name: String,
    pub listen_port: u16,
    pub role: ApplicationRole,
    pub authority_manifest: Option<PathBuf>,
    pub trusted_authority_signer: Option<String>,
    pub internet: InternetConfig,
}

#[derive(Clone, Debug)]
pub struct SiteRequest {
    pub method: String,
    pub query: String,
    pub content_type: String,
    pub authorization: Option<String>,
    pub headers: Vec<SiteHeader>,
    pub body: Vec<u8>,
}

impl SiteRequest {
    fn get() -> Self {
        Self {
            method: "GET".into(),
            query: String::new(),
            content_type: String::new(),
            authorization: None,
            headers: Vec::new(),
            body: Vec::new(),
        }
    }
}

#[derive(Clone)]
pub struct NodeHandle {
    commands: mpsc::Sender<NodeCommand>,
    snapshot: Arc<RwLock<NodeSnapshot>>,
    local_peer: PeerId,
}

impl NodeHandle {
    pub fn local_peer_id(&self) -> PeerId {
        self.local_peer
    }

    pub async fn snapshot(&self) -> NodeSnapshot {
        self.snapshot.read().await.clone()
    }

    pub async fn dial(&self, peer: ManualPeer) -> Result<String> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::Dial { peer, reply })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while dialing")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn send_message(&self, peer_id: &str, body: &str) -> Result<String> {
        let peer = PeerId::from_str(peer_id).context("invalid recipient PeerId")?;
        if body.is_empty() {
            bail!("message cannot be empty");
        }
        if body.len() > MAX_MESSAGE_BYTES {
            bail!("message exceeds {MAX_MESSAGE_BYTES} bytes");
        }
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SendMessage {
                peer,
                body: body.to_owned(),
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while sending")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn send_mail(&self, recipient: &str, subject: &str, body: &str) -> Result<String> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SendMail {
                recipient: recipient.to_owned(),
                subject: subject.to_owned(),
                body: body.to_owned(),
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while queuing mail")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn mark_mail_read(&self, message_id: &str) -> Result<usize> {
        let message_id = Uuid::parse_str(message_id)
            .context("invalid mail message ID")?
            .to_string();
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::MarkMailRead { message_id, reply })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while marking mail read")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn mark_conversation_read(&self, peer_id: &str) -> Result<usize> {
        let peer = PeerId::from_str(peer_id).context("invalid conversation PeerId")?;
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::MarkConversationRead { peer, reply })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while marking a conversation read")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn fetch_site(&self, peer_id: &str, site_id: &str, path: &str) -> Result<HostedFile> {
        self.request_site(peer_id, site_id, path, SiteRequest::get())
            .await
    }

    pub async fn request_site(
        &self,
        peer_id: &str,
        site_id: &str,
        path: &str,
        mut request: SiteRequest,
    ) -> Result<HostedFile> {
        let peer = PeerId::from_str(peer_id).context("invalid site-provider PeerId")?;
        if !matches!(request.method.as_str(), "GET" | "HEAD" | "POST") {
            bail!("only GET, HEAD, and POST site requests are supported");
        }
        if request.body.len() > MAX_SITE_REQUEST_BYTES {
            bail!("site request exceeds {MAX_SITE_REQUEST_BYTES} bytes");
        }
        request.headers = sanitize_site_headers(&request.headers, request_header_allowed)
            .context("invalid site request headers")?;
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::FetchSite {
                peer,
                site_id: site_id.to_owned(),
                path: path.to_owned(),
                request,
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while fetching")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn add_site(&self, site_id: &str, name: &str, root: &Path) -> Result<SiteConfig> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::AddSite {
                site_id: site_id.to_owned(),
                name: name.to_owned(),
                root: root.to_path_buf(),
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while adding site")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn create_site(&self, site_id: &str, name: &str) -> Result<SiteConfig> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::CreateSite {
                site_id: site_id.to_owned(),
                name: name.to_owned(),
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while creating a site")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn upload_site_file(
        &self,
        site_id: &str,
        path: &str,
        body: Vec<u8>,
    ) -> Result<UploadedFile> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::UploadSiteFile {
                site_id: site_id.to_owned(),
                path: path.to_owned(),
                body,
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while uploading a site file")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn set_site_enabled(&self, site_id: &str, enabled: bool) -> Result<SiteConfig> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SetSiteEnabled {
                site_id: site_id.to_owned(),
                enabled,
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while updating a site")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn set_contact(
        &self,
        peer_id: &str,
        alias: Option<&str>,
        trust_state: &str,
        muted: bool,
    ) -> Result<ContactRecord> {
        let peer = PeerId::from_str(peer_id).context("invalid contact PeerId")?;
        if peer == self.local_peer {
            bail!("the local identity cannot be added as a contact");
        }
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SetContact {
                peer,
                alias: alias.map(str::to_owned),
                trust_state: trust_state.to_owned(),
                muted,
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while updating a contact")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn update_display_name(&self, display_name: &str) -> Result<String> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::UpdateDisplayName {
                display_name: display_name.to_owned(),
                reply,
            })
            .await
            .context("Freedom node has stopped")?;
        receiver
            .await
            .context("Freedom node stopped while updating its profile")?
            .map_err(anyhow::Error::msg)
    }

    #[cfg(feature = "authority")]
    pub async fn set_authority_name(&self, record: NameRecord) -> Result<u64> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SetAuthorityName {
                hostname: record.hostname.clone(),
                record: Some(record),
                reply,
            })
            .await
            .context("Freedom Authority has stopped")?;
        receiver
            .await
            .context("Freedom Authority stopped while saving DNS")?
            .map_err(anyhow::Error::msg)
    }

    #[cfg(feature = "authority")]
    pub async fn remove_authority_name(&self, hostname: &str) -> Result<u64> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::SetAuthorityName {
                hostname: hostname.to_owned(),
                record: None,
                reply,
            })
            .await
            .context("Freedom Authority has stopped")?;
        receiver
            .await
            .context("Freedom Authority stopped while removing DNS")?
            .map_err(anyhow::Error::msg)
    }

    pub async fn shutdown(&self) -> Result<()> {
        let (reply, receiver) = oneshot::channel();
        self.commands
            .send(NodeCommand::Shutdown { reply })
            .await
            .context("Freedom node has already stopped")?;
        receiver
            .await
            .context("Freedom node stopped during shutdown")?;
        Ok(())
    }
}

pub async fn spawn_node(config: NodeConfig) -> Result<NodeHandle> {
    #[cfg(not(feature = "authority"))]
    if config.role == ApplicationRole::Authority {
        bail!("this Freedom build does not include owner-only authority capabilities");
    }
    if config.internet.infrastructure && config.role != ApplicationRole::Authority {
        bail!("Internet infrastructure mode requires the Freedom Authority edition");
    }
    let identity = FreedomIdentity::load_or_create(&config.data_dir, &config.display_name)?;
    let local_peer = identity.peer_id();
    let bootstrap_cache_path = config.data_dir.join("bootstrap-peers-cache.json");
    let bootstrap_manifests = config.internet.bootstrap_manifests.clone();
    let mut bootstrap_trust_anchors = config
        .internet
        .bootstrap_peers
        .iter()
        .chain(&config.internet.relay_peers)
        .map(|endpoint| endpoint.peer_id)
        .collect::<HashSet<_>>();
    if config.role == ApplicationRole::Authority {
        bootstrap_trust_anchors.insert(local_peer);
    }
    let mut internet = config.internet.clone();
    let mut bootstrap_manifest_status = if bootstrap_manifests.is_empty() {
        "Not configured".to_owned()
    } else {
        "Checking".to_owned()
    };
    let mut bootstrap_manifest_last_success = None;
    let mut bootstrap_manifest_peer_count = 0;
    let mut bootstrap_manifest_listed = false;
    if !bootstrap_manifests.is_empty()
        && let Ok(cached) = InternetConfig::load_cached_bootstrap_manifest(&bootstrap_cache_path)
        && cached.contains_any_peer(bootstrap_trust_anchors.iter())
    {
        bootstrap_manifest_peer_count = cached.unique_peer_count();
        bootstrap_manifest_listed = cached.contains_any_peer([&local_peer]);
        internet.merge_discovery(&cached);
        bootstrap_manifest_status = "Cached · checking".into();
        bootstrap_manifest_last_success = std::fs::metadata(&bootstrap_cache_path)
            .ok()
            .and_then(|metadata| metadata.modified().ok())
            .and_then(|modified| modified.duration_since(UNIX_EPOCH).ok())
            .map(|duration| duration.as_secs() as i64);
    }
    let internet_mode = internet.mode_label().to_owned();
    let bootstrap_peers = internet
        .bootstrap_peers
        .iter()
        .filter(|endpoint| endpoint.peer_id != local_peer)
        .cloned()
        .collect::<Vec<_>>();
    let relay_peers = internet
        .relay_peers
        .iter()
        .filter(|endpoint| endpoint.peer_id != local_peer)
        .cloned()
        .collect::<Vec<_>>();
    let configured_bootstrap_peers = bootstrap_peers.len();
    let configured_relay_peers = relay_peers.len();
    let storage = Storage::open(&config.data_dir.join("freedom.db"))?;
    let legacy_htdocs = config.data_dir.join("htdocs");
    let htdocs_root = config
        .htdocs_dir
        .clone()
        .unwrap_or_else(|| legacy_htdocs.clone());
    std::fs::create_dir_all(&htdocs_root).context("could not create Freedom htdocs")?;
    let htdocs_root =
        std::fs::canonicalize(htdocs_root).context("could not resolve Freedom htdocs")?;
    let mut stored_sites = storage.sites()?;
    migrate_managed_sites(&storage, &mut stored_sites, &legacy_htdocs, &htdocs_root);
    let mut sites = SiteRegistry::new(stored_sites);
    for discovered in sites
        .discover_managed(&htdocs_root)
        .context("could not discover sites copied into Freedom htdocs")?
    {
        storage
            .upsert_site(&discovered)
            .context("could not remember a site discovered in Freedom htdocs")?;
    }
    let published_sites = sites
        .list()
        .into_iter()
        .filter(|site| site.enabled)
        .map(|site| site.site_id)
        .collect::<HashSet<_>>();
    let manifest_cache_path = config.data_dir.join("authority-name-manifest.json");
    #[cfg(feature = "authority")]
    let mut authority_signing_key = None;
    let (name_records, authority_peer, authority_signer, name_manifest, trusted_authority_signer) =
        match config.role {
            ApplicationRole::Authority => {
                #[cfg(feature = "authority")]
                {
                    let authority_dir = config.data_dir.join("authority");
                    let signer = FreedomIdentity::load_or_create(
                        &authority_dir.join("signer"),
                        "Freedom Authority Signer",
                    )?;
                    let records = merge_authority_name_records(
                        official_name_records(Some(&local_peer), &published_sites),
                        load_authority_name_records(&authority_dir)?,
                    )?;
                    let manifest = store_authority_manifest(
                        &authority_dir,
                        signer.keypair(),
                        unix_timestamp(),
                        records,
                    )?;
                    let trusted_signer = signer.keypair().public().to_peer_id();
                    authority_signing_key = Some(signer.keypair().clone());
                    let provider = official_mail_peer(&manifest.records);
                    (
                        manifest.records.clone(),
                        provider,
                        Some(manifest.signer_peer_id.clone()),
                        Some(manifest),
                        Some(trusted_signer),
                    )
                }
                #[cfg(not(feature = "authority"))]
                unreachable!("authority role was rejected above");
            }
            ApplicationRole::Node => {
                match (&config.authority_manifest, &config.trusted_authority_signer) {
                    (Some(path), Some(expected)) => {
                        let expected = PeerId::from_str(expected)
                            .context("configured authority signer PeerID is invalid")?;
                        let packaged = load_verified_manifest(path, &expected)
                            .context("could not load the signed Freedom name manifest")?;
                        let manifest = load_verified_manifest(&manifest_cache_path, &expected)
                            .ok()
                            .filter(|cached| cached.sequence > packaged.sequence)
                            .unwrap_or(packaged);
                        let provider = official_mail_peer(&manifest.records);
                        (
                            manifest.records.clone(),
                            provider,
                            Some(expected.to_string()),
                            Some(manifest),
                            Some(expected),
                        )
                    }
                    (None, None) => (
                        official_name_records(None, &published_sites),
                        None,
                        None,
                        None,
                        None,
                    ),
                    _ => bail!(
                        "a public node requires both an authority manifest and its pinned signer PeerID"
                    ),
                }
            }
        };
    let mail_address = mailbox_address(&local_peer);
    #[cfg(feature = "authority")]
    let official_mail_provider = if config.role == ApplicationRole::Authority {
        Some(
            OfficialMailProvider::open(&htdocs_root, local_peer)
                .map_err(anyhow::Error::msg)
                .context("could not open the official Freedom mailbox store")?,
        )
    } else {
        None
    };
    let (mail_submission_sender, mail_submissions) = mpsc::channel(32);
    let mail_submission = start_submission_server(mail_submission_sender).await?;
    let php = PhpRuntime::new(
        config.php_cgi,
        Some((mail_submission.port, mail_address.clone())),
    );
    #[cfg(feature = "authority")]
    let php = php.with_authority_peer(
        (config.role == ApplicationRole::Authority).then(|| local_peer.to_string()),
    );
    let (commands, receiver) = mpsc::channel(128);
    let mut initial_snapshot = NodeSnapshot::empty(
        identity.display_name(),
        local_peer.to_string(),
        identity.fingerprint(),
    );
    initial_snapshot.application_role = config.role.as_str().into();
    initial_snapshot
        .authority_signer
        .clone_from(&authority_signer);
    let snapshot = Arc::new(RwLock::new(initial_snapshot));

    let mdns = if config.enable_mdns {
        Some(mdns::tokio::Behaviour::new(
            mdns::Config::default(),
            local_peer,
        )?)
    } else {
        None
    };
    let display_name = identity.display_name().to_owned();
    let codec = request_response::cbor::codec::Codec::<FreedomRequest, FreedomResponse>::default()
        .set_request_size_maximum((MAX_SITE_REQUEST_BYTES + 96 * 1024) as u64)
        .set_response_size_maximum((MAX_SITE_RESPONSE_BYTES + 256 * 1024) as u64);
    let exchange = request_response::cbor::Behaviour::with_codec(
        codec,
        [(
            StreamProtocol::new(EXCHANGE_PROTOCOL),
            ProtocolSupport::Full,
        )],
        request_response::Config::default()
            .with_request_timeout(Duration::from_secs(90))
            .with_max_concurrent_streams(16),
    );
    let peer_exchange_codec =
        request_response::cbor::codec::Codec::<PeerExchangeRequest, PeerExchangeResponse>::default(
        )
        .set_request_size_maximum(4 * 1024)
        .set_response_size_maximum(256 * 1024);
    let peer_exchange = request_response::cbor::Behaviour::with_codec(
        peer_exchange_codec,
        [(
            StreamProtocol::new(PEER_EXCHANGE_PROTOCOL),
            ProtocolSupport::Full,
        )],
        request_response::Config::default()
            .with_request_timeout(Duration::from_secs(15))
            .with_max_concurrent_streams(16),
    );
    let authority_records_codec = request_response::cbor::codec::Codec::<
        AuthorityRecordsRequest,
        AuthorityRecordsResponse,
    >::default()
    .set_request_size_maximum(4 * 1024)
    .set_response_size_maximum(MAX_AUTHORITY_MANIFEST_BYTES as u64 + 16 * 1024);
    let authority_records = request_response::cbor::Behaviour::with_codec(
        authority_records_codec,
        [(
            StreamProtocol::new(AUTHORITY_RECORDS_PROTOCOL),
            ProtocolSupport::Full,
        )],
        request_response::Config::default()
            .with_request_timeout(Duration::from_secs(15))
            .with_max_concurrent_streams(8),
    );
    let mail_codec = request_response::cbor::codec::Codec::<MailRequest, MailResponse>::default()
        .set_request_size_maximum((MAX_MAIL_BODY_BYTES + 8 * 1024) as u64)
        .set_response_size_maximum(4 * 1024);
    let mail = request_response::cbor::Behaviour::with_codec(
        mail_codec,
        [(StreamProtocol::new(MAIL_PROTOCOL), ProtocolSupport::Full)],
        request_response::Config::default()
            .with_request_timeout(Duration::from_secs(30))
            .with_max_concurrent_streams(8),
    );
    let identify = identify::Behaviour::new(
        identify::Config::new("/freedom/identity/1".into(), identity.keypair().public())
            .with_agent_version(format!("Freedom/0.1; name={display_name}")),
    );
    let mut kad = kad::Behaviour::with_config(
        local_peer,
        kad::store::MemoryStore::new(local_peer),
        kad::Config::new(StreamProtocol::new("/freedom/kad/1.0.0")),
    );
    kad.set_mode(Some(if internet.infrastructure {
        kad::Mode::Server
    } else {
        kad::Mode::Client
    }));
    let autonat = autonat::Behaviour::new(local_peer, autonat::Config::default());
    let dcutr = dcutr::Behaviour::new(local_peer);
    let ping = ping::Behaviour::new(ping::Config::default());
    let relay_server = internet.infrastructure.then(|| {
        relay::Behaviour::new(
            local_peer,
            relay::Config {
                max_reservations: 256,
                max_reservations_per_peer: 2,
                max_circuits: 128,
                max_circuits_per_peer: 8,
                max_circuit_duration: Duration::from_secs(10 * 60),
                max_circuit_bytes: 64 * 1024 * 1024,
                ..Default::default()
            },
        )
    });
    let upnp = internet.enable_upnp.then(upnp::tokio::Behaviour::default);

    let mut swarm = SwarmBuilder::with_existing_identity(identity.keypair().clone())
        .with_tokio()
        .with_tcp(
            tcp::Config::default().nodelay(true),
            noise::Config::new,
            yamux::Config::default,
        )?
        .with_quic()
        .with_dns()?
        .with_relay_client(noise::Config::new, yamux::Config::default)?
        .with_behaviour(move |_, relay_client| FreedomBehaviour {
            mdns: Toggle::from(mdns),
            identify,
            kad,
            autonat,
            relay_client,
            relay_server: Toggle::from(relay_server),
            dcutr,
            upnp: Toggle::from(upnp),
            ping,
            exchange,
            peer_exchange,
            authority_records,
            mail,
        })?
        .with_swarm_config(|configuration| {
            configuration.with_idle_connection_timeout(Duration::from_secs(120))
        })
        .build();

    let listen: Multiaddr = format!("/ip4/0.0.0.0/tcp/{}", config.listen_port).parse()?;
    swarm.listen_on(listen)?;
    let quic_listen: Multiaddr =
        format!("/ip4/0.0.0.0/udp/{}/quic-v1", config.listen_port).parse()?;
    swarm.listen_on(quic_listen)?;

    let mut configured_peers = HashSet::new();
    for endpoint in bootstrap_peers.iter().chain(&relay_peers) {
        if endpoint.peer_id == local_peer {
            continue;
        }
        let transport_address = endpoint.transport_address();
        swarm
            .behaviour_mut()
            .kad
            .add_address(&endpoint.peer_id, transport_address.clone());
        swarm
            .behaviour_mut()
            .autonat
            .add_server(endpoint.peer_id, Some(transport_address.clone()));
        swarm.add_peer_address(endpoint.peer_id, transport_address);
        configured_peers.insert(endpoint.peer_id);
    }
    let mut initially_dialing_peers = HashSet::new();
    for peer in &configured_peers {
        match swarm.dial(*peer) {
            Ok(()) => {
                initially_dialing_peers.insert(*peer);
            }
            Err(error) => {
                debug!(%peer, %error, "configured Internet peer dial could not start");
            }
        }
    }
    for endpoint in &relay_peers {
        if endpoint.peer_id == local_peer {
            continue;
        }
        let relay_listener = endpoint
            .address
            .clone()
            .with(libp2p::multiaddr::Protocol::P2pCircuit);
        swarm.listen_on(relay_listener).with_context(|| {
            format!(
                "could not request relay reservation from {}",
                endpoint.peer_id
            )
        })?;
    }
    if !bootstrap_peers.is_empty() || !relay_peers.is_empty() {
        let _ = swarm.behaviour_mut().kad.bootstrap();
    }
    let registered_internet_addresses = bootstrap_peers
        .iter()
        .chain(&relay_peers)
        .map(|endpoint| endpoint.address.clone())
        .collect::<HashSet<_>>();
    let relay_listener_addresses = relay_peers
        .iter()
        .map(|endpoint| endpoint.address.clone())
        .collect::<HashSet<_>>();
    let (bootstrap_update_sender, bootstrap_updates) = mpsc::channel(4);

    let mut node = FreedomNode {
        local_peer,
        data_dir: config.data_dir,
        htdocs_root,
        display_name,
        swarm,
        storage,
        sites,
        php,
        mail_address,
        name_records,
        authority_peer,
        authority_signer,
        name_manifest,
        trusted_authority_signer,
        manifest_cache_path,
        application_role: config.role,
        #[cfg(feature = "authority")]
        authority_signing_key,
        #[cfg(feature = "authority")]
        official_mail_provider,
        mail_submissions,
        mail_submission_task: mail_submission.task,
        commands: receiver,
        snapshot: Arc::clone(&snapshot),
        listen_addresses: Vec::new(),
        internet_mode,
        internet_infrastructure: internet.infrastructure,
        nat_status: "Unknown".into(),
        configured_bootstrap_peers,
        configured_relay_peers,
        internet_bootstrap_peers: bootstrap_peers,
        internet_relay_peers: relay_peers,
        registered_internet_addresses,
        relay_listener_addresses,
        relay_reservations: HashSet::new(),
        bootstrap_manifests,
        bootstrap_cache_path,
        bootstrap_trust_anchors,
        bootstrap_update_sender,
        bootstrap_updates,
        bootstrap_refresh_in_flight: false,
        bootstrap_last_attempt: None,
        bootstrap_manifest_status,
        bootstrap_manifest_last_checked: None,
        bootstrap_manifest_last_success,
        bootstrap_manifest_peer_count,
        bootstrap_manifest_listed,
        bootstrap_manifest_url: None,
        bootstrap_recovery_checks: 0,
        recent_events: VecDeque::new(),
        pending: HashMap::new(),
        pending_mail: HashMap::new(),
        pending_authority: HashSet::new(),
        pending_verifications: Vec::new(),
        dialing_peers: initially_dialing_peers,
    };
    node.publish_snapshot().await?;
    tokio::spawn(async move {
        if let Err(error) = node.run().await {
            tracing::error!(error = %error, "Freedom node stopped unexpectedly");
        }
    });

    Ok(NodeHandle {
        commands,
        snapshot,
        local_peer,
    })
}

fn official_mail_peer(records: &[NameRecord]) -> Option<PeerId> {
    records
        .iter()
        .find(|record| record.hostname == "mail.freedom.net" && record.active && record.official)
        .and_then(|record| record.peer_id.as_deref())
        .and_then(|peer| PeerId::from_str(peer).ok())
}

fn migrate_managed_sites(
    storage: &Storage,
    sites: &mut [SiteConfig],
    legacy_htdocs: &Path,
    htdocs_root: &Path,
) {
    let Ok(legacy_root) = std::fs::canonicalize(legacy_htdocs) else {
        return;
    };
    if legacy_root == htdocs_root {
        return;
    }
    for site in sites {
        let source = PathBuf::from(&site.root);
        let Ok(source) = std::fs::canonicalize(&source) else {
            continue;
        };
        let Ok(relative) = source.strip_prefix(&legacy_root) else {
            continue;
        };
        if relative.as_os_str().is_empty() {
            continue;
        }
        let destination = htdocs_root.join(relative);
        if destination.exists() {
            warn!(
                site_id = %site.site_id,
                source = %source.display(),
                destination = %destination.display(),
                "managed-site migration skipped because the destination already exists"
            );
            continue;
        }
        let temporary = htdocs_root.join(format!(".freedom-migration-{}", Uuid::new_v4()));
        let result = copy_directory_without_links(&source, &temporary)
            .and_then(|()| std::fs::rename(&temporary, &destination).map_err(Into::into))
            .and_then(|()| {
                let canonical = std::fs::canonicalize(&destination)?;
                storage.set_site_root(&site.site_id, &canonical.to_string_lossy())?;
                site.root = canonical.to_string_lossy().into_owned();
                Ok(())
            });
        if let Err(error) = result {
            let _ = std::fs::remove_dir_all(&temporary);
            let _ = std::fs::remove_dir_all(&destination);
            warn!(site_id = %site.site_id, %error, "managed-site migration failed; legacy site remains active");
        } else {
            info!(site_id = %site.site_id, destination = %destination.display(), "managed site copied to app htdocs");
        }
    }
}

fn copy_directory_without_links(source: &Path, destination: &Path) -> Result<()> {
    let metadata = std::fs::symlink_metadata(source)?;
    if !metadata.is_dir() || metadata.file_type().is_symlink() {
        bail!("site migration source is not a plain directory");
    }
    std::fs::create_dir(destination)?;
    for entry in std::fs::read_dir(source)? {
        let entry = entry?;
        let metadata = std::fs::symlink_metadata(entry.path())?;
        if metadata.file_type().is_symlink() {
            bail!("site migration refuses links and junctions");
        }
        let target = destination.join(entry.file_name());
        if metadata.is_dir() {
            copy_directory_without_links(&entry.path(), &target)?;
        } else if metadata.is_file() {
            std::fs::copy(entry.path(), target)?;
        } else {
            bail!("site migration encountered an unsupported filesystem entry");
        }
    }
    Ok(())
}

#[derive(NetworkBehaviour)]
#[behaviour(to_swarm = "FreedomBehaviourEvent")]
struct FreedomBehaviour {
    mdns: Toggle<mdns::tokio::Behaviour>,
    identify: identify::Behaviour,
    kad: kad::Behaviour<kad::store::MemoryStore>,
    autonat: autonat::Behaviour,
    relay_client: relay::client::Behaviour,
    relay_server: Toggle<relay::Behaviour>,
    dcutr: dcutr::Behaviour,
    upnp: Toggle<upnp::tokio::Behaviour>,
    ping: ping::Behaviour,
    exchange: request_response::cbor::Behaviour<FreedomRequest, FreedomResponse>,
    peer_exchange: request_response::cbor::Behaviour<PeerExchangeRequest, PeerExchangeResponse>,
    authority_records:
        request_response::cbor::Behaviour<AuthorityRecordsRequest, AuthorityRecordsResponse>,
    mail: request_response::cbor::Behaviour<MailRequest, MailResponse>,
}

#[derive(Debug)]
enum FreedomBehaviourEvent {
    Mdns(mdns::Event),
    Identify(Box<identify::Event>),
    Kad(kad::Event),
    Autonat(autonat::Event),
    RelayClient(relay::client::Event),
    RelayServer(relay::Event),
    Dcutr(dcutr::Event),
    Upnp(upnp::Event),
    Ping(ping::Event),
    Exchange(request_response::Event<FreedomRequest, FreedomResponse>),
    PeerExchange(request_response::Event<PeerExchangeRequest, PeerExchangeResponse>),
    AuthorityRecords(request_response::Event<AuthorityRecordsRequest, AuthorityRecordsResponse>),
    Mail(request_response::Event<MailRequest, MailResponse>),
}

impl From<mdns::Event> for FreedomBehaviourEvent {
    fn from(event: mdns::Event) -> Self {
        Self::Mdns(event)
    }
}

impl From<identify::Event> for FreedomBehaviourEvent {
    fn from(event: identify::Event) -> Self {
        Self::Identify(Box::new(event))
    }
}

impl From<kad::Event> for FreedomBehaviourEvent {
    fn from(event: kad::Event) -> Self {
        Self::Kad(event)
    }
}

impl From<autonat::Event> for FreedomBehaviourEvent {
    fn from(event: autonat::Event) -> Self {
        Self::Autonat(event)
    }
}

impl From<relay::client::Event> for FreedomBehaviourEvent {
    fn from(event: relay::client::Event) -> Self {
        Self::RelayClient(event)
    }
}

impl From<relay::Event> for FreedomBehaviourEvent {
    fn from(event: relay::Event) -> Self {
        Self::RelayServer(event)
    }
}

impl From<dcutr::Event> for FreedomBehaviourEvent {
    fn from(event: dcutr::Event) -> Self {
        Self::Dcutr(event)
    }
}

impl From<upnp::Event> for FreedomBehaviourEvent {
    fn from(event: upnp::Event) -> Self {
        Self::Upnp(event)
    }
}

impl From<ping::Event> for FreedomBehaviourEvent {
    fn from(event: ping::Event) -> Self {
        Self::Ping(event)
    }
}

impl From<request_response::Event<FreedomRequest, FreedomResponse>> for FreedomBehaviourEvent {
    fn from(event: request_response::Event<FreedomRequest, FreedomResponse>) -> Self {
        Self::Exchange(event)
    }
}

impl From<request_response::Event<PeerExchangeRequest, PeerExchangeResponse>>
    for FreedomBehaviourEvent
{
    fn from(event: request_response::Event<PeerExchangeRequest, PeerExchangeResponse>) -> Self {
        Self::PeerExchange(event)
    }
}

impl From<request_response::Event<MailRequest, MailResponse>> for FreedomBehaviourEvent {
    fn from(event: request_response::Event<MailRequest, MailResponse>) -> Self {
        Self::Mail(event)
    }
}

impl From<request_response::Event<AuthorityRecordsRequest, AuthorityRecordsResponse>>
    for FreedomBehaviourEvent
{
    fn from(
        event: request_response::Event<AuthorityRecordsRequest, AuthorityRecordsResponse>,
    ) -> Self {
        Self::AuthorityRecords(event)
    }
}

enum NodeCommand {
    Dial {
        peer: ManualPeer,
        reply: oneshot::Sender<Result<String, String>>,
    },
    SendMessage {
        peer: PeerId,
        body: String,
        reply: oneshot::Sender<Result<String, String>>,
    },
    MarkConversationRead {
        peer: PeerId,
        reply: oneshot::Sender<Result<usize, String>>,
    },
    SendMail {
        recipient: String,
        subject: String,
        body: String,
        reply: oneshot::Sender<Result<String, String>>,
    },
    MarkMailRead {
        message_id: String,
        reply: oneshot::Sender<Result<usize, String>>,
    },
    FetchSite {
        peer: PeerId,
        site_id: String,
        path: String,
        request: SiteRequest,
        reply: oneshot::Sender<Result<HostedFile, String>>,
    },
    AddSite {
        site_id: String,
        name: String,
        root: PathBuf,
        reply: oneshot::Sender<Result<SiteConfig, String>>,
    },
    CreateSite {
        site_id: String,
        name: String,
        reply: oneshot::Sender<Result<SiteConfig, String>>,
    },
    UploadSiteFile {
        site_id: String,
        path: String,
        body: Vec<u8>,
        reply: oneshot::Sender<Result<UploadedFile, String>>,
    },
    SetSiteEnabled {
        site_id: String,
        enabled: bool,
        reply: oneshot::Sender<Result<SiteConfig, String>>,
    },
    SetContact {
        peer: PeerId,
        alias: Option<String>,
        trust_state: String,
        muted: bool,
        reply: oneshot::Sender<Result<ContactRecord, String>>,
    },
    UpdateDisplayName {
        display_name: String,
        reply: oneshot::Sender<Result<String, String>>,
    },
    #[cfg(feature = "authority")]
    SetAuthorityName {
        hostname: String,
        record: Option<NameRecord>,
        reply: oneshot::Sender<Result<u64, String>>,
    },
    Shutdown {
        reply: oneshot::Sender<()>,
    },
}

enum PendingRequest {
    Message {
        message_id: String,
        reply: oneshot::Sender<Result<String, String>>,
    },
    Site {
        reply: oneshot::Sender<Result<HostedFile, String>>,
    },
}

struct ExpectedDial {
    address: Multiaddr,
    normalized_fingerprint: String,
}

struct BootstrapRefreshResult {
    checked_at: i64,
    result: std::result::Result<(String, InternetConfig), String>,
}

struct FreedomNode {
    local_peer: PeerId,
    data_dir: PathBuf,
    htdocs_root: PathBuf,
    display_name: String,
    swarm: Swarm<FreedomBehaviour>,
    storage: Storage,
    sites: SiteRegistry,
    php: PhpRuntime,
    mail_address: String,
    name_records: Vec<NameRecord>,
    authority_peer: Option<PeerId>,
    authority_signer: Option<String>,
    name_manifest: Option<SignedNameManifest>,
    trusted_authority_signer: Option<PeerId>,
    manifest_cache_path: PathBuf,
    application_role: ApplicationRole,
    #[cfg(feature = "authority")]
    authority_signing_key: Option<libp2p::identity::Keypair>,
    #[cfg(feature = "authority")]
    official_mail_provider: Option<OfficialMailProvider>,
    mail_submissions: mpsc::Receiver<SubmittedMail>,
    mail_submission_task: tokio::task::JoinHandle<()>,
    commands: mpsc::Receiver<NodeCommand>,
    snapshot: Arc<RwLock<NodeSnapshot>>,
    listen_addresses: Vec<String>,
    internet_mode: String,
    internet_infrastructure: bool,
    nat_status: String,
    configured_bootstrap_peers: usize,
    configured_relay_peers: usize,
    internet_bootstrap_peers: Vec<InternetEndpoint>,
    internet_relay_peers: Vec<InternetEndpoint>,
    registered_internet_addresses: HashSet<Multiaddr>,
    relay_listener_addresses: HashSet<Multiaddr>,
    relay_reservations: HashSet<PeerId>,
    bootstrap_manifests: Vec<String>,
    bootstrap_cache_path: PathBuf,
    bootstrap_trust_anchors: HashSet<PeerId>,
    bootstrap_update_sender: mpsc::Sender<BootstrapRefreshResult>,
    bootstrap_updates: mpsc::Receiver<BootstrapRefreshResult>,
    bootstrap_refresh_in_flight: bool,
    bootstrap_last_attempt: Option<Instant>,
    bootstrap_manifest_status: String,
    bootstrap_manifest_last_checked: Option<i64>,
    bootstrap_manifest_last_success: Option<i64>,
    bootstrap_manifest_peer_count: usize,
    bootstrap_manifest_listed: bool,
    bootstrap_manifest_url: Option<String>,
    bootstrap_recovery_checks: u64,
    recent_events: VecDeque<String>,
    pending: HashMap<OutboundRequestId, PendingRequest>,
    pending_mail: HashMap<OutboundRequestId, String>,
    pending_authority: HashSet<OutboundRequestId>,
    pending_verifications: Vec<ExpectedDial>,
    dialing_peers: HashSet<PeerId>,
}

impl FreedomNode {
    #[cfg(feature = "authority")]
    fn official_provider_path(&self) -> Option<String> {
        self.official_mail_provider
            .as_ref()
            .map(|provider| provider.path().display().to_string())
    }

    #[cfg(not(feature = "authority"))]
    fn official_provider_path(&self) -> Option<String> {
        None
    }

    #[cfg(feature = "authority")]
    fn official_provider_present(&self) -> bool {
        self.official_mail_provider.is_some()
    }

    #[cfg(not(feature = "authority"))]
    fn official_provider_present(&self) -> bool {
        false
    }

    #[cfg(feature = "authority")]
    fn official_sender_allowed(&self, address: &str, peer: &PeerId) -> bool {
        self.official_mail_provider
            .as_ref()
            .is_some_and(|provider| provider.sender_allowed(address, peer))
    }

    #[cfg(not(feature = "authority"))]
    fn official_sender_allowed(&self, _address: &str, _peer: &PeerId) -> bool {
        false
    }

    #[cfg(feature = "authority")]
    fn deliver_official_mail(&self, mail: &MailRecord) -> Result<Option<bool>, String> {
        self.official_mail_provider
            .as_ref()
            .ok_or_else(|| "official mail provider is unavailable".to_string())?
            .deliver(mail)
    }

    #[cfg(not(feature = "authority"))]
    fn deliver_official_mail(&self, _mail: &MailRecord) -> Result<Option<bool>, String> {
        Err("official mail provider is unavailable".into())
    }

    fn request_bootstrap_refresh(&mut self, reason: &'static str) {
        if self.bootstrap_refresh_in_flight || self.bootstrap_manifests.is_empty() {
            return;
        }
        if reason != "startup" {
            self.bootstrap_recovery_checks = self.bootstrap_recovery_checks.saturating_add(1);
        }
        self.bootstrap_refresh_in_flight = true;
        self.bootstrap_last_attempt = Some(Instant::now());
        if self.bootstrap_manifest_last_success.is_none() {
            self.bootstrap_manifest_status = "Checking".into();
        }
        self.event(format!("Bootstrap manifest check started: {reason}"));

        let urls = self.bootstrap_manifests.clone();
        let cache_path = self.bootstrap_cache_path.clone();
        let anchors = self
            .bootstrap_trust_anchors
            .iter()
            .copied()
            .collect::<Vec<_>>();
        let sender = self.bootstrap_update_sender.clone();
        tokio::spawn(async move {
            let checked_at = unix_timestamp();
            let result = tokio::task::spawn_blocking(move || {
                let mut errors = Vec::new();
                for url in urls {
                    match fetch_bootstrap_manifest(&url) {
                        Ok((config, bytes)) => {
                            if anchors.is_empty() || !config.contains_any_peer(anchors.iter()) {
                                errors.push(format!(
                                    "{url}: manifest does not include a pinned bootstrap PeerID"
                                ));
                                continue;
                            }
                            if let Err(error) = store_bootstrap_manifest_cache(&cache_path, &bytes)
                            {
                                errors.push(format!("{url}: could not cache manifest: {error}"));
                                continue;
                            }
                            return Ok((url, config));
                        }
                        Err(error) => errors.push(format!("{url}: {error}")),
                    }
                }
                Err(if errors.is_empty() {
                    "no bootstrap manifest URLs are configured".into()
                } else {
                    errors.join("; ")
                })
            })
            .await
            .unwrap_or_else(|error| Err(format!("bootstrap worker stopped: {error}")));
            let _ = sender
                .send(BootstrapRefreshResult { checked_at, result })
                .await;
        });
    }

    fn bootstrap_refresh_due(&self) -> bool {
        if self.bootstrap_refresh_in_flight || self.bootstrap_manifests.is_empty() {
            return false;
        }
        let Some(last_attempt) = self.bootstrap_last_attempt else {
            return true;
        };
        let disconnected = self.swarm.connected_peers().next().is_none();
        let delay = if self.application_role == ApplicationRole::Authority {
            Duration::from_secs(15 * 60)
        } else if disconnected {
            Duration::from_secs(5 * 60)
        } else {
            Duration::from_secs(6 * 60 * 60)
        };
        last_attempt.elapsed() >= delay
    }

    fn handle_bootstrap_refresh(&mut self, update: BootstrapRefreshResult) -> bool {
        self.bootstrap_refresh_in_flight = false;
        self.bootstrap_manifest_last_checked = Some(update.checked_at);
        match update.result {
            Ok((url, config)) => {
                self.bootstrap_manifest_status = "Online".into();
                self.bootstrap_manifest_last_success = Some(update.checked_at);
                self.bootstrap_manifest_peer_count = config.unique_peer_count();
                self.bootstrap_manifest_listed = config.contains_any_peer([&self.local_peer]);
                self.bootstrap_manifest_url = Some(url.clone());
                self.apply_discovered_internet(config);
                self.event(format!(
                    "Bootstrap manifest online: {url} · {} peer(s)",
                    self.bootstrap_manifest_peer_count
                ));
                true
            }
            Err(error) => {
                self.bootstrap_manifest_status = if self.bootstrap_manifest_last_success.is_some() {
                    "Offline · using last known good".into()
                } else {
                    "Offline · using packaged peers".into()
                };
                self.event(format!("Bootstrap manifest unavailable: {error}"));
                true
            }
        }
    }

    fn apply_discovered_internet(&mut self, config: InternetConfig) -> bool {
        let mut changed = false;
        for endpoint in config.bootstrap_peers {
            if endpoint.peer_id == self.local_peer
                || self
                    .internet_bootstrap_peers
                    .iter()
                    .any(|existing| existing.address == endpoint.address)
            {
                continue;
            }
            self.register_internet_endpoint(&endpoint, false);
            self.internet_bootstrap_peers.push(endpoint);
            changed = true;
        }
        for endpoint in config.relay_peers {
            if endpoint.peer_id == self.local_peer
                || self
                    .internet_relay_peers
                    .iter()
                    .any(|existing| existing.address == endpoint.address)
            {
                continue;
            }
            self.register_internet_endpoint(&endpoint, true);
            self.internet_relay_peers.push(endpoint);
            changed = true;
        }
        self.configured_bootstrap_peers = self.internet_bootstrap_peers.len();
        self.configured_relay_peers = self.internet_relay_peers.len();
        self.internet_mode = if self.internet_infrastructure {
            "Infrastructure server"
        } else if !self.internet_relay_peers.is_empty() {
            "Internet via relay"
        } else if !self.internet_bootstrap_peers.is_empty() {
            "Internet direct"
        } else {
            "Direct/LAN"
        }
        .into();
        if changed {
            let _ = self.swarm.behaviour_mut().kad.bootstrap();
        }
        changed
    }

    fn register_internet_endpoint(&mut self, endpoint: &InternetEndpoint, relay: bool) {
        if self
            .registered_internet_addresses
            .insert(endpoint.address.clone())
        {
            let transport_address = endpoint.transport_address();
            self.swarm
                .behaviour_mut()
                .kad
                .add_address(&endpoint.peer_id, transport_address.clone());
            self.swarm
                .behaviour_mut()
                .autonat
                .add_server(endpoint.peer_id, Some(transport_address.clone()));
            self.swarm
                .add_peer_address(endpoint.peer_id, transport_address);
        }
        if relay
            && self
                .relay_listener_addresses
                .insert(endpoint.address.clone())
        {
            let relay_listener = endpoint
                .address
                .clone()
                .with(libp2p::multiaddr::Protocol::P2pCircuit);
            if let Err(error) = self.swarm.listen_on(relay_listener) {
                self.event(format!(
                    "Could not request relay reservation from {}: {error}",
                    endpoint.peer_id
                ));
            }
        }
        if !self.swarm.is_connected(&endpoint.peer_id)
            && !self.dialing_peers.contains(&endpoint.peer_id)
        {
            match self.swarm.dial(endpoint.peer_id) {
                Ok(()) => {
                    self.dialing_peers.insert(endpoint.peer_id);
                }
                Err(error) => {
                    debug!(peer = %endpoint.peer_id, %error, "Internet peer dial could not start");
                }
            }
        }
    }

    fn retry_internet_peers(&mut self) -> bool {
        let peers = self
            .internet_bootstrap_peers
            .iter()
            .chain(&self.internet_relay_peers)
            .map(|endpoint| endpoint.peer_id)
            .collect::<HashSet<_>>();
        let mut changed = false;
        for peer in peers {
            if peer == self.local_peer
                || self.swarm.is_connected(&peer)
                || self.dialing_peers.contains(&peer)
            {
                continue;
            }
            match self.swarm.dial(peer) {
                Ok(()) => {
                    self.dialing_peers.insert(peer);
                    self.event(format!("Internet bootstrap reconnect started: {peer}"));
                    changed = true;
                }
                Err(error) => {
                    debug!(%peer, %error, "Internet bootstrap reconnect could not start");
                }
            }
        }
        changed
    }

    async fn run(mut self) -> Result<()> {
        self.event(format!(
            "Identity ready: {} · {}",
            self.display_name,
            fingerprint_for_peer(&self.local_peer)
                .chars()
                .take(3)
                .collect::<String>()
        ));
        self.event(format!("Network mode: {}", self.internet_mode));
        if self.configured_bootstrap_peers == 0 && self.configured_relay_peers == 0 {
            self.event(
                "No Internet bootstrap or relay peers configured; direct and LAN connections remain available"
                    .into(),
            );
        }
        if let Some(path) = self.official_provider_path() {
            self.event(format!("Official Freedom mail provider ready: {path}"));
        }
        self.request_bootstrap_refresh("startup");
        self.publish_snapshot().await?;
        let mut reconnect = tokio::time::interval_at(
            tokio::time::Instant::now() + Duration::from_secs(2),
            Duration::from_secs(5),
        );
        reconnect.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        let mut authority_refresh = tokio::time::interval_at(
            tokio::time::Instant::now() + Duration::from_secs(3),
            Duration::from_secs(15),
        );
        authority_refresh.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);
        let mut internet_maintenance = tokio::time::interval_at(
            tokio::time::Instant::now() + Duration::from_secs(10),
            Duration::from_secs(30),
        );
        internet_maintenance.set_missed_tick_behavior(tokio::time::MissedTickBehavior::Skip);

        loop {
            tokio::select! {
                command = self.commands.recv() => {
                    match command {
                        Some(NodeCommand::Shutdown { reply }) => {
                            let _ = reply.send(());
                            break;
                        }
                        Some(command) => self.handle_command(command).await,
                        None => break,
                    }
                }
                submission = self.mail_submissions.recv() => {
                    if let Some(submission) = submission {
                        let result = self.queue_mail_from(
                            submission.sender.as_deref(),
                            &submission.recipient,
                            &submission.subject,
                            &submission.body,
                        );
                        if let Err(error) = result {
                            self.event(format!("Local mail submission rejected: {error}"));
                        }
                        let _ = self.publish_snapshot().await;
                    }
                }
                update = self.bootstrap_updates.recv() => {
                    if let Some(update) = update {
                        self.handle_bootstrap_refresh(update);
                        let _ = self.publish_snapshot().await;
                    }
                }
                event = self.swarm.select_next_some() => {
                    self.handle_swarm_event(event).await;
                }
                _ = reconnect.tick() => {
                    let peers_changed = self.retry_known_peers();
                    let mail_changed = self.retry_queued_mail();
                    if peers_changed || mail_changed {
                        let _ = self.publish_snapshot().await;
                    }
                }
                _ = authority_refresh.tick() => {
                    let changed = self.refresh_authority_registry();
                    self.request_authority_records_from_connected_peers();
                    if changed {
                        let _ = self.publish_snapshot().await;
                    }
                }
                _ = internet_maintenance.tick() => {
                    let mut changed = self.retry_internet_peers();
                    if self.bootstrap_refresh_due() {
                        let reason = if self.swarm.connected_peers().next().is_none() {
                            "network recovery"
                        } else {
                            "periodic refresh"
                        };
                        self.request_bootstrap_refresh(reason);
                        changed = true;
                    }
                    if changed {
                        let _ = self.publish_snapshot().await;
                    }
                }
            }
        }
        self.mail_submission_task.abort();
        Ok(())
    }

    async fn handle_command(&mut self, command: NodeCommand) {
        match command {
            NodeCommand::Dial { peer, reply } => {
                let address = peer.address.clone();
                let peer_id = peer_id_from_address(&address);
                let address_without_peer = without_trailing_peer(&address);
                if let Some(peer_id) = peer_id {
                    if self
                        .storage
                        .is_blocked(&peer_id.to_string())
                        .unwrap_or(true)
                    {
                        let _ = reply.send(Err("peer is blocked".into()));
                        return;
                    }
                    self.swarm
                        .add_peer_address(peer_id, address_without_peer.clone());
                    self.swarm
                        .behaviour_mut()
                        .kad
                        .add_address(&peer_id, address_without_peer.clone());
                }
                if let Some(expected) = peer.expected_fingerprint {
                    if let Some(peer_id) = peer_id {
                        let received = fingerprint_for_peer(&peer_id);
                        let actual = normalize_fingerprint(&received).unwrap_or_default();
                        if actual != expected {
                            let message = format!(
                                "expected fingerprint {}, received {received}",
                                grouped_fingerprint(&expected)
                            );
                            self.event(format!("SECURITY WARNING: {message}"));
                            let _ = reply.send(Err(message));
                            let _ = self.publish_snapshot().await;
                            return;
                        }
                    }
                    self.pending_verifications.push(ExpectedDial {
                        address: address_without_peer.clone(),
                        normalized_fingerprint: expected,
                    });
                }

                if let Some(peer_id) = peer_id {
                    if self.swarm.is_connected(&peer_id) {
                        self.pending_verifications
                            .retain(|pending| pending.address != address_without_peer);
                        let _ = reply.send(Ok(format!("Already connected to {peer_id}")));
                        return;
                    }
                    if self.dialing_peers.contains(&peer_id) {
                        let _ = reply.send(Ok(format!(
                            "Connection to {peer_id} is already in progress"
                        )));
                        return;
                    }
                }
                let result = self
                    .swarm
                    .dial(address.clone())
                    .map(|_| {
                        if let Some(peer_id) = peer_id {
                            self.dialing_peers.insert(peer_id);
                            let _ = self.storage.mark_dial_started(&peer_id.to_string());
                        }
                        self.event(format!("Manual dial started: {address}"));
                        format!("Connecting to {address}")
                    })
                    .map_err(|error| error.to_string());
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::SendMessage { peer, body, reply } => {
                if body.is_empty() || body.len() > MAX_MESSAGE_BYTES {
                    let _ = reply.send(Err("invalid message size".into()));
                    return;
                }
                if self.storage.is_blocked(&peer.to_string()).unwrap_or(true) {
                    let _ = reply.send(Err("peer is blocked".into()));
                    return;
                }
                let message_id = Uuid::new_v4().to_string();
                let message = MessageRecord {
                    id: message_id.clone(),
                    direction: "out".into(),
                    peer_id: peer.to_string(),
                    timestamp: unix_timestamp(),
                    body: body.clone(),
                    state: "sending".into(),
                    read: true,
                };
                if let Err(error) = self.storage.insert_message(&message) {
                    let _ = reply.send(Err(error.to_string()));
                    return;
                }
                let request_id = self.swarm.behaviour_mut().exchange.send_request(
                    &peer,
                    FreedomRequest::Message {
                        id: message_id.clone(),
                        recipient: peer.to_string(),
                        sent_at: message.timestamp,
                        body,
                    },
                );
                self.pending
                    .insert(request_id, PendingRequest::Message { message_id, reply });
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::MarkConversationRead { peer, reply } => {
                let result = self
                    .storage
                    .mark_conversation_read(&peer.to_string())
                    .map_err(|error| error.to_string());
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::SendMail {
                recipient,
                subject,
                body,
                reply,
            } => {
                let result = self.queue_mail(&recipient, &subject, &body);
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::MarkMailRead { message_id, reply } => {
                let result = self
                    .storage
                    .mark_mail_read(&message_id)
                    .map_err(|error| error.to_string());
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::FetchSite {
                peer,
                site_id,
                path,
                request,
                reply,
            } => {
                if self.storage.is_blocked(&peer.to_string()).unwrap_or(true) {
                    let _ = reply.send(Err("peer is blocked".into()));
                    return;
                }
                if peer == self.local_peer {
                    let requester_peer_id = self.local_peer.to_string();
                    let result = Self::serve_local_site(
                        &self.sites,
                        &self.php,
                        &site_id,
                        &path,
                        &requester_peer_id,
                        &request,
                    )
                    .await;
                    let _ = reply.send(result);
                } else {
                    let request_id = self.swarm.behaviour_mut().exchange.send_request(
                        &peer,
                        FreedomRequest::Site {
                            site_id,
                            path,
                            method: request.method,
                            query: request.query,
                            content_type: request.content_type,
                            authorization: request.authorization,
                            headers: request.headers,
                            body: request.body,
                        },
                    );
                    self.pending
                        .insert(request_id, PendingRequest::Site { reply });
                }
            }
            NodeCommand::AddSite {
                site_id,
                name,
                root,
                reply,
            } => {
                let result = self
                    .sites
                    .register(&site_id, &name, &root, true)
                    .map_err(|error| error.to_string())
                    .and_then(|site| {
                        self.storage
                            .upsert_site(&site)
                            .map_err(|error| error.to_string())?;
                        Ok(site)
                    });
                if let Ok(site) = &result {
                    self.event(format!("Site enabled: {} ({})", site.name, site.site_id));
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::CreateSite {
                site_id,
                name,
                reply,
            } => {
                let result = self
                    .sites
                    .create_managed(&site_id, &name, &self.htdocs_root)
                    .map_err(|error| error.to_string())
                    .and_then(|site| {
                        self.storage
                            .upsert_site(&site)
                            .map_err(|error| error.to_string())?;
                        Ok(site)
                    });
                if let Ok(site) = &result {
                    self.event(format!(
                        "Managed site created: {} ({})",
                        site.name, site.site_id
                    ));
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::UploadSiteFile {
                site_id,
                path,
                body,
                reply,
            } => {
                let result = self
                    .sites
                    .write_file(&site_id, &path, &body)
                    .map_err(|error| error.to_string());
                if let Ok(upload) = &result {
                    self.event(format!(
                        "Site file uploaded: {site_id}/{} ({} bytes)",
                        upload.path, upload.bytes
                    ));
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::SetSiteEnabled {
                site_id,
                enabled,
                reply,
            } => {
                let result = self
                    .sites
                    .set_enabled(&site_id, enabled)
                    .map_err(|error| error.to_string())
                    .and_then(|site| {
                        self.storage
                            .upsert_site(&site)
                            .map_err(|error| error.to_string())?;
                        Ok(site)
                    });
                if let Ok(site) = &result {
                    self.event(format!(
                        "Site {}: {} ({})",
                        if site.enabled { "enabled" } else { "disabled" },
                        site.name,
                        site.site_id
                    ));
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::SetContact {
                peer,
                alias,
                trust_state,
                muted,
                reply,
            } => {
                let alias = alias
                    .map(|value| value.trim().to_owned())
                    .filter(|value| !value.is_empty());
                let contact = ContactRecord {
                    peer_id: peer.to_string(),
                    alias,
                    trust_state,
                    muted,
                    created_at: unix_timestamp(),
                };
                let result = self
                    .storage
                    .upsert_contact(&contact)
                    .map(|()| contact.clone())
                    .map_err(|error| error.to_string());
                if let Ok(contact) = &result {
                    if contact.trust_state == "blocked" {
                        self.dialing_peers.remove(&peer);
                        let _ = self.swarm.disconnect_peer_id(peer);
                    }
                    self.event(format!(
                        "Contact updated: {} is {}{}",
                        peer,
                        contact.trust_state,
                        if contact.muted { " and muted" } else { "" }
                    ));
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::UpdateDisplayName {
                display_name,
                reply,
            } => {
                let result = FreedomIdentity::update_display_name(&self.data_dir, &display_name)
                    .map_err(|error| error.to_string());
                if let Ok(display_name) = &result {
                    self.display_name.clone_from(display_name);
                    self.event(format!("Display name updated: {display_name}"));
                    self.announce_profile();
                }
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            #[cfg(feature = "authority")]
            NodeCommand::SetAuthorityName {
                hostname,
                record,
                reply,
            } => {
                let result = self.update_authority_name_assignment(&hostname, record);
                let _ = reply.send(result);
                let _ = self.publish_snapshot().await;
            }
            NodeCommand::Shutdown { .. } => unreachable!(),
        }
    }

    async fn handle_swarm_event(&mut self, event: SwarmEvent<FreedomBehaviourEvent>) {
        let mut refresh = false;
        match event {
            SwarmEvent::NewListenAddr { address, .. } => {
                let advertised = address.with(libp2p::multiaddr::Protocol::P2p(self.local_peer));
                let value = advertised.to_string();
                if !self.listen_addresses.contains(&value) {
                    self.listen_addresses.push(value.clone());
                }
                self.event(format!("Listening on {value}"));
                info!(address = %value, "Freedom node listening");
                refresh = true;
            }
            SwarmEvent::ConnectionEstablished {
                peer_id,
                endpoint,
                established_in,
                ..
            } => {
                self.dialing_peers.remove(&peer_id);
                let remote_address = endpoint.get_remote_address().clone();
                let fingerprint = fingerprint_for_peer(&peer_id);
                if self
                    .storage
                    .is_blocked(&peer_id.to_string())
                    .unwrap_or(false)
                {
                    self.event(format!("Blocked peer connection refused: {peer_id}"));
                    let _ = self.swarm.disconnect_peer_id(peer_id);
                    refresh = true;
                } else if !self.verify_expected(&remote_address, &fingerprint) {
                    warn!(peer = %peer_id, "manual peer fingerprint mismatch");
                    let _ = self.swarm.disconnect_peer_id(peer_id);
                    refresh = true;
                } else {
                    let record = PeerRecord {
                        peer_id: peer_id.to_string(),
                        display_name: None,
                        fingerprint: fingerprint.clone(),
                        address: remote_address.to_string(),
                        last_seen: unix_timestamp(),
                        connected: true,
                    };
                    if let Err(error) = self.storage.record_peer(&record) {
                        warn!(%error, "could not persist connected peer");
                    }
                    let _ = self.storage.set_peer_connected(&peer_id.to_string(), true);
                    self.request_peer_exchange(peer_id);
                    self.request_authority_records(peer_id);
                    self.event(format!(
                        "Secure peer connected: {} · {} ({} ms)",
                        &fingerprint[..3],
                        peer_id,
                        established_in.as_millis()
                    ));
                    refresh = true;
                }
            }
            SwarmEvent::ConnectionClosed { peer_id, .. } => {
                let still_connected = self.swarm.is_connected(&peer_id);
                let _ = self
                    .storage
                    .set_peer_connected(&peer_id.to_string(), still_connected);
                if !still_connected {
                    self.relay_reservations.remove(&peer_id);
                    self.event(format!("Peer disconnected: {peer_id}"));
                }
                refresh = true;
            }
            SwarmEvent::OutgoingConnectionError { peer_id, error, .. } => {
                if let Some(peer_id) = &peer_id {
                    self.dialing_peers.remove(peer_id);
                    let _ = self.storage.mark_dial_failed(&peer_id.to_string());
                }
                self.event(format!(
                    "Connection failed{}: {error}",
                    peer_id.map(|peer| format!(" ({peer})")).unwrap_or_default()
                ));
                refresh = true;
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Mdns(event)) => {
                refresh |= self.handle_mdns(event);
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Identify(event)) => {
                refresh |= self.handle_identify(*event);
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Kad(event)) => match event {
                kad::Event::RoutingUpdated {
                    peer, is_new_peer, ..
                } => {
                    if is_new_peer {
                        self.event(format!("DHT route learned: {peer}"));
                    }
                    refresh = true;
                }
                kad::Event::ModeChanged { new_mode } => {
                    self.event(format!("Freedom DHT mode: {new_mode}"));
                    refresh = true;
                }
                other => debug!(event = ?other, "Freedom DHT event"),
            },
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Autonat(event)) => match event {
                autonat::Event::StatusChanged { new, .. } => {
                    self.nat_status = match new {
                        autonat::NatStatus::Public(address) => format!("Public ({address})"),
                        autonat::NatStatus::Private => "Private / behind NAT".into(),
                        autonat::NatStatus::Unknown => "Unknown".into(),
                    };
                    self.event(format!("Internet reachability: {}", self.nat_status));
                    refresh = true;
                }
                other => debug!(event = ?other, "AutoNAT event"),
            },
            SwarmEvent::Behaviour(FreedomBehaviourEvent::RelayClient(event)) => match event {
                relay::client::Event::ReservationReqAccepted {
                    relay_peer_id,
                    renewal,
                    ..
                } => {
                    self.relay_reservations.insert(relay_peer_id);
                    self.event(format!(
                        "Relay reservation {}: {relay_peer_id}",
                        if renewal { "renewed" } else { "ready" }
                    ));
                    refresh = true;
                }
                relay::client::Event::OutboundCircuitEstablished { relay_peer_id, .. } => {
                    self.event(format!(
                        "Outbound relay circuit ready through {relay_peer_id}"
                    ));
                    refresh = true;
                }
                relay::client::Event::InboundCircuitEstablished { src_peer_id, .. } => {
                    self.event(format!("Inbound relay circuit accepted from {src_peer_id}"));
                    refresh = true;
                }
            },
            SwarmEvent::Behaviour(FreedomBehaviourEvent::RelayServer(event)) => match event {
                relay::Event::ReservationReqAccepted {
                    src_peer_id,
                    renewed,
                } => {
                    self.event(format!(
                        "Infrastructure relay reservation {} for {src_peer_id}",
                        if renewed { "renewed" } else { "accepted" }
                    ));
                    refresh = true;
                }
                relay::Event::CircuitReqAccepted {
                    src_peer_id,
                    dst_peer_id,
                } => {
                    self.event(format!(
                        "Infrastructure relay circuit: {src_peer_id} to {dst_peer_id}"
                    ));
                    refresh = true;
                }
                other => debug!(event = ?other, "relay server event"),
            },
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Dcutr(event)) => {
                match event.result {
                    Ok(_) => self.event(format!(
                        "Direct connection established after relay introduction: {}",
                        event.remote_peer_id
                    )),
                    Err(error) => {
                        debug!(peer = %event.remote_peer_id, %error, "direct hole punch was unavailable; relay remains usable")
                    }
                }
                refresh = true;
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Upnp(event)) => {
                match event {
                    upnp::Event::NewExternalAddr(address) => {
                        self.event(format!("Router port mapping ready: {address}"));
                    }
                    upnp::Event::ExpiredExternalAddr(address) => {
                        self.event(format!("Router port mapping expired: {address}"));
                    }
                    upnp::Event::GatewayNotFound => {
                        debug!("UPnP gateway was not found; configured relays remain available");
                    }
                    upnp::Event::NonRoutableGateway => {
                        debug!("UPnP gateway is not publicly routable");
                    }
                }
                refresh = true;
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Ping(event)) => {
                if let Err(error) = event.result {
                    debug!(peer = %event.peer, %error, "peer health check failed");
                }
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Exchange(event)) => {
                refresh |= self.handle_exchange(event).await;
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::PeerExchange(event)) => {
                refresh |= self.handle_peer_exchange(event);
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::AuthorityRecords(event)) => {
                refresh |= self.handle_authority_records(event);
            }
            SwarmEvent::Behaviour(FreedomBehaviourEvent::Mail(event)) => {
                refresh |= self.handle_mail(event);
            }
            other => debug!(event = ?other, "libp2p event"),
        }
        if refresh {
            let _ = self.publish_snapshot().await;
        }
    }

    fn handle_mdns(&mut self, event: mdns::Event) -> bool {
        match event {
            mdns::Event::Discovered(peers) => {
                for (peer, address) in peers {
                    if peer == self.local_peer {
                        continue;
                    }
                    if self.storage.is_blocked(&peer.to_string()).unwrap_or(true) {
                        continue;
                    }
                    let address_without_peer = without_trailing_peer(&address);
                    self.swarm
                        .add_peer_address(peer, address_without_peer.clone());
                    self.swarm
                        .behaviour_mut()
                        .kad
                        .add_address(&peer, address_without_peer.clone());
                    let fingerprint = fingerprint_for_peer(&peer);
                    let record = PeerRecord {
                        peer_id: peer.to_string(),
                        display_name: None,
                        fingerprint: fingerprint.clone(),
                        address: address.to_string(),
                        last_seen: unix_timestamp(),
                        connected: self.swarm.is_connected(&peer),
                    };
                    let _ = self.storage.record_peer(&record);
                    if !self.swarm.is_connected(&peer)
                        && !self.dialing_peers.contains(&peer)
                        && self.local_peer.to_bytes() < peer.to_bytes()
                    {
                        let dial =
                            address_without_peer.with(libp2p::multiaddr::Protocol::P2p(peer));
                        if self.swarm.dial(dial).is_ok() {
                            self.dialing_peers.insert(peer);
                            let _ = self.storage.mark_dial_started(&peer.to_string());
                        }
                    }
                    self.event(format!(
                        "LAN peer discovered: {} · {}",
                        &fingerprint[..3],
                        peer
                    ));
                }
                true
            }
            mdns::Event::Expired(peers) => {
                for (peer, address) in peers {
                    debug!(%peer, %address, "mDNS record expired");
                }
                false
            }
        }
    }

    fn handle_identify(&mut self, event: identify::Event) -> bool {
        if let identify::Event::Received { peer_id, info, .. } = event {
            if self
                .storage
                .is_blocked(&peer_id.to_string())
                .unwrap_or(true)
            {
                return false;
            }
            let display_name = info
                .agent_version
                .strip_prefix("Freedom/0.1; name=")
                .and_then(valid_remote_display_name);
            let mut address = String::new();
            for listen_address in info.listen_addrs {
                let mut advertised = listen_address;
                if !matches!(
                    advertised.iter().last(),
                    Some(libp2p::multiaddr::Protocol::P2p(_))
                ) {
                    advertised.push(libp2p::multiaddr::Protocol::P2p(peer_id));
                }
                if !valid_peer_address(&advertised, &peer_id) {
                    continue;
                }
                let transport_address = without_trailing_peer(&advertised);
                self.swarm
                    .behaviour_mut()
                    .kad
                    .add_address(&peer_id, transport_address.clone());
                self.swarm.add_peer_address(peer_id, transport_address);
                if address.is_empty() {
                    address = advertised.to_string();
                }
            }
            let record = PeerRecord {
                peer_id: peer_id.to_string(),
                display_name,
                fingerprint: fingerprint_for_peer(&peer_id),
                address,
                last_seen: unix_timestamp(),
                connected: self.swarm.is_connected(&peer_id),
            };
            let _ = self.storage.record_peer(&record);
            return true;
        }
        false
    }

    fn request_peer_exchange(&mut self, peer: PeerId) {
        self.swarm.behaviour_mut().peer_exchange.send_request(
            &peer,
            PeerExchangeRequest {
                limit: MAX_PEER_ADVERTISEMENTS as u16,
                requester_name: self.display_name.clone(),
            },
        );
    }

    fn request_authority_records(&mut self, peer: PeerId) {
        if self.trusted_authority_signer.is_none() {
            return;
        }
        let after_sequence = self
            .name_manifest
            .as_ref()
            .map(|manifest| manifest.sequence)
            .unwrap_or_default();
        let request_id = self
            .swarm
            .behaviour_mut()
            .authority_records
            .send_request(&peer, AuthorityRecordsRequest { after_sequence });
        self.pending_authority.insert(request_id);
    }

    fn request_authority_records_from_connected_peers(&mut self) {
        let peers = self.swarm.connected_peers().copied().collect::<Vec<_>>();
        for peer in peers {
            self.request_authority_records(peer);
        }
    }

    fn handle_authority_records(
        &mut self,
        event: request_response::Event<AuthorityRecordsRequest, AuthorityRecordsResponse>,
    ) -> bool {
        match event {
            request_response::Event::Message { peer, message, .. } => match message {
                request_response::Message::Request {
                    request, channel, ..
                } => {
                    let manifest = (!self.storage.is_blocked(&peer.to_string()).unwrap_or(true))
                        .then_some(self.name_manifest.as_ref())
                        .flatten()
                        .filter(|manifest| manifest.sequence > request.after_sequence);
                    let manifest_json = manifest.and_then(|manifest| {
                        serde_json::to_vec(manifest)
                            .ok()
                            .filter(|bytes| bytes.len() <= MAX_AUTHORITY_MANIFEST_BYTES)
                    });
                    let response = AuthorityRecordsResponse {
                        sequence: manifest
                            .map(|manifest| manifest.sequence)
                            .unwrap_or_default(),
                        manifest_json,
                    };
                    if self
                        .swarm
                        .behaviour_mut()
                        .authority_records
                        .send_response(channel, response)
                        .is_err()
                    {
                        debug!(%peer, "authority-record response channel closed");
                    }
                    false
                }
                request_response::Message::Response {
                    request_id,
                    response,
                } => {
                    self.pending_authority.remove(&request_id);
                    let Some(bytes) = response.manifest_json else {
                        return false;
                    };
                    if bytes.len() > MAX_AUTHORITY_MANIFEST_BYTES {
                        warn!(%peer, "oversized authority manifest rejected");
                        return false;
                    }
                    let Some(expected_signer) = self.trusted_authority_signer.as_ref() else {
                        return false;
                    };
                    let Ok(manifest) = serde_json::from_slice::<SignedNameManifest>(&bytes) else {
                        warn!(%peer, "invalid authority manifest JSON rejected");
                        return false;
                    };
                    let current_sequence = self
                        .name_manifest
                        .as_ref()
                        .map(|current| current.sequence)
                        .unwrap_or_default();
                    if response.sequence != manifest.sequence
                        || manifest.sequence <= current_sequence
                        || manifest.verify(Some(expected_signer)).is_err()
                    {
                        warn!(%peer, "untrusted or stale authority manifest rejected");
                        return false;
                    }
                    if self.application_role == ApplicationRole::Node
                        && let Err(error) = store_verified_manifest_cache(
                            &self.manifest_cache_path,
                            &manifest,
                            expected_signer,
                        )
                    {
                        warn!(%peer, %error, "could not cache verified authority manifest");
                        return false;
                    }
                    self.name_records.clone_from(&manifest.records);
                    self.authority_peer = official_mail_peer(&manifest.records);
                    self.authority_signer = Some(manifest.signer_peer_id.clone());
                    self.name_manifest = Some(manifest);
                    self.event(format!(
                        "Verified Freedom DNS update {} received from {peer}",
                        response.sequence
                    ));
                    true
                }
            },
            request_response::Event::OutboundFailure {
                request_id,
                peer,
                error,
                ..
            } => {
                self.pending_authority.remove(&request_id);
                debug!(%peer, %error, "authority-record request failed");
                false
            }
            request_response::Event::InboundFailure { peer, error, .. } => {
                debug!(%peer, %error, "authority-record inbound request failed");
                false
            }
            request_response::Event::ResponseSent { .. } => false,
        }
    }

    #[cfg(feature = "authority")]
    fn update_authority_name_assignment(
        &mut self,
        hostname: &str,
        record: Option<NameRecord>,
    ) -> Result<u64, String> {
        if self.application_role != ApplicationRole::Authority {
            return Err("DNS management is available only in Freedom Authority".into());
        }
        let hostname = hostname.trim().to_ascii_lowercase();
        if hostname.is_empty() || hostname.len() > 253 || !hostname.ends_with(".net") {
            return Err("official DNS names must be valid .net domains".into());
        }
        if record
            .as_ref()
            .is_some_and(|record| record.hostname != hostname)
        {
            return Err("DNS record hostname does not match the requested domain".into());
        }
        let signer = self
            .authority_signing_key
            .clone()
            .ok_or_else(|| "Authority signing identity is unavailable".to_string())?;
        let authority_dir = self.data_dir.join("authority");
        let mut assignments =
            load_authority_name_records(&authority_dir).map_err(|error| error.to_string())?;
        assignments.retain(|existing| existing.hostname != hostname);
        if let Some(record) = record {
            assignments.push(record);
        }
        assignments.sort_by(|left, right| left.hostname.cmp(&right.hostname));
        let published_sites = self
            .sites
            .list()
            .into_iter()
            .filter(|site| site.enabled)
            .map(|site| site.site_id)
            .collect::<HashSet<_>>();
        let records = merge_authority_name_records(
            official_name_records(Some(&self.local_peer), &published_sites),
            assignments.clone(),
        )
        .map_err(|error| error.to_string())?;
        store_authority_name_records(&authority_dir, assignments)
            .map_err(|error| error.to_string())?;
        let manifest = store_authority_manifest(&authority_dir, &signer, unix_timestamp(), records)
            .map_err(|error| error.to_string())?;
        self.name_records.clone_from(&manifest.records);
        self.authority_peer = official_mail_peer(&manifest.records);
        self.authority_signer = Some(manifest.signer_peer_id.clone());
        self.name_manifest = Some(manifest.clone());
        self.event(format!(
            "Freedom DNS update {} saved and signed",
            manifest.sequence
        ));
        Ok(manifest.sequence)
    }

    #[cfg(feature = "authority")]
    fn refresh_authority_registry(&mut self) -> bool {
        if self.application_role != ApplicationRole::Authority {
            return false;
        }
        let Some(signer) = self.authority_signing_key.as_ref() else {
            return false;
        };
        let published_sites = self
            .sites
            .list()
            .into_iter()
            .filter(|site| site.enabled)
            .map(|site| site.site_id)
            .collect::<HashSet<_>>();
        let authority_dir = self.data_dir.join("authority");
        let result = load_authority_name_records(&authority_dir)
            .and_then(|assignments| {
                merge_authority_name_records(
                    official_name_records(Some(&self.local_peer), &published_sites),
                    assignments,
                )
            })
            .and_then(|records| {
                store_authority_manifest(&authority_dir, signer, unix_timestamp(), records)
            });
        let manifest = match result {
            Ok(manifest) => manifest,
            Err(error) => {
                warn!(%error, "Freedom DNS assignment reload failed");
                return false;
            }
        };
        let current_sequence = self
            .name_manifest
            .as_ref()
            .map(|current| current.sequence)
            .unwrap_or_default();
        if manifest.sequence <= current_sequence {
            return false;
        }
        self.name_records.clone_from(&manifest.records);
        self.authority_peer = official_mail_peer(&manifest.records);
        self.authority_signer = Some(manifest.signer_peer_id.clone());
        self.name_manifest = Some(manifest.clone());
        self.event(format!(
            "Freedom DNS assignments signed as update {}",
            manifest.sequence
        ));
        true
    }

    #[cfg(not(feature = "authority"))]
    fn refresh_authority_registry(&mut self) -> bool {
        false
    }

    fn announce_profile(&mut self) {
        let peers = self.swarm.connected_peers().copied().collect::<Vec<_>>();
        for peer in peers {
            self.request_peer_exchange(peer);
        }
    }

    fn peer_advertisements(&self, requester: PeerId, limit: usize) -> Vec<PeerAdvertisement> {
        let Ok(peers) = self.storage.peers() else {
            return Vec::new();
        };
        peers
            .into_iter()
            .filter(|peer| peer.peer_id != requester.to_string() && !peer.address.is_empty())
            .filter(|peer| !self.storage.is_blocked(&peer.peer_id).unwrap_or(true))
            .filter_map(|peer| {
                let peer_id = PeerId::from_str(&peer.peer_id).ok()?;
                let mut address = Multiaddr::from_str(&peer.address).ok()?;
                if let Some(address_peer) = peer_id_from_address(&address) {
                    if address_peer != peer_id {
                        return None;
                    }
                } else {
                    address.push(libp2p::multiaddr::Protocol::P2p(peer_id));
                }
                valid_peer_address(&address, &peer_id).then_some(PeerAdvertisement {
                    peer_id: peer.peer_id,
                    address: address.to_string(),
                    display_name: peer
                        .display_name
                        .and_then(|name| valid_remote_display_name(&name)),
                })
            })
            .take(limit.min(MAX_PEER_ADVERTISEMENTS))
            .collect()
    }

    fn handle_peer_exchange(
        &mut self,
        event: request_response::Event<PeerExchangeRequest, PeerExchangeResponse>,
    ) -> bool {
        match event {
            request_response::Event::Message { peer, message, .. } => match message {
                request_response::Message::Request {
                    request, channel, ..
                } => {
                    let blocked = self.storage.is_blocked(&peer.to_string()).unwrap_or(true);
                    if !blocked {
                        self.record_remote_profile(peer, &request.requester_name);
                    }
                    let response = if blocked {
                        PeerExchangeResponse {
                            responder_name: String::new(),
                            peers: Vec::new(),
                        }
                    } else {
                        PeerExchangeResponse {
                            responder_name: self.display_name.clone(),
                            peers: self.peer_advertisements(peer, usize::from(request.limit)),
                        }
                    };
                    if self
                        .swarm
                        .behaviour_mut()
                        .peer_exchange
                        .send_response(channel, response)
                        .is_err()
                    {
                        warn!(%peer, "peer exchange response channel closed");
                    }
                    true
                }
                request_response::Message::Response { response, .. } => {
                    self.record_remote_profile(peer, &response.responder_name);
                    let mut accepted = 0;
                    for advertisement in response.peers.into_iter().take(MAX_PEER_ADVERTISEMENTS) {
                        if !self.storage.can_accept_introduced_peer().unwrap_or(false) {
                            break;
                        }
                        let Some((introduced_peer, address)) =
                            normalize_advertisement(&advertisement)
                        else {
                            continue;
                        };
                        if introduced_peer == self.local_peer
                            || introduced_peer == peer
                            || self
                                .storage
                                .is_blocked(&introduced_peer.to_string())
                                .unwrap_or(true)
                        {
                            continue;
                        }
                        let base_address = without_trailing_peer(&address);
                        self.swarm
                            .behaviour_mut()
                            .kad
                            .add_address(&introduced_peer, base_address.clone());
                        self.swarm.add_peer_address(introduced_peer, base_address);
                        let record = PeerRecord {
                            peer_id: introduced_peer.to_string(),
                            display_name: advertisement
                                .display_name
                                .as_deref()
                                .and_then(valid_remote_display_name),
                            fingerprint: fingerprint_for_peer(&introduced_peer),
                            address: address.to_string(),
                            last_seen: unix_timestamp(),
                            connected: self.swarm.is_connected(&introduced_peer),
                        };
                        if self.storage.record_peer(&record).is_ok() {
                            accepted += 1;
                        }
                    }
                    if accepted > 0 {
                        self.event(format!(
                            "Learned {accepted} bounded peer introduction(s) from {peer}"
                        ));
                    }
                    true
                }
            },
            request_response::Event::OutboundFailure { peer, error, .. } => {
                debug!(%peer, %error, "peer exchange request failed");
                false
            }
            request_response::Event::InboundFailure { peer, error, .. } => {
                debug!(%peer, %error, "peer exchange inbound request failed");
                false
            }
            request_response::Event::ResponseSent { .. } => false,
        }
    }

    fn record_remote_profile(&self, peer: PeerId, display_name: &str) {
        let Some(display_name) = valid_remote_display_name(display_name) else {
            return;
        };
        let _ = self.storage.record_peer(&PeerRecord {
            peer_id: peer.to_string(),
            display_name: Some(display_name),
            fingerprint: fingerprint_for_peer(&peer),
            address: String::new(),
            last_seen: unix_timestamp(),
            connected: self.swarm.is_connected(&peer),
        });
    }

    fn queue_mail(&mut self, recipient: &str, subject: &str, body: &str) -> Result<String, String> {
        let sender = self.mail_address.clone();
        self.queue_mail_from(Some(&sender), recipient, subject, body)
    }

    fn queue_mail_from(
        &mut self,
        sender: Option<&str>,
        recipient: &str,
        subject: &str,
        body: &str,
    ) -> Result<String, String> {
        let recipient_route = route_mailbox(recipient, self.authority_peer.as_ref())
            .map_err(|error| error.to_string())?;
        let sender_route = route_mailbox(
            sender.unwrap_or(&self.mail_address),
            self.authority_peer.as_ref(),
        )
        .map_err(|error| error.to_string())?;
        if sender_route.legacy_direct && sender_route.provider_peer != self.local_peer {
            return Err("mail sender does not belong to this Freedom node".into());
        }
        if !sender_route.legacy_direct
            && self.official_provider_present()
            && !self.official_sender_allowed(&sender_route.canonical, &self.local_peer)
        {
            return Err("mail sender is not an active Freedom account".into());
        }
        let subject = subject.trim();
        if subject.len() > MAX_MAIL_SUBJECT_BYTES || subject.chars().any(char::is_control) {
            return Err("mail subject is invalid".into());
        }
        let subject = if subject.is_empty() {
            "(No subject)"
        } else {
            subject
        };
        if body.len() > MAX_MAIL_BODY_BYTES || body.contains('\0') {
            return Err(format!(
                "mail body exceeds the {MAX_MAIL_BODY_BYTES} byte limit or contains invalid data"
            ));
        }
        if self
            .storage
            .is_blocked(&recipient_route.provider_peer.to_string())
            .unwrap_or(true)
        {
            return Err("recipient mail provider is blocked".into());
        }
        let id = Uuid::new_v4().to_string();
        let message = MailRecord {
            id: id.clone(),
            direction: "out".into(),
            peer_id: recipient_route.provider_peer.to_string(),
            sender: sender_route.canonical,
            recipient: recipient_route.canonical,
            timestamp: unix_timestamp(),
            subject: subject.to_owned(),
            body: body.to_owned(),
            state: "queued".into(),
            read: true,
        };
        self.storage
            .insert_mail(&message)
            .map_err(|error| error.to_string())?;
        if recipient_route.provider_peer == self.local_peer {
            let incoming = MailRecord {
                id: id.clone(),
                direction: "in".into(),
                peer_id: self.local_peer.to_string(),
                sender: message.sender.clone(),
                recipient: message.recipient.clone(),
                timestamp: message.timestamp,
                subject: message.subject.clone(),
                body: message.body.clone(),
                state: "received".into(),
                read: false,
            };
            if recipient_route.legacy_direct {
                self.storage
                    .insert_mail(&MailRecord {
                        id: Uuid::new_v4().to_string(),
                        ..incoming
                    })
                    .map_err(|error| error.to_string())?;
            } else {
                let delivery = self.deliver_official_mail(&incoming)?;
                if delivery.is_none() {
                    let _ = self.storage.set_mail_state(&id, "rejected");
                    return Err("recipient mailbox does not exist or is disabled".into());
                }
            }
            self.storage
                .set_mail_state(&id, "delivered")
                .map_err(|error| error.to_string())?;
        } else {
            self.dispatch_mail(message);
        }
        self.event(format!("Mail queued: {id}"));
        Ok(id)
    }

    fn dispatch_mail(&mut self, message: MailRecord) -> bool {
        if self
            .pending_mail
            .values()
            .any(|message_id| message_id == &message.id)
        {
            return false;
        }
        let Ok(peer) = PeerId::from_str(&message.peer_id) else {
            return false;
        };
        let request_id = self.swarm.behaviour_mut().mail.send_request(
            &peer,
            MailRequest::Deliver {
                id: message.id.clone(),
                sender: message.sender,
                recipient: message.recipient,
                sent_at: message.timestamp,
                subject: message.subject,
                body: message.body,
            },
        );
        self.pending_mail.insert(request_id, message.id);
        true
    }

    fn retry_queued_mail(&mut self) -> bool {
        let Ok(messages) = self.storage.queued_mail(8) else {
            return false;
        };
        let mut changed = false;
        for message in messages {
            let Ok(peer) = PeerId::from_str(&message.peer_id) else {
                continue;
            };
            if self.swarm.is_connected(&peer) {
                changed |= self.dispatch_mail(message);
            }
        }
        changed
    }

    fn handle_mail(&mut self, event: request_response::Event<MailRequest, MailResponse>) -> bool {
        match event {
            request_response::Event::Message { peer, message, .. } => match message {
                request_response::Message::Request {
                    request, channel, ..
                } => {
                    let MailRequest::Deliver {
                        id,
                        sender,
                        recipient,
                        sent_at,
                        subject,
                        body,
                    } = request;
                    let sender_route = route_mailbox(&sender, self.authority_peer.as_ref()).ok();
                    let recipient_route =
                        route_mailbox(&recipient, self.authority_peer.as_ref()).ok();
                    let sender_matches = sender_route.as_ref().is_some_and(|route| {
                        if route.legacy_direct {
                            route.provider_peer == peer
                        } else {
                            self.official_sender_allowed(&sender, &peer)
                        }
                    });
                    let recipient_matches = recipient_route.as_ref().is_some_and(|route| {
                        route.provider_peer == self.local_peer
                            && (route.legacy_direct
                                && route.canonical.eq_ignore_ascii_case(&self.mail_address)
                                || !route.legacy_direct && self.official_provider_present())
                    });
                    let blocked = self.storage.is_blocked(&peer.to_string()).unwrap_or(true);
                    let valid = Uuid::parse_str(&id).is_ok()
                        && sender_matches
                        && recipient_matches
                        && !blocked
                        && !subject.is_empty()
                        && subject.len() <= MAX_MAIL_SUBJECT_BYTES
                        && !subject.chars().any(char::is_control)
                        && body.len() <= MAX_MAIL_BODY_BYTES
                        && !body.contains('\0');
                    let (accepted, reason) = if valid {
                        let now = unix_timestamp();
                        let recipient_route =
                            recipient_route.as_ref().expect("validated mail route");
                        let record = MailRecord {
                            id: id.clone(),
                            direction: "in".into(),
                            peer_id: peer.to_string(),
                            sender: sender_route
                                .as_ref()
                                .expect("validated sender route")
                                .canonical
                                .clone(),
                            recipient: recipient_route.canonical.clone(),
                            timestamp: sent_at.clamp(now - 86_400, now + 300),
                            subject,
                            body,
                            state: "received".into(),
                            read: false,
                        };
                        let delivery = if recipient_route.legacy_direct {
                            self.storage
                                .insert_mail(&record)
                                .map(Some)
                                .map_err(|error| error.to_string())
                        } else {
                            self.deliver_official_mail(&record)
                        };
                        match delivery {
                            Ok(Some(true)) => {
                                self.event(format!("Encrypted mail received: {id} from {peer}"));
                                (true, None)
                            }
                            Ok(Some(false)) => (true, Some("duplicate".into())),
                            Ok(None) => (false, Some("recipient mailbox not found".into())),
                            Err(error) => (false, Some(error)),
                        }
                    } else {
                        (
                            false,
                            Some(if blocked {
                                "sender is blocked".into()
                            } else {
                                "invalid mail envelope or message size".into()
                            }),
                        )
                    };
                    if self
                        .swarm
                        .behaviour_mut()
                        .mail
                        .send_response(
                            channel,
                            MailResponse::DeliveryAck {
                                id,
                                accepted,
                                reason,
                            },
                        )
                        .is_err()
                    {
                        warn!(%peer, "mail response channel closed");
                    }
                    true
                }
                request_response::Message::Response {
                    request_id,
                    response,
                } => {
                    let Some(message_id) = self.pending_mail.remove(&request_id) else {
                        return false;
                    };
                    let MailResponse::DeliveryAck {
                        id,
                        accepted,
                        reason,
                    } = response;
                    if accepted && id == message_id {
                        let _ = self.storage.set_mail_state(&message_id, "delivered");
                        self.event(format!("Mail delivered: {message_id}"));
                    } else {
                        let _ = self.storage.set_mail_state(&message_id, "rejected");
                        self.event(format!(
                            "Mail rejected: {message_id} ({})",
                            reason.unwrap_or_else(|| "invalid acknowledgement".into())
                        ));
                    }
                    true
                }
            },
            request_response::Event::OutboundFailure {
                peer,
                request_id,
                error,
                ..
            } => {
                if let Some(message_id) = self.pending_mail.remove(&request_id) {
                    let _ = self.storage.set_mail_state(&message_id, "queued");
                    self.event(format!("Mail remains queued for {peer}: {error}"));
                    true
                } else {
                    false
                }
            }
            request_response::Event::InboundFailure { peer, error, .. } => {
                self.event(format!("Inbound mail from {peer} rejected: {error}"));
                true
            }
            request_response::Event::ResponseSent { .. } => false,
        }
    }

    async fn handle_exchange(
        &mut self,
        event: request_response::Event<FreedomRequest, FreedomResponse>,
    ) -> bool {
        match event {
            request_response::Event::Message { peer, message, .. } => match message {
                request_response::Message::Request {
                    request, channel, ..
                } => {
                    let response = self.handle_inbound_request(peer, request).await;
                    if self
                        .swarm
                        .behaviour_mut()
                        .exchange
                        .send_response(channel, response)
                        .is_err()
                    {
                        warn!(%peer, "response channel closed");
                    }
                    true
                }
                request_response::Message::Response {
                    request_id,
                    response,
                } => {
                    self.handle_outbound_response(request_id, response);
                    true
                }
            },
            request_response::Event::OutboundFailure {
                peer,
                request_id,
                error,
                ..
            } => {
                let text = format!("request to {peer} failed: {error}");
                if let Some(pending) = self.pending.remove(&request_id) {
                    match pending {
                        PendingRequest::Message { message_id, reply } => {
                            let _ = self.storage.set_message_state(&message_id, "failed");
                            let _ = reply.send(Err(text.clone()));
                        }
                        PendingRequest::Site { reply } => {
                            let _ = reply.send(Err(text.clone()));
                        }
                    }
                }
                self.event(text);
                true
            }
            request_response::Event::InboundFailure { peer, error, .. } => {
                self.event(format!("inbound request from {peer} rejected: {error}"));
                true
            }
            request_response::Event::ResponseSent { .. } => false,
        }
    }

    async fn handle_inbound_request(
        &mut self,
        peer: PeerId,
        request: FreedomRequest,
    ) -> FreedomResponse {
        let requester_peer_id = peer.to_string();
        match request {
            FreedomRequest::Message {
                id,
                recipient,
                sent_at,
                body,
            } => {
                let blocked = self.storage.is_blocked(&peer.to_string()).unwrap_or(true);
                let valid_id = Uuid::parse_str(&id).is_ok();
                let valid = recipient == self.local_peer.to_string()
                    && valid_id
                    && !blocked
                    && !body.is_empty()
                    && body.len() <= MAX_MESSAGE_BYTES;
                let (accepted, reason) = if valid {
                    let now = unix_timestamp();
                    let bounded_timestamp = sent_at.clamp(now - 86_400, now + 300);
                    let message = MessageRecord {
                        id: id.clone(),
                        direction: "in".into(),
                        peer_id: peer.to_string(),
                        timestamp: bounded_timestamp,
                        body,
                        state: "received".into(),
                        read: false,
                    };
                    match self.storage.insert_message(&message) {
                        Ok(true) => {
                            self.event(format!("Encrypted message received: {id} from {peer}"));
                            (true, None)
                        }
                        Ok(false) => (true, Some("duplicate".into())),
                        Err(error) => (false, Some(error.to_string())),
                    }
                } else {
                    (
                        false,
                        Some(if blocked {
                            "peer is blocked".into()
                        } else {
                            "invalid recipient, id, or message size".into()
                        }),
                    )
                };
                FreedomResponse::MessageAck {
                    id,
                    accepted,
                    reason,
                }
            }
            FreedomRequest::Site { .. }
                if self.storage.is_blocked(&peer.to_string()).unwrap_or(true) =>
            {
                FreedomResponse::Site {
                    found: false,
                    status_code: 403,
                    mime_type: "text/plain; charset=utf-8".into(),
                    body: Vec::new(),
                    sha256: String::new(),
                    www_authenticate: None,
                    headers: Vec::new(),
                    error: Some("peer is blocked".into()),
                }
            }
            FreedomRequest::Site {
                site_id,
                path,
                method,
                query,
                content_type,
                authorization,
                headers,
                body,
            } => match Self::serve_local_site(
                &self.sites,
                &self.php,
                &site_id,
                &path,
                &requester_peer_id,
                &SiteRequest {
                    method,
                    query,
                    content_type,
                    authorization,
                    headers,
                    body,
                },
            )
            .await
            {
                Ok(file) => FreedomResponse::Site {
                    found: true,
                    status_code: file.status_code,
                    mime_type: file.mime_type,
                    body: file.body,
                    sha256: file.sha256,
                    www_authenticate: file.www_authenticate,
                    headers: file.headers,
                    error: None,
                },
                Err(error) => FreedomResponse::Site {
                    found: false,
                    status_code: 404,
                    mime_type: "text/plain; charset=utf-8".into(),
                    body: Vec::new(),
                    sha256: String::new(),
                    www_authenticate: None,
                    headers: Vec::new(),
                    error: Some(error.to_string()),
                },
            },
        }
    }

    async fn serve_local_site(
        sites: &SiteRegistry,
        php: &PhpRuntime,
        site_id: &str,
        path: &str,
        requester_peer_id: &str,
        request: &SiteRequest,
    ) -> Result<HostedFile, String> {
        if sanitize_site_headers(&request.headers, request_header_allowed).is_none() {
            return Err("invalid site request headers".into());
        }
        let policy = sites
            .access_policy(site_id, path)
            .map_err(|error| error.to_string())?;
        match &policy {
            AccessPolicy::Denied => {
                return Ok(HostedFile::text(403, "Access denied", None));
            }
            AccessPolicy::Basic { realm, .. } => {
                let allowed = basic_credentials(request.authorization.as_deref())
                    .map(|(username, password)| authorize_basic(&policy, &username, &password))
                    .transpose()
                    .map_err(|error| error.to_string())?
                    .unwrap_or(false);
                if !allowed {
                    let realm = realm.replace('\\', "\\\\").replace('"', "\\\"");
                    return Ok(HostedFile::text(
                        401,
                        "Authentication required",
                        Some(format!("Basic realm=\"{realm}\", charset=\"UTF-8\"")),
                    ));
                }
            }
            AccessPolicy::Public => {}
        }
        let resolved = sites
            .resolve(site_id, path)
            .map_err(|error| error.to_string())?;
        if resolved.is_php {
            php.execute(
                &resolved,
                PhpRequest {
                    peer_id: requester_peer_id,
                    method: &request.method,
                    query: &request.query,
                    content_type: &request.content_type,
                    headers: &request.headers,
                    body: &request.body,
                },
            )
            .await
            .map_err(|error| error.to_string())
        } else if matches!(request.method.as_str(), "GET" | "HEAD") && request.body.is_empty() {
            sites
                .read_for_request(
                    site_id,
                    path,
                    request_header(&request.headers, "range"),
                    request.method == "HEAD",
                )
                .map_err(|error| error.to_string())
        } else {
            Err("POST requests require a PHP target".into())
        }
    }

    fn handle_outbound_response(
        &mut self,
        request_id: OutboundRequestId,
        response: FreedomResponse,
    ) {
        let Some(pending) = self.pending.remove(&request_id) else {
            return;
        };
        match (pending, response) {
            (
                PendingRequest::Message { message_id, reply },
                FreedomResponse::MessageAck {
                    id,
                    accepted,
                    reason: _,
                },
            ) if id == message_id && accepted => {
                let _ = self.storage.set_message_state(&message_id, "delivered");
                let _ = reply.send(Ok(message_id.clone()));
                self.event(format!("Message delivered: {message_id}"));
            }
            (PendingRequest::Message { message_id, reply }, response) => {
                let _ = self.storage.set_message_state(&message_id, "rejected");
                let error = match response {
                    FreedomResponse::MessageAck { reason, .. } => {
                        reason.unwrap_or_else(|| "peer rejected message".into())
                    }
                    _ => "unexpected peer response".into(),
                };
                let _ = reply.send(Err(error));
            }
            (
                PendingRequest::Site { reply },
                FreedomResponse::Site {
                    found: true,
                    status_code,
                    mime_type,
                    body,
                    sha256,
                    www_authenticate,
                    headers,
                    ..
                },
            ) if verify_hash(&body, &sha256) => {
                let Some(headers) = sanitize_site_headers(&headers, response_header_allowed) else {
                    let _ = reply.send(Err("peer returned invalid site response headers".into()));
                    return;
                };
                let _ = reply.send(Ok(HostedFile {
                    status_code,
                    mime_type,
                    body,
                    sha256,
                    www_authenticate,
                    headers,
                }));
            }
            (PendingRequest::Site { reply }, FreedomResponse::Site { error, .. }) => {
                let _ = reply.send(Err(
                    error.unwrap_or_else(|| "site content hash mismatch".into())
                ));
            }
            (PendingRequest::Site { reply }, _) => {
                let _ = reply.send(Err("unexpected peer response".into()));
            }
        }
    }

    fn verify_expected(&mut self, address: &Multiaddr, actual_fingerprint: &str) -> bool {
        let Some(index) = self
            .pending_verifications
            .iter()
            .position(|pending| addresses_match(&pending.address, address))
        else {
            return true;
        };
        let pending = self.pending_verifications.remove(index);
        let actual = normalize_fingerprint(actual_fingerprint).unwrap_or_default();
        if actual != pending.normalized_fingerprint {
            self.event(format!(
                "SECURITY WARNING: expected fingerprint {}, received {}",
                grouped_fingerprint(&pending.normalized_fingerprint),
                actual_fingerprint
            ));
            return false;
        }
        true
    }

    fn retry_known_peers(&mut self) -> bool {
        let Ok(candidates) = self.storage.reconnect_candidates(unix_timestamp(), 4) else {
            return false;
        };
        let mut changed = false;
        for candidate in candidates {
            let Ok(peer) = PeerId::from_str(&candidate.peer_id) else {
                continue;
            };
            if peer == self.local_peer
                || self.swarm.is_connected(&peer)
                || self.dialing_peers.contains(&peer)
            {
                continue;
            }
            let Ok(mut address) = Multiaddr::from_str(&candidate.address) else {
                continue;
            };
            if let Some(address_peer) = peer_id_from_address(&address) {
                if address_peer != peer {
                    continue;
                }
            } else {
                address.push(libp2p::multiaddr::Protocol::P2p(peer));
            }
            if !valid_peer_address(&address, &peer) {
                continue;
            }
            self.swarm
                .add_peer_address(peer, without_trailing_peer(&address));
            self.swarm
                .behaviour_mut()
                .kad
                .add_address(&peer, without_trailing_peer(&address));
            match self.swarm.dial(address) {
                Ok(()) => {
                    self.dialing_peers.insert(peer);
                    let _ = self.storage.mark_dial_started(&peer.to_string());
                    self.event(format!("Known peer reconnect started: {peer}"));
                }
                Err(error) => {
                    let _ = self.storage.mark_dial_failed(&peer.to_string());
                    debug!(%peer, %error, "known peer reconnect could not start");
                }
            }
            changed = true;
        }
        changed
    }

    fn event(&mut self, event: String) {
        if self.recent_events.len() == MAX_RECENT_EVENTS {
            self.recent_events.pop_front();
        }
        self.recent_events.push_back(event);
    }

    async fn publish_snapshot(&mut self) -> Result<()> {
        let has_tcp_listener = self
            .listen_addresses
            .iter()
            .any(|address| address.contains("/tcp/"));
        let has_quic_listener = self
            .listen_addresses
            .iter()
            .any(|address| address.contains("/udp/") && address.contains("/quic-v1"));
        let bootstrap_server_status = if !self.internet_infrastructure {
            "Not enabled"
        } else if has_tcp_listener && has_quic_listener {
            "Online · TCP + QUIC listening"
        } else if has_tcp_listener || has_quic_listener {
            "Degraded · one transport listening"
        } else {
            "Starting"
        };
        let mut snapshot = self.snapshot.write().await;
        snapshot.display_name.clone_from(&self.display_name);
        snapshot.application_role = self.application_role.as_str().into();
        snapshot.authority_signer.clone_from(&self.authority_signer);
        snapshot.htdocs_root = self.htdocs_root.to_string_lossy().into_owned();
        snapshot.php_available = self.php.available();
        snapshot.listen_addresses = self.listen_addresses.clone();
        snapshot.internet_mode.clone_from(&self.internet_mode);
        snapshot.nat_status.clone_from(&self.nat_status);
        snapshot.configured_bootstrap_peers = self.configured_bootstrap_peers;
        snapshot.configured_relay_peers = self.configured_relay_peers;
        snapshot.relay_reservations = self.relay_reservations.len();
        snapshot.dht_peers = self
            .swarm
            .behaviour_mut()
            .kad
            .kbuckets()
            .map(|bucket| bucket.num_entries())
            .sum();
        snapshot.bootstrap_manifest_url = self
            .bootstrap_manifest_url
            .clone()
            .or_else(|| self.bootstrap_manifests.first().cloned());
        snapshot
            .bootstrap_manifest_status
            .clone_from(&self.bootstrap_manifest_status);
        snapshot.bootstrap_manifest_last_checked = self.bootstrap_manifest_last_checked;
        snapshot.bootstrap_manifest_last_success = self.bootstrap_manifest_last_success;
        snapshot.bootstrap_manifest_peer_count = self.bootstrap_manifest_peer_count;
        snapshot.bootstrap_manifest_listed = self.bootstrap_manifest_listed;
        snapshot.bootstrap_recovery_checks = self.bootstrap_recovery_checks;
        snapshot.bootstrap_server_status = bootstrap_server_status.into();
        snapshot.peers = self.storage.peers()?;
        snapshot.messages = self.storage.messages()?;
        snapshot.sites = self.sites.list();
        snapshot.contacts = self.storage.contacts()?;
        snapshot.mail_address.clone_from(&self.mail_address);
        snapshot.mail_messages = self.storage.mail_messages()?;
        snapshot.names.clone_from(&self.name_records);
        snapshot.recent_events = self.recent_events.iter().rev().cloned().collect();
        Ok(())
    }
}

fn addresses_match(expected: &Multiaddr, actual: &Multiaddr) -> bool {
    without_trailing_peer(expected) == without_trailing_peer(actual)
}

fn without_trailing_peer(address: &Multiaddr) -> Multiaddr {
    let mut address = address.clone();
    if matches!(
        address.iter().last(),
        Some(libp2p::multiaddr::Protocol::P2p(_))
    ) {
        address.pop();
    }
    address
}

fn peer_id_from_address(address: &Multiaddr) -> Option<PeerId> {
    address
        .iter()
        .filter_map(|protocol| match protocol {
            libp2p::multiaddr::Protocol::P2p(peer_id) => Some(peer_id),
            _ => None,
        })
        .last()
}

fn request_header<'a>(headers: &'a [SiteHeader], name: &str) -> Option<&'a str> {
    headers
        .iter()
        .find(|header| header.name.eq_ignore_ascii_case(name))
        .map(|header| header.value.as_str())
}

fn sanitize_site_headers(
    headers: &[SiteHeader],
    allowed: fn(&str) -> bool,
) -> Option<Vec<SiteHeader>> {
    if headers.len() > 32 {
        return None;
    }
    let mut total = 0_usize;
    let mut sanitized = Vec::with_capacity(headers.len());
    for header in headers {
        let name = header.name.trim().to_ascii_lowercase();
        let value = header.value.trim().to_owned();
        total = total.checked_add(name.len() + value.len())?;
        if name.is_empty()
            || name.len() > 64
            || value.len() > 16 * 1024
            || total > 32 * 1024
            || !name
                .bytes()
                .all(|byte| byte.is_ascii_lowercase() || byte == b'-')
            || value.bytes().any(|byte| matches!(byte, b'\r' | b'\n' | 0))
            || !allowed(&name)
        {
            return None;
        }
        sanitized.push(SiteHeader { name, value });
    }
    Some(sanitized)
}

fn request_header_allowed(name: &str) -> bool {
    matches!(
        name,
        "accept"
            | "accept-language"
            | "cookie"
            | "host"
            | "if-modified-since"
            | "if-none-match"
            | "if-range"
            | "origin"
            | "range"
            | "referer"
            | "user-agent"
            | "x-requested-with"
    )
}

fn response_header_allowed(name: &str) -> bool {
    matches!(
        name,
        "accept-ranges"
            | "cache-control"
            | "content-disposition"
            | "content-length"
            | "content-range"
            | "etag"
            | "expires"
            | "last-modified"
            | "link"
            | "location"
            | "pragma"
            | "refresh"
            | "set-cookie"
            | "vary"
    )
}

fn valid_remote_display_name(value: &str) -> Option<String> {
    let value = value.trim();
    (!value.is_empty() && value.chars().count() <= 64 && !value.chars().any(char::is_control))
        .then(|| value.to_owned())
}

fn normalize_advertisement(advertisement: &PeerAdvertisement) -> Option<(PeerId, Multiaddr)> {
    if advertisement.peer_id.len() > 128 || advertisement.address.len() > 512 {
        return None;
    }
    let peer = PeerId::from_str(&advertisement.peer_id).ok()?;
    let mut address = Multiaddr::from_str(&advertisement.address).ok()?;
    if let Some(address_peer) = peer_id_from_address(&address) {
        if address_peer != peer {
            return None;
        }
    } else {
        address.push(libp2p::multiaddr::Protocol::P2p(peer));
    }
    valid_peer_address(&address, &peer).then_some((peer, address))
}

fn valid_peer_address(address: &Multiaddr, expected_peer: &PeerId) -> bool {
    use libp2p::multiaddr::Protocol;

    let protocols = address.iter().collect::<Vec<_>>();
    if !protocols.first().is_some_and(shareable_host_protocol) {
        return false;
    }
    matches!(
        protocols.as_slice(),
        [_, Protocol::Tcp(_), Protocol::P2p(peer)] if peer == expected_peer
    ) || matches!(
        protocols.as_slice(),
        [_, Protocol::Udp(_), Protocol::QuicV1, Protocol::P2p(peer)] if peer == expected_peer
    ) || matches!(
        protocols.as_slice(),
        [_, Protocol::Tcp(_), Protocol::P2p(relay), Protocol::P2pCircuit, Protocol::P2p(peer)]
            if peer == expected_peer && relay != expected_peer
    ) || matches!(
        protocols.as_slice(),
        [_, Protocol::Udp(_), Protocol::QuicV1, Protocol::P2p(relay), Protocol::P2pCircuit, Protocol::P2p(peer)]
            if peer == expected_peer && relay != expected_peer
    )
}

fn shareable_host_protocol(protocol: &libp2p::multiaddr::Protocol<'_>) -> bool {
    use libp2p::multiaddr::Protocol;

    match protocol {
        Protocol::Ip4(address) => !address.is_unspecified(),
        Protocol::Ip6(address) => !address.is_unspecified(),
        Protocol::Dns(name) | Protocol::Dns4(name) | Protocol::Dns6(name) => {
            !name.is_empty() && !name.chars().any(char::is_control)
        }
        _ => false,
    }
}

fn grouped_fingerprint(normalized: &str) -> String {
    normalized
        .as_bytes()
        .chunks(3)
        .map(|chunk| String::from_utf8_lossy(chunk))
        .collect::<Vec<_>>()
        .join("-")
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;

    async fn wait_until<F>(mut predicate: F) -> bool
    where
        F: AsyncFnMut() -> bool,
    {
        for _ in 0..200 {
            if predicate().await {
                return true;
            }
            tokio::time::sleep(Duration::from_millis(50)).await;
        }
        false
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 4)]
    async fn two_nodes_message_and_fetch_site_over_noise() {
        let first_dir = tempfile::tempdir().unwrap();
        let second_dir = tempfile::tempdir().unwrap();

        let first = spawn_node(NodeConfig {
            data_dir: first_dir.path().to_owned(),
            htdocs_dir: None,
            php_cgi: None,
            enable_mdns: false,
            display_name: "Alice".into(),
            listen_port: 0,
            role: ApplicationRole::Node,
            authority_manifest: None,
            trusted_authority_signer: None,
            internet: InternetConfig::default(),
        })
        .await
        .unwrap();
        let second = spawn_node(NodeConfig {
            data_dir: second_dir.path().to_owned(),
            htdocs_dir: None,
            php_cgi: None,
            enable_mdns: false,
            display_name: "Bob".into(),
            listen_port: 0,
            role: ApplicationRole::Node,
            authority_manifest: None,
            trusted_authority_signer: None,
            internet: InternetConfig::default(),
        })
        .await
        .unwrap();
        second.create_site("home", "Bob home").await.unwrap();
        second
            .upload_site_file("home", "index.html", b"<h1>Peer B</h1>".to_vec())
            .await
            .unwrap();
        second
            .upload_site_file("home", "admin/index.html", b"remote admin".to_vec())
            .await
            .unwrap();
        second
            .upload_site_file(
                "home",
                "admin/.htaccess",
                b"AuthType Basic\nAuthName \"Remote Admin\"\nAuthUserFile .htpasswd\nRequire valid-user\n"
                    .to_vec(),
            )
            .await
            .unwrap();
        second
            .upload_site_file(
                "home",
                "admin/.htpasswd",
                b"user1:$apr1$gxNb79DX$6wi9QaGNM5TA0kBKiC4710\n".to_vec(),
            )
            .await
            .unwrap();
        assert_eq!(
            Path::new(&second.snapshot().await.htdocs_root),
            fs::canonicalize(second_dir.path().join("htdocs")).unwrap()
        );

        assert!(
            wait_until(|| async { !second.snapshot().await.listen_addresses.is_empty() }).await,
            "second node did not listen: {:?}",
            second.snapshot().await
        );
        let second_address = second.snapshot().await.listen_addresses[0].clone();
        first
            .dial(ManualPeer {
                address: second_address.parse().unwrap(),
                expected_fingerprint: None,
            })
            .await
            .unwrap();
        assert!(
            wait_until(|| async {
                first.snapshot().await.peers.iter().any(|peer| {
                    peer.peer_id == second.local_peer_id().to_string()
                        && peer.connected
                        && peer.display_name.as_deref() == Some("Bob")
                })
            })
            .await,
            "nodes did not connect; first={:?}; second={:?}",
            first.snapshot().await,
            second.snapshot().await
        );

        first
            .send_message(&second.local_peer_id().to_string(), "hello over Noise")
            .await
            .unwrap();
        assert!(
            wait_until(|| async {
                second
                    .snapshot()
                    .await
                    .messages
                    .iter()
                    .any(|message| message.body == "hello over Noise")
            })
            .await,
            "message was not persisted; second={:?}",
            second.snapshot().await
        );
        let received = second
            .snapshot()
            .await
            .messages
            .into_iter()
            .find(|message| message.body == "hello over Noise")
            .unwrap();
        assert!(!received.read);
        assert_eq!(
            second
                .mark_conversation_read(&first.local_peer_id().to_string())
                .await
                .unwrap(),
            1
        );
        assert!(
            second
                .snapshot()
                .await
                .messages
                .iter()
                .find(|message| message.id == received.id)
                .unwrap()
                .read
        );

        let second_mailbox = second.snapshot().await.mail_address;
        let mail_id = first
            .send_mail(
                &second_mailbox,
                "Welcome to Freedom Mail",
                "This arrived over the dedicated mail protocol.",
            )
            .await
            .unwrap();
        assert!(
            wait_until(|| async {
                second
                    .snapshot()
                    .await
                    .mail_messages
                    .iter()
                    .any(|mail| mail.direction == "in" && mail.subject == "Welcome to Freedom Mail")
                    && first
                        .snapshot()
                        .await
                        .mail_messages
                        .iter()
                        .any(|mail| mail.id == mail_id && mail.state == "delivered")
            })
            .await,
            "mail was not delivered; first={:?}; second={:?}",
            first.snapshot().await,
            second.snapshot().await
        );
        let received_mail = second
            .snapshot()
            .await
            .mail_messages
            .into_iter()
            .find(|mail| mail.subject == "Welcome to Freedom Mail")
            .unwrap();
        assert!(!received_mail.read);
        assert_eq!(second.mark_mail_read(&received_mail.id).await.unwrap(), 1);

        let file = first
            .fetch_site(&second.local_peer_id().to_string(), "home", "")
            .await
            .unwrap();
        assert_eq!(file.body, b"<h1>Peer B</h1>");
        assert!(verify_hash(&file.body, &file.sha256));

        let challenge = first
            .request_site(
                &second.local_peer_id().to_string(),
                "home",
                "admin/index.html",
                SiteRequest::get(),
            )
            .await
            .unwrap();
        assert_eq!(challenge.status_code, 401);
        assert!(challenge.www_authenticate.is_some());
        let protected = first
            .request_site(
                &second.local_peer_id().to_string(),
                "home",
                "admin/index.html",
                SiteRequest {
                    authorization: Some("Basic dXNlcjE6bWlja2V5NQ==".into()),
                    ..SiteRequest::get()
                },
            )
            .await
            .unwrap();
        assert_eq!(protected.status_code, 200);
        assert_eq!(protected.body, b"remote admin");

        second.set_site_enabled("home", false).await.unwrap();
        assert!(
            first
                .fetch_site(&second.local_peer_id().to_string(), "home", "")
                .await
                .is_err()
        );
        second.set_site_enabled("home", true).await.unwrap();

        first.update_display_name("Alice Updated").await.unwrap();
        assert!(
            wait_until(|| async {
                second.snapshot().await.peers.iter().any(|peer| {
                    peer.peer_id == first.local_peer_id().to_string()
                        && peer.display_name.as_deref() == Some("Alice Updated")
                })
            })
            .await,
            "updated profile was not announced; second={:?}",
            second.snapshot().await
        );

        first
            .set_contact(
                &second.local_peer_id().to_string(),
                Some("Bob's laptop"),
                "blocked",
                true,
            )
            .await
            .unwrap();
        assert!(
            first
                .send_message(&second.local_peer_id().to_string(), "must not send")
                .await
                .is_err()
        );
        assert_eq!(first.snapshot().await.contacts[0].trust_state, "blocked");

        first.shutdown().await.unwrap();
        second.shutdown().await.unwrap();
    }

    #[tokio::test(flavor = "multi_thread", worker_threads = 2)]
    async fn local_host_enforces_htaccess_before_static_or_php_serving() {
        let data = tempfile::tempdir().unwrap();
        let node = spawn_node(NodeConfig {
            data_dir: data.path().to_owned(),
            htdocs_dir: None,
            php_cgi: None,
            enable_mdns: false,
            display_name: "Protected host".into(),
            listen_port: 0,
            role: ApplicationRole::Node,
            authority_manifest: None,
            trusted_authority_signer: None,
            internet: InternetConfig::default(),
        })
        .await
        .unwrap();
        node.create_site("legacy", "Legacy site").await.unwrap();
        node.upload_site_file("legacy", "admin/index.html", b"admin".to_vec())
            .await
            .unwrap();
        node.upload_site_file(
            "legacy",
            "admin/.htaccess",
            b"AuthType Basic\nAuthName \"Legacy Admin\"\nAuthUserFile .htpasswd\nRequire valid-user\n"
                .to_vec(),
        )
        .await
        .unwrap();
        node.upload_site_file(
            "legacy",
            "admin/.htpasswd",
            b"user1:$apr1$gxNb79DX$6wi9QaGNM5TA0kBKiC4710\n".to_vec(),
        )
        .await
        .unwrap();
        node.upload_site_file("legacy", "data/site.sqlite", b"database".to_vec())
            .await
            .unwrap();
        node.upload_site_file("legacy", "data/.htaccess", b"Require all denied\n".to_vec())
            .await
            .unwrap();

        let peer = node.local_peer_id().to_string();
        let challenge = node
            .request_site(&peer, "legacy", "admin/index.html", SiteRequest::get())
            .await
            .unwrap();
        assert_eq!(challenge.status_code, 401);
        assert_eq!(
            challenge.www_authenticate.as_deref(),
            Some("Basic realm=\"Legacy Admin\", charset=\"UTF-8\"")
        );

        let authorized = node
            .request_site(
                &peer,
                "legacy",
                "admin/index.html",
                SiteRequest {
                    authorization: Some("Basic dXNlcjE6bWlja2V5NQ==".into()),
                    ..SiteRequest::get()
                },
            )
            .await
            .unwrap();
        assert_eq!(authorized.status_code, 200);
        assert_eq!(authorized.body, b"admin");

        let denied = node
            .request_site(&peer, "legacy", "data/site.sqlite", SiteRequest::get())
            .await
            .unwrap();
        assert_eq!(denied.status_code, 403);
        assert!(
            node.request_site(&peer, "legacy", "admin/.htpasswd", SiteRequest::get())
                .await
                .is_ok_and(|response| response.status_code == 403)
        );
        node.shutdown().await.unwrap();
    }

    #[tokio::test]
    async fn managed_sites_migrate_to_a_new_htdocs_without_deleting_the_legacy_copy() {
        let data = tempfile::tempdir().unwrap();
        let portable = tempfile::tempdir().unwrap();
        let legacy_site = data.path().join("htdocs/home");
        fs::create_dir_all(&legacy_site).unwrap();
        fs::write(legacy_site.join("index.html"), "legacy content").unwrap();
        {
            let storage = Storage::open(&data.path().join("freedom.db")).unwrap();
            storage
                .upsert_site(&SiteConfig {
                    site_id: "home".into(),
                    name: "Home".into(),
                    root: fs::canonicalize(&legacy_site)
                        .unwrap()
                        .to_string_lossy()
                        .into_owned(),
                    enabled: true,
                })
                .unwrap();
        }

        let node = spawn_node(NodeConfig {
            data_dir: data.path().to_owned(),
            htdocs_dir: Some(portable.path().join("htdocs")),
            php_cgi: None,
            enable_mdns: false,
            display_name: "Portable".into(),
            listen_port: 0,
            role: ApplicationRole::Node,
            authority_manifest: None,
            trusted_authority_signer: None,
            internet: InternetConfig::default(),
        })
        .await
        .unwrap();
        let snapshot = node.snapshot().await;
        let migrated = portable.path().join("htdocs/home/index.html");
        assert_eq!(fs::read_to_string(&migrated).unwrap(), "legacy content");
        assert_eq!(
            Path::new(&snapshot.sites[0].root),
            fs::canonicalize(migrated.parent().unwrap()).unwrap()
        );
        assert_eq!(
            fs::read_to_string(legacy_site.join("index.html")).unwrap(),
            "legacy content"
        );
        node.shutdown().await.unwrap();
    }

    #[test]
    fn introduced_addresses_support_tcp_quic_and_relay_but_require_the_claimed_peer() {
        let first = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id();
        let second = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id();
        let valid = PeerAdvertisement {
            peer_id: first.to_string(),
            address: format!("/ip4/192.0.2.1/tcp/42100/p2p/{first}"),
            display_name: Some("Peer".into()),
        };
        assert!(normalize_advertisement(&valid).is_some());

        let mismatched = PeerAdvertisement {
            address: format!("/ip4/192.0.2.1/tcp/42100/p2p/{second}"),
            ..valid.clone()
        };
        assert!(normalize_advertisement(&mismatched).is_none());

        let unsupported = PeerAdvertisement {
            address: format!("/ip4/192.0.2.1/udp/42100/quic-v1/p2p/{first}"),
            ..valid
        };
        assert!(normalize_advertisement(&unsupported).is_some());

        let relay = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id();
        let relayed = PeerAdvertisement {
            peer_id: first.to_string(),
            address: format!(
                "/dns4/relay.freedom.net/tcp/42100/p2p/{relay}/p2p-circuit/p2p/{first}"
            ),
            display_name: Some("Relayed peer".into()),
        };
        assert!(normalize_advertisement(&relayed).is_some());

        let unspecified = PeerAdvertisement {
            peer_id: first.to_string(),
            address: format!("/ip4/0.0.0.0/tcp/42100/p2p/{first}"),
            display_name: None,
        };
        assert!(normalize_advertisement(&unspecified).is_none());
    }
}
