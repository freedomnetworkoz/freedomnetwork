use std::{borrow::Cow, net::IpAddr, str::FromStr};

use libp2p::{Multiaddr, multiaddr::Protocol};
use thiserror::Error;

pub const DEFAULT_FREEDOM_PORT: u16 = 42_100;

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct ManualPeer {
    pub address: Multiaddr,
    pub expected_fingerprint: Option<String>,
}

#[derive(Debug, Error, PartialEq, Eq)]
pub enum AddressError {
    #[error("peer address is empty")]
    Empty,
    #[error("invalid peer address: {0}")]
    Invalid(String),
    #[error("invalid port: {0}")]
    InvalidPort(String),
    #[error("invalid expected Freedom fingerprint")]
    InvalidFingerprint,
}

pub fn parse_manual_peer(
    input: &str,
    expected_fingerprint: Option<&str>,
) -> Result<ManualPeer, AddressError> {
    let input = input.trim();
    if input.is_empty() {
        return Err(AddressError::Empty);
    }

    let address = if input.starts_with('/') {
        Multiaddr::from_str(input).map_err(|_| AddressError::Invalid(input.to_owned()))?
    } else if let Ok(ip) = IpAddr::from_str(input) {
        ip_with_port(ip, DEFAULT_FREEDOM_PORT)
    } else if input.starts_with('[') {
        let close = input
            .find(']')
            .ok_or_else(|| AddressError::Invalid(input.to_owned()))?;
        let ip = input[1..close]
            .parse::<IpAddr>()
            .map_err(|_| AddressError::Invalid(input.to_owned()))?;
        let port = if input.len() == close + 1 {
            DEFAULT_FREEDOM_PORT
        } else {
            let suffix = input
                .get(close + 1..)
                .ok_or_else(|| AddressError::Invalid(input.to_owned()))?;
            let port_text = suffix
                .strip_prefix(':')
                .ok_or_else(|| AddressError::Invalid(input.to_owned()))?;
            parse_port(port_text)?
        };
        ip_with_port(ip, port)
    } else {
        parse_host_or_ipv4_with_port(input)?
    };

    let expected_fingerprint = expected_fingerprint
        .map(normalize_fingerprint)
        .transpose()?;

    Ok(ManualPeer {
        address,
        expected_fingerprint,
    })
}

pub fn normalize_fingerprint(value: &str) -> Result<String, AddressError> {
    let normalized: String = value
        .chars()
        .filter(|character| *character != '-' && !character.is_whitespace())
        .map(|character| character.to_ascii_uppercase())
        .collect();
    if normalized.len() != 15
        || !normalized
            .chars()
            .all(|character| character.is_ascii_uppercase() || character.is_ascii_digit())
    {
        return Err(AddressError::InvalidFingerprint);
    }
    Ok(normalized)
}

fn parse_host_or_ipv4_with_port(input: &str) -> Result<Multiaddr, AddressError> {
    let (host, port) = match input.rsplit_once(':') {
        Some((host, port_text)) if !host.contains(':') => (host, parse_port(port_text)?),
        Some(_) => return Err(AddressError::Invalid(input.to_owned())),
        None => (input, DEFAULT_FREEDOM_PORT),
    };

    if let Ok(ip) = host.parse::<IpAddr>() {
        return Ok(ip_with_port(ip, port));
    }

    validate_hostname(host)?;
    Ok(Multiaddr::empty()
        .with(Protocol::Dns(Cow::Owned(host.to_ascii_lowercase())))
        .with(Protocol::Tcp(port)))
}

fn parse_port(value: &str) -> Result<u16, AddressError> {
    let port = value
        .parse::<u16>()
        .map_err(|_| AddressError::InvalidPort(value.to_owned()))?;
    if port == 0 {
        return Err(AddressError::InvalidPort(value.to_owned()));
    }
    Ok(port)
}

fn validate_hostname(host: &str) -> Result<(), AddressError> {
    if host.is_empty()
        || host.len() > 253
        || host.starts_with('.')
        || host.ends_with('.')
        || host.split('.').any(|label| {
            label.is_empty()
                || label.len() > 63
                || label.starts_with('-')
                || label.ends_with('-')
                || !label
                    .chars()
                    .all(|character| character.is_ascii_alphanumeric() || character == '-')
        })
    {
        return Err(AddressError::Invalid(host.to_owned()));
    }
    Ok(())
}

fn ip_with_port(ip: IpAddr, port: u16) -> Multiaddr {
    let address = match ip {
        IpAddr::V4(ip) => Multiaddr::empty().with(Protocol::Ip4(ip)),
        IpAddr::V6(ip) => Multiaddr::empty().with(Protocol::Ip6(ip)),
    };
    address.with(Protocol::Tcp(port))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn accepts_required_manual_forms() {
        assert_eq!(
            parse_manual_peer("192.0.2.8", None)
                .unwrap()
                .address
                .to_string(),
            "/ip4/192.0.2.8/tcp/42100"
        );
        assert_eq!(
            parse_manual_peer("192.0.2.8:5000", None)
                .unwrap()
                .address
                .to_string(),
            "/ip4/192.0.2.8/tcp/5000"
        );
        assert_eq!(
            parse_manual_peer("2001:db8::8", None)
                .unwrap()
                .address
                .to_string(),
            "/ip6/2001:db8::8/tcp/42100"
        );
        assert_eq!(
            parse_manual_peer("[2001:db8::8]:5000", None)
                .unwrap()
                .address
                .to_string(),
            "/ip6/2001:db8::8/tcp/5000"
        );
        assert_eq!(
            parse_manual_peer("friend.example.net:5000", None)
                .unwrap()
                .address
                .to_string(),
            "/dns/friend.example.net/tcp/5000"
        );
    }

    #[test]
    fn rejects_ambiguous_or_unsafe_forms() {
        assert!(parse_manual_peer("bad host:42100", None).is_err());
        assert!(parse_manual_peer("example.test:0", None).is_err());
        assert!(parse_manual_peer("[2001:db8::1", None).is_err());
    }

    #[test]
    fn normalizes_fingerprint() {
        let parsed = parse_manual_peer("127.0.0.1", Some("abc-def-234-567-xyz")).unwrap();
        assert_eq!(
            parsed.expected_fingerprint.as_deref(),
            Some("ABCDEF234567XYZ")
        );
        assert!(parse_manual_peer("127.0.0.1", Some("short")).is_err());
    }
}
