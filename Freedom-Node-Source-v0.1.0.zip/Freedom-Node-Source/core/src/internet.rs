use std::{
    fs,
    io::{Read, Write},
    net::{TcpStream, ToSocketAddrs},
    path::{Path, PathBuf},
    str::FromStr,
    sync::Arc,
    time::Duration,
};

use anyhow::{Context, Result, bail};
use libp2p::{Multiaddr, PeerId, multiaddr::Protocol};
use rustls::{ClientConfig, ClientConnection, RootCertStore, StreamOwned, pki_types::ServerName};
use serde::{Deserialize, Serialize};
use url::Url;

pub const INTERNET_CONFIG_VERSION: u32 = 1;
pub const MAX_BOOTSTRAP_PEERS: usize = 16;
pub const MAX_RELAY_PEERS: usize = 8;
pub const MAX_BOOTSTRAP_MANIFESTS: usize = 4;
pub const MAX_BOOTSTRAP_MANIFEST_BYTES: usize = 64 * 1024;
pub const DEFAULT_BOOTSTRAP_MANIFEST_URL: &str = "https://fenixstudio.org/bootstrap/peers.json";
const MAX_ENDPOINT_BYTES: usize = 512;
const MAX_MANIFEST_URL_BYTES: usize = 2048;

#[derive(Clone, Debug)]
pub struct InternetEndpoint {
    pub peer_id: PeerId,
    pub address: Multiaddr,
}

impl InternetEndpoint {
    pub fn parse(value: &str) -> Result<Self> {
        let value = value.trim();
        if value.is_empty()
            || value.len() > MAX_ENDPOINT_BYTES
            || value.chars().any(char::is_control)
        {
            bail!("Internet endpoint is empty or too long");
        }
        let address = Multiaddr::from_str(value).context("invalid Internet peer multiaddress")?;
        let peer_id = terminal_peer(&address)
            .ok_or_else(|| anyhow::anyhow!("Internet endpoint must end in /p2p/<PeerID>"))?;
        if !valid_direct_endpoint(&address, &peer_id) {
            bail!("Internet endpoint must use TCP or QUIC and end in the server's /p2p/<PeerID>");
        }
        Ok(Self { peer_id, address })
    }

    pub fn transport_address(&self) -> Multiaddr {
        let mut address = self.address.clone();
        address.pop();
        address
    }
}

#[derive(Clone, Debug)]
pub struct InternetConfig {
    pub bootstrap_peers: Vec<InternetEndpoint>,
    pub relay_peers: Vec<InternetEndpoint>,
    pub bootstrap_manifests: Vec<String>,
    pub enable_upnp: bool,
    pub infrastructure: bool,
}

impl Default for InternetConfig {
    fn default() -> Self {
        Self {
            bootstrap_peers: Vec::new(),
            relay_peers: Vec::new(),
            bootstrap_manifests: Vec::new(),
            enable_upnp: true,
            infrastructure: false,
        }
    }
}

impl InternetConfig {
    pub fn load(path: &Path) -> Result<Self> {
        if !path.is_file() {
            return Ok(Self::default());
        }
        let bytes = fs::read(path).with_context(|| format!("could not read {}", path.display()))?;
        let file: InternetConfigFile = serde_json::from_slice(&bytes)
            .with_context(|| format!("invalid Internet configuration in {}", path.display()))?;
        file.into_runtime()
    }

    pub fn add_bootstrap(&mut self, value: &str) -> Result<()> {
        if self.bootstrap_peers.len() >= MAX_BOOTSTRAP_PEERS {
            bail!("at most {MAX_BOOTSTRAP_PEERS} bootstrap peers may be configured");
        }
        push_unique(&mut self.bootstrap_peers, InternetEndpoint::parse(value)?);
        Ok(())
    }

    pub fn add_relay(&mut self, value: &str) -> Result<()> {
        if self.relay_peers.len() >= MAX_RELAY_PEERS {
            bail!("at most {MAX_RELAY_PEERS} relay peers may be configured");
        }
        push_unique(&mut self.relay_peers, InternetEndpoint::parse(value)?);
        Ok(())
    }

    pub fn add_bootstrap_manifest(&mut self, value: &str) -> Result<()> {
        if self.bootstrap_manifests.len() >= MAX_BOOTSTRAP_MANIFESTS {
            bail!("at most {MAX_BOOTSTRAP_MANIFESTS} bootstrap manifests may be configured");
        }
        let value = validate_manifest_url(value)?;
        if !self.bootstrap_manifests.contains(&value) {
            self.bootstrap_manifests.push(value);
        }
        Ok(())
    }

    pub fn parse_bootstrap_manifest(bytes: &[u8]) -> Result<Self> {
        if bytes.is_empty() || bytes.len() > MAX_BOOTSTRAP_MANIFEST_BYTES {
            bail!("bootstrap manifest is empty or exceeds {MAX_BOOTSTRAP_MANIFEST_BYTES} bytes");
        }
        let file: InternetConfigFile =
            serde_json::from_slice(bytes).context("invalid bootstrap manifest JSON")?;
        if file.infrastructure {
            bail!("a bootstrap manifest cannot enable infrastructure mode");
        }
        if !file.bootstrap_manifests.is_empty() {
            bail!("a bootstrap manifest cannot redirect clients to other manifest URLs");
        }
        file.into_runtime()
    }

    pub fn load_cached_bootstrap_manifest(path: &Path) -> Result<Self> {
        let bytes = fs::read(path)
            .with_context(|| format!("could not read bootstrap cache {}", path.display()))?;
        Self::parse_bootstrap_manifest(&bytes)
    }

    pub fn merge_discovery(&mut self, discovered: &Self) {
        for endpoint in &discovered.bootstrap_peers {
            push_unique(&mut self.bootstrap_peers, endpoint.clone());
        }
        for endpoint in &discovered.relay_peers {
            push_unique(&mut self.relay_peers, endpoint.clone());
        }
    }

    pub fn contains_any_peer<'a>(&self, peers: impl IntoIterator<Item = &'a PeerId>) -> bool {
        let configured = self
            .bootstrap_peers
            .iter()
            .chain(&self.relay_peers)
            .map(|endpoint| endpoint.peer_id)
            .collect::<std::collections::HashSet<_>>();
        peers.into_iter().any(|peer| configured.contains(peer))
    }

    pub fn unique_peer_count(&self) -> usize {
        self.bootstrap_peers
            .iter()
            .chain(&self.relay_peers)
            .map(|endpoint| endpoint.peer_id)
            .collect::<std::collections::HashSet<_>>()
            .len()
    }

    pub fn mode_label(&self) -> &'static str {
        if self.infrastructure {
            "Infrastructure server"
        } else if !self.relay_peers.is_empty() {
            "Internet via relay"
        } else if !self.bootstrap_peers.is_empty() {
            "Internet direct"
        } else {
            "Direct/LAN"
        }
    }
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(deny_unknown_fields)]
struct InternetConfigFile {
    version: u32,
    #[serde(default = "default_true")]
    enable_upnp: bool,
    #[serde(default)]
    infrastructure: bool,
    #[serde(default)]
    bootstrap_peers: Vec<String>,
    #[serde(default)]
    relay_peers: Vec<String>,
    #[serde(default)]
    bootstrap_manifests: Vec<String>,
}

impl InternetConfigFile {
    fn into_runtime(self) -> Result<InternetConfig> {
        if self.version != INTERNET_CONFIG_VERSION {
            bail!(
                "unsupported Internet configuration version {}; expected {INTERNET_CONFIG_VERSION}",
                self.version
            );
        }
        if self.bootstrap_peers.len() > MAX_BOOTSTRAP_PEERS {
            bail!("at most {MAX_BOOTSTRAP_PEERS} bootstrap peers may be configured");
        }
        if self.relay_peers.len() > MAX_RELAY_PEERS {
            bail!("at most {MAX_RELAY_PEERS} relay peers may be configured");
        }
        if self.bootstrap_manifests.len() > MAX_BOOTSTRAP_MANIFESTS {
            bail!("at most {MAX_BOOTSTRAP_MANIFESTS} bootstrap manifests may be configured");
        }
        let mut runtime = InternetConfig {
            enable_upnp: self.enable_upnp,
            infrastructure: self.infrastructure,
            ..Default::default()
        };
        for endpoint in self.bootstrap_peers {
            runtime.add_bootstrap(&endpoint)?;
        }
        for endpoint in self.relay_peers {
            runtime.add_relay(&endpoint)?;
        }
        for manifest in self.bootstrap_manifests {
            runtime.add_bootstrap_manifest(&manifest)?;
        }
        Ok(runtime)
    }
}

fn default_true() -> bool {
    true
}

fn push_unique(endpoints: &mut Vec<InternetEndpoint>, endpoint: InternetEndpoint) {
    if endpoints
        .iter()
        .all(|existing| existing.address != endpoint.address)
    {
        endpoints.push(endpoint);
    }
}

fn validate_manifest_url(value: &str) -> Result<String> {
    let value = value.trim();
    if value.is_empty()
        || value.len() > MAX_MANIFEST_URL_BYTES
        || value.chars().any(char::is_control)
    {
        bail!("bootstrap manifest URL is empty or too long");
    }
    let parsed = Url::parse(value).context("invalid bootstrap manifest URL")?;
    if parsed.scheme() != "https"
        || parsed.host_str().is_none()
        || !parsed.username().is_empty()
        || parsed.password().is_some()
        || parsed.query().is_some()
        || parsed.fragment().is_some()
    {
        bail!(
            "bootstrap manifest URL must be a plain HTTPS URL without credentials, query or fragment"
        );
    }
    Ok(parsed.to_string())
}

pub fn store_bootstrap_manifest_cache(path: &Path, bytes: &[u8]) -> Result<()> {
    InternetConfig::parse_bootstrap_manifest(bytes)?;
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let temporary = temporary_path(path, "tmp");
    let backup = temporary_path(path, "bak");
    fs::write(&temporary, bytes)
        .with_context(|| format!("could not write bootstrap cache {}", temporary.display()))?;
    if !path.exists() {
        return fs::rename(&temporary, path)
            .with_context(|| format!("could not install bootstrap cache {}", path.display()));
    }
    let _ = fs::remove_file(&backup);
    fs::rename(path, &backup)
        .with_context(|| format!("could not back up bootstrap cache {}", path.display()))?;
    match fs::rename(&temporary, path) {
        Ok(()) => {
            let _ = fs::remove_file(backup);
            Ok(())
        }
        Err(error) => {
            let _ = fs::rename(backup, path);
            Err(error).context("could not replace bootstrap manifest cache")
        }
    }
}

fn temporary_path(path: &Path, suffix: &str) -> PathBuf {
    let file_name = path
        .file_name()
        .and_then(|name| name.to_str())
        .unwrap_or("bootstrap-peers.json");
    path.with_file_name(format!(".{file_name}-{}.{suffix}", uuid::Uuid::new_v4()))
}

pub fn fetch_bootstrap_manifest(url: &str) -> Result<(InternetConfig, Vec<u8>)> {
    let normalized = validate_manifest_url(url)?;
    let parsed = Url::parse(&normalized).context("invalid bootstrap manifest URL")?;
    let host = parsed
        .host_str()
        .ok_or_else(|| anyhow::anyhow!("bootstrap manifest URL has no host"))?;
    let port = parsed.port_or_known_default().unwrap_or(443);
    let addresses = (host, port)
        .to_socket_addrs()
        .with_context(|| format!("could not resolve bootstrap host {host}"))?;
    let mut last_connect_error = None;
    let mut tcp = None;
    for address in addresses {
        match TcpStream::connect_timeout(&address, Duration::from_secs(5)) {
            Ok(stream) => {
                tcp = Some(stream);
                break;
            }
            Err(error) => last_connect_error = Some(error),
        }
    }
    let tcp = tcp.ok_or_else(|| {
        anyhow::anyhow!(
            "could not connect to bootstrap host {host}: {}",
            last_connect_error
                .map(|error| error.to_string())
                .unwrap_or_else(|| "host resolved to no addresses".to_owned())
        )
    })?;
    tcp.set_read_timeout(Some(Duration::from_secs(8)))?;
    tcp.set_write_timeout(Some(Duration::from_secs(8)))?;

    let mut roots = RootCertStore::empty();
    roots.extend(webpki_roots::TLS_SERVER_ROOTS.iter().cloned());
    let tls_config = ClientConfig::builder()
        .with_root_certificates(roots)
        .with_no_client_auth();
    let server_name = ServerName::try_from(host.to_owned())
        .map_err(|_| anyhow::anyhow!("invalid bootstrap TLS server name"))?;
    let connection = ClientConnection::new(Arc::new(tls_config), server_name)
        .context("could not initialise bootstrap TLS connection")?;
    let mut stream = StreamOwned::new(connection, tcp);
    let request_target = if parsed.path().is_empty() {
        "/"
    } else {
        parsed.path()
    };
    let host_header = if port == 443 {
        host.to_owned()
    } else {
        format!("{host}:{port}")
    };
    write!(
        stream,
        "GET {request_target} HTTP/1.1\r\nHost: {host_header}\r\nAccept: application/json\r\nAccept-Encoding: identity\r\nConnection: close\r\nUser-Agent: Freedom-Network/0.1\r\n\r\n"
    )
    .context("could not send bootstrap HTTPS request")?;
    stream
        .flush()
        .context("could not flush bootstrap HTTPS request")?;
    let body = read_http_manifest_response(&mut stream)?;
    let config = InternetConfig::parse_bootstrap_manifest(&body)?;
    Ok((config, body))
}

fn read_http_manifest_response(reader: &mut impl Read) -> Result<Vec<u8>> {
    const MAX_HTTP_HEADER_BYTES: usize = 16 * 1024;
    const MAX_HTTP_WIRE_BYTES: usize = MAX_BOOTSTRAP_MANIFEST_BYTES + 64 * 1024;
    let mut wire = Vec::new();
    let mut buffer = [0u8; 4096];
    loop {
        if let Some(header_end) = find_bytes(&wire, b"\r\n\r\n") {
            if header_end > MAX_HTTP_HEADER_BYTES {
                bail!("bootstrap HTTPS response headers are too large");
            }
            let body_start = header_end + 4;
            let headers = std::str::from_utf8(&wire[..header_end])
                .context("bootstrap HTTPS response headers are not valid text")?;
            let mut lines = headers.split("\r\n");
            let status = lines
                .next()
                .and_then(|line| line.split_whitespace().nth(1))
                .and_then(|value| value.parse::<u16>().ok())
                .ok_or_else(|| anyhow::anyhow!("invalid bootstrap HTTPS status line"))?;
            if status != 200 {
                bail!("bootstrap manifest returned HTTP {status}");
            }
            let mut content_length = None;
            let mut chunked = false;
            for line in lines {
                let Some((name, value)) = line.split_once(':') else {
                    continue;
                };
                if name.eq_ignore_ascii_case("content-length") {
                    content_length = Some(
                        value
                            .trim()
                            .parse::<usize>()
                            .context("invalid bootstrap HTTPS content length")?,
                    );
                } else if name.eq_ignore_ascii_case("transfer-encoding")
                    && value
                        .split(',')
                        .any(|encoding| encoding.trim().eq_ignore_ascii_case("chunked"))
                {
                    chunked = true;
                }
            }
            if chunked {
                if let Some(body) = decode_chunked_manifest(&wire[body_start..])? {
                    return Ok(body);
                }
            } else if let Some(length) = content_length {
                if length > MAX_BOOTSTRAP_MANIFEST_BYTES {
                    bail!("bootstrap manifest exceeds {MAX_BOOTSTRAP_MANIFEST_BYTES} bytes");
                }
                if wire.len() >= body_start + length {
                    return Ok(wire[body_start..body_start + length].to_vec());
                }
            } else {
                bail!("bootstrap HTTPS response has no bounded body framing");
            }
        } else if wire.len() > MAX_HTTP_HEADER_BYTES {
            bail!("bootstrap HTTPS response headers are too large");
        }

        let read = reader
            .read(&mut buffer)
            .context("could not read bootstrap HTTPS response")?;
        if read == 0 {
            bail!("bootstrap HTTPS response ended before its body was complete");
        }
        if wire.len() + read > MAX_HTTP_WIRE_BYTES {
            bail!("bootstrap HTTPS response is too large");
        }
        wire.extend_from_slice(&buffer[..read]);
    }
}

fn decode_chunked_manifest(encoded: &[u8]) -> Result<Option<Vec<u8>>> {
    let mut cursor = 0usize;
    let mut body = Vec::new();
    loop {
        let Some(line_length) = find_bytes(&encoded[cursor..], b"\r\n") else {
            return Ok(None);
        };
        let line_end = cursor + line_length;
        let size_text = std::str::from_utf8(&encoded[cursor..line_end])
            .context("invalid bootstrap HTTPS chunk header")?;
        let size =
            usize::from_str_radix(size_text.split(';').next().unwrap_or_default().trim(), 16)
                .context("invalid bootstrap HTTPS chunk size")?;
        cursor = line_end + 2;
        if size == 0 {
            if encoded.len() < cursor + 2 {
                return Ok(None);
            }
            if encoded[cursor..].starts_with(b"\r\n")
                || find_bytes(&encoded[cursor..], b"\r\n\r\n").is_some()
            {
                return Ok(Some(body));
            }
            return Ok(None);
        }
        if size > MAX_BOOTSTRAP_MANIFEST_BYTES - body.len() {
            bail!("bootstrap manifest exceeds {MAX_BOOTSTRAP_MANIFEST_BYTES} bytes");
        }
        if encoded.len() < cursor + size + 2 {
            return Ok(None);
        }
        body.extend_from_slice(&encoded[cursor..cursor + size]);
        cursor += size;
        if &encoded[cursor..cursor + 2] != b"\r\n" {
            bail!("invalid bootstrap HTTPS chunk terminator");
        }
        cursor += 2;
    }
}

fn find_bytes(haystack: &[u8], needle: &[u8]) -> Option<usize> {
    haystack
        .windows(needle.len())
        .position(|candidate| candidate == needle)
}

fn terminal_peer(address: &Multiaddr) -> Option<PeerId> {
    match address.iter().last()? {
        Protocol::P2p(peer) => Some(peer),
        _ => None,
    }
}

fn valid_direct_endpoint(address: &Multiaddr, expected_peer: &PeerId) -> bool {
    let protocols = address.iter().collect::<Vec<_>>();
    let host = protocols.first().is_some_and(is_host_protocol);
    host && (matches!(protocols.as_slice(), [_, Protocol::Tcp(_), Protocol::P2p(peer)] if peer == expected_peer)
        || matches!(protocols.as_slice(), [_, Protocol::Udp(_), Protocol::QuicV1, Protocol::P2p(peer)] if peer == expected_peer))
}

fn is_host_protocol(protocol: &Protocol<'_>) -> bool {
    matches!(
        protocol,
        Protocol::Ip4(_)
            | Protocol::Ip6(_)
            | Protocol::Dns(_)
            | Protocol::Dns4(_)
            | Protocol::Dns6(_)
    )
}

#[cfg(test)]
mod tests {
    use super::*;

    fn peer() -> PeerId {
        libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id()
    }

    #[test]
    fn accepts_tcp_and_quic_endpoints() {
        let peer = peer();
        assert!(
            InternetEndpoint::parse(&format!("/dns4/bootstrap.freedom.net/tcp/42100/p2p/{peer}"))
                .is_ok()
        );
        assert!(
            InternetEndpoint::parse(&format!(
                "/dns4/bootstrap.freedom.net/udp/42100/quic-v1/p2p/{peer}"
            ))
            .is_ok()
        );
        assert!(
            InternetEndpoint::parse(&format!("/ip4/159.196.22.133/tcp/42100/p2p/{peer}")).is_ok()
        );
    }

    #[test]
    fn rejects_missing_peer_and_relay_paths() {
        let peer = peer();
        assert!(InternetEndpoint::parse("/ip4/203.0.113.1/tcp/42100").is_err());
        assert!(
            InternetEndpoint::parse(&format!(
                "/ip4/203.0.113.1/tcp/42100/p2p/{peer}/p2p-circuit/p2p/{peer}"
            ))
            .is_err()
        );
    }

    #[test]
    fn missing_file_keeps_safe_direct_defaults() {
        let temp = tempfile::tempdir().unwrap();
        let config = InternetConfig::load(&temp.path().join("missing.json")).unwrap();
        assert!(config.enable_upnp);
        assert!(!config.infrastructure);
        assert!(config.bootstrap_peers.is_empty());
        assert!(config.relay_peers.is_empty());
        assert!(config.bootstrap_manifests.is_empty());
    }

    #[test]
    fn parses_bounded_bootstrap_manifest_and_rejects_remote_policy_changes() {
        let peer = peer();
        let valid = format!(
            r#"{{
                "version": 1,
                "enable_upnp": true,
                "infrastructure": false,
                "bootstrap_peers": ["/ip4/159.196.22.133/tcp/42100/p2p/{peer}"],
                "relay_peers": []
            }}"#
        );
        let parsed = InternetConfig::parse_bootstrap_manifest(valid.as_bytes()).unwrap();
        assert_eq!(parsed.bootstrap_peers.len(), 1);
        assert!(parsed.contains_any_peer([&peer]));

        let infrastructure = valid.replace("\"infrastructure\": false", "\"infrastructure\": true");
        assert!(InternetConfig::parse_bootstrap_manifest(infrastructure.as_bytes()).is_err());

        let recursive = valid.replace(
            "\"relay_peers\": []",
            &format!(
                "\"relay_peers\": [], \"bootstrap_manifests\": [\"{DEFAULT_BOOTSTRAP_MANIFEST_URL}\"]"
            ),
        );
        assert!(InternetConfig::parse_bootstrap_manifest(recursive.as_bytes()).is_err());
    }

    #[test]
    fn validates_manifest_urls_and_cache_replacement() {
        let mut config = InternetConfig::default();
        config
            .add_bootstrap_manifest(DEFAULT_BOOTSTRAP_MANIFEST_URL)
            .unwrap();
        assert_eq!(config.bootstrap_manifests, [DEFAULT_BOOTSTRAP_MANIFEST_URL]);
        assert!(
            config
                .add_bootstrap_manifest("http://fenixstudio.org/bootstrap/peers.json")
                .is_err()
        );
        assert!(
            config
                .add_bootstrap_manifest("https://user@example.com/peers.json")
                .is_err()
        );

        let peer = peer();
        let bytes = format!(
            r#"{{"version":1,"infrastructure":false,"bootstrap_peers":["/ip4/159.196.22.133/tcp/42100/p2p/{peer}"],"relay_peers":[]}}"#
        );
        let temp = tempfile::tempdir().unwrap();
        let path = temp.path().join("bootstrap-peers.json");
        store_bootstrap_manifest_cache(&path, bytes.as_bytes()).unwrap();
        let loaded = InternetConfig::load_cached_bootstrap_manifest(&path).unwrap();
        assert!(loaded.contains_any_peer([&peer]));
    }

    #[test]
    fn reads_content_length_and_chunked_http_responses() {
        let fixed = b"HTTP/1.1 200 OK\r\nContent-Length: 7\r\n\r\nfreedom";
        assert_eq!(
            read_http_manifest_response(&mut std::io::Cursor::new(fixed)).unwrap(),
            b"freedom"
        );

        let chunked = b"HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n3\r\nfre\r\n4\r\nedom\r\n0\r\n\r\n";
        assert_eq!(
            read_http_manifest_response(&mut std::io::Cursor::new(chunked)).unwrap(),
            b"freedom"
        );
    }

    #[test]
    fn rejects_redirects_and_oversized_http_responses() {
        let redirect = b"HTTP/1.1 302 Found\r\nContent-Length: 0\r\n\r\n";
        assert!(read_http_manifest_response(&mut std::io::Cursor::new(redirect)).is_err());

        let oversized = format!(
            "HTTP/1.1 200 OK\r\nContent-Length: {}\r\n\r\n",
            MAX_BOOTSTRAP_MANIFEST_BYTES + 1
        );
        assert!(read_http_manifest_response(&mut std::io::Cursor::new(oversized)).is_err());
    }

    #[test]
    #[ignore = "requires live HTTPS access"]
    fn live_bootstrap_manifest_is_available() {
        let (config, _) = fetch_bootstrap_manifest(DEFAULT_BOOTSTRAP_MANIFEST_URL).unwrap();
        assert!(!config.bootstrap_peers.is_empty());
        assert!(!config.relay_peers.is_empty());
    }
}
