use std::{
    fs::OpenOptions,
    io,
    path::{Path, PathBuf},
    process::Stdio,
    time::Duration,
};

use sha2::{Digest, Sha256};
use thiserror::Error;
use tokio::{
    io::{AsyncRead, AsyncReadExt, AsyncWriteExt},
    process::Command,
};
use uuid::Uuid;

use crate::{
    protocol::{MAX_SITE_REQUEST_BYTES, MAX_SITE_RESPONSE_BYTES, SiteHeader},
    sites::{HostedFile, ResolvedSiteFile},
};

const PHP_TIMEOUT: Duration = Duration::from_secs(75);
const CGI_HEADER_ALLOWANCE: usize = 32 * 1024;
const STDERR_LIMIT: usize = 16 * 1024;
#[cfg(windows)]
const CREATE_NO_WINDOW: u32 = 0x0800_0000;

struct TemporaryPhpIni {
    path: PathBuf,
}

impl TemporaryPhpIni {
    fn create(
        runtime_dir: &Path,
        site_root: &Path,
        session_dir: &Path,
        temporary_dir: &Path,
        mail: Option<&PhpMailConfig>,
    ) -> io::Result<Self> {
        let config_dir = std::env::temp_dir().join("Freedom").join("php-config");
        std::fs::create_dir_all(&config_dir)?;
        let path = config_dir.join(format!("{}.ini", Uuid::new_v4()));
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&path)?;
        let config = php_configuration(runtime_dir, site_root, session_dir, temporary_dir, mail);
        std::io::Write::write_all(&mut file, config.as_bytes())?;
        file.sync_all()?;
        Ok(Self { path })
    }
}

impl Drop for TemporaryPhpIni {
    fn drop(&mut self) {
        let _ = std::fs::remove_file(&self.path);
    }
}

#[derive(Debug, Error)]
pub(crate) enum PhpError {
    #[error("the built-in PHP runtime is unavailable")]
    Unavailable,
    #[error("unsupported PHP request")]
    UnsupportedRequest,
    #[error("PHP request body exceeds the {MAX_SITE_REQUEST_BYTES} byte limit")]
    RequestTooLarge,
    #[error("PHP output exceeds the {MAX_SITE_RESPONSE_BYTES} byte limit")]
    OutputTooLarge,
    #[error("PHP execution timed out")]
    Timeout,
    #[error("PHP execution failed")]
    ExecutionFailed,
    #[error("PHP returned an invalid CGI response")]
    InvalidResponse,
    #[error("PHP runtime I/O failed: {0}")]
    Io(#[from] io::Error),
}

pub(crate) struct PhpRequest<'a> {
    pub peer_id: &'a str,
    pub method: &'a str,
    pub query: &'a str,
    pub content_type: &'a str,
    pub headers: &'a [SiteHeader],
    pub body: &'a [u8],
}

pub(crate) struct PhpRuntime {
    executable: Option<PathBuf>,
    mail: Option<PhpMailConfig>,
    #[cfg(feature = "authority")]
    authority_peer: Option<String>,
}

struct PhpMailConfig {
    port: u16,
    sender: String,
}

impl PhpRuntime {
    pub(crate) fn new(executable: Option<PathBuf>, mail: Option<(u16, String)>) -> Self {
        let executable = executable
            .filter(|path| path.is_file())
            .and_then(|path| std::fs::canonicalize(path).ok());
        let mail = mail
            .filter(|(port, sender)| {
                *port > 0
                    && !sender.is_empty()
                    && sender.len() <= 254
                    && !sender.chars().any(char::is_control)
            })
            .map(|(port, sender)| PhpMailConfig { port, sender });
        Self {
            executable,
            mail,
            #[cfg(feature = "authority")]
            authority_peer: None,
        }
    }

    #[cfg(feature = "authority")]
    pub(crate) fn with_authority_peer(mut self, peer_id: Option<String>) -> Self {
        self.authority_peer = peer_id.filter(|peer| {
            !peer.is_empty() && peer.len() <= 128 && !peer.chars().any(char::is_control)
        });
        self
    }

    pub(crate) fn available(&self) -> bool {
        self.executable.is_some()
    }

    pub(crate) async fn execute(
        &self,
        file: &ResolvedSiteFile,
        request: PhpRequest<'_>,
    ) -> Result<HostedFile, PhpError> {
        let executable = self.executable.as_ref().ok_or(PhpError::Unavailable)?;
        if !matches!(request.method, "GET" | "HEAD" | "POST")
            || request.query.len() > 4096
            || request.content_type.len() > 256
        {
            return Err(PhpError::UnsupportedRequest);
        }
        if request.body.len() > MAX_SITE_REQUEST_BYTES {
            return Err(PhpError::RequestTooLarge);
        }

        let runtime_dir = child_process_path(executable.parent().ok_or(PhpError::Unavailable)?);
        let site_root = child_process_path(&file.root);
        let script_path = child_process_path(&file.path);
        let private_runtime = site_root.join(".freedom-runtime");
        let session_dir = private_runtime.join("sessions");
        let temporary_dir = private_runtime.join("tmp");
        std::fs::create_dir_all(&session_dir)?;
        std::fs::create_dir_all(&temporary_dir)?;
        let php_ini = TemporaryPhpIni::create(
            &runtime_dir,
            &site_root,
            &session_dir,
            &temporary_dir,
            self.mail.as_ref(),
        )?;
        let mut command = Command::new(executable);
        #[cfg(windows)]
        command.creation_flags(CREATE_NO_WINDOW);
        command
            .current_dir(&site_root)
            .env_clear()
            .env("PATH", &runtime_dir)
            .env("PHPRC", &php_ini.path)
            .env("PHP_INI_SCAN_DIR", "")
            .env("REDIRECT_STATUS", "1")
            .env("GATEWAY_INTERFACE", "CGI/1.1")
            .env("SERVER_PROTOCOL", "HTTP/1.1")
            .env("SERVER_NAME", "freedom")
            .env("SERVER_PORT", "0")
            .env("REMOTE_ADDR", "127.0.0.1")
            .env("FREEDOM_PEER_ID", request.peer_id)
            .env("REQUEST_METHOD", request.method)
            .env("QUERY_STRING", request.query)
            .env(
                "REQUEST_URI",
                format!(
                    "/{}{}{}",
                    file.relative_path,
                    if request.query.is_empty() { "" } else { "?" },
                    request.query
                ),
            )
            .env("SCRIPT_NAME", format!("/{}", file.relative_path))
            .env("SCRIPT_FILENAME", &script_path)
            .env("DOCUMENT_ROOT", &site_root)
            .env("CONTENT_LENGTH", request.body.len().to_string())
            .env("CONTENT_TYPE", request.content_type)
            .stdin(Stdio::piped())
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .kill_on_drop(true);
        #[cfg(feature = "authority")]
        if let Some(authority_peer) = &self.authority_peer {
            command.env("FREEDOM_AUTHORITY_PEER", authority_peer);
        }
        for header in request.headers {
            if let Some(environment_name) = cgi_environment_name(&header.name) {
                command.env(environment_name, &header.value);
            }
        }
        copy_windows_runtime_environment(&mut command);

        let mut child = command.spawn()?;
        let stdout = child.stdout.take().ok_or(PhpError::ExecutionFailed)?;
        let stderr = child.stderr.take().ok_or(PhpError::ExecutionFailed)?;
        let stdout_task = tokio::spawn(drain_bounded(
            stdout,
            MAX_SITE_RESPONSE_BYTES + CGI_HEADER_ALLOWANCE,
        ));
        let stderr_task = tokio::spawn(drain_bounded(stderr, STDERR_LIMIT));

        if let Some(mut stdin) = child.stdin.take() {
            stdin.write_all(request.body).await?;
            stdin.shutdown().await?;
        }

        let status = match tokio::time::timeout(PHP_TIMEOUT, child.wait()).await {
            Ok(status) => status?,
            Err(_) => {
                let _ = child.kill().await;
                let _ = child.wait().await;
                stdout_task.abort();
                stderr_task.abort();
                return Err(PhpError::Timeout);
            }
        };
        let (output, output_truncated) =
            stdout_task.await.map_err(|_| PhpError::ExecutionFailed)??;
        let (_stderr, _) = stderr_task.await.map_err(|_| PhpError::ExecutionFailed)??;
        if output_truncated {
            return Err(PhpError::OutputTooLarge);
        }
        if !status.success() {
            return Err(PhpError::ExecutionFailed);
        }
        parse_cgi_response(&output)
    }
}

fn child_process_path(path: &Path) -> PathBuf {
    let value = path.to_string_lossy();
    if let Some(unc) = value.strip_prefix(r"\\?\UNC\") {
        PathBuf::from(format!(r"\\{unc}"))
    } else if let Some(local) = value.strip_prefix(r"\\?\") {
        PathBuf::from(local)
    } else {
        path.to_owned()
    }
}

fn php_configuration(
    runtime_dir: &Path,
    site_root: &Path,
    session_dir: &Path,
    temporary_dir: &Path,
    mail: Option<&PhpMailConfig>,
) -> String {
    let extension_dir = runtime_dir.join("ext");
    let mut extensions = String::new();
    if extension_dir.is_dir() {
        extensions.push_str(&format!(
            "extension_dir={}\n",
            ini_quoted_path(&extension_dir)
        ));
        for extension in [
            "php_exif.dll",
            "php_fileinfo.dll",
            "php_gd.dll",
            "php_intl.dll",
            "php_mbstring.dll",
            "php_pdo_sqlite.dll",
            "php_sqlite3.dll",
            "php_zip.dll",
        ] {
            if extension_dir.join(extension).is_file() {
                extensions.push_str(&format!("extension={extension}\n"));
            }
        }
    }

    let (mail_settings, mail_function) = if let Some(mail) = mail {
        (
            format!(
                "SMTP=127.0.0.1\nsmtp_port={}\nsendmail_from={}\n",
                mail.port, mail.sender
            ),
            "",
        )
    } else {
        (String::new(), "mail,")
    };

    format!(
        concat!(
            "[PHP]\n",
            "open_basedir={}\n",
            "allow_url_fopen=Off\n",
            "allow_url_include=Off\n",
            "enable_dl=Off\n",
            "expose_php=Off\n",
            "display_errors=Off\n",
            "display_startup_errors=Off\n",
            "log_errors=Off\n",
            "max_execution_time=60\n",
            "max_input_time=60\n",
            "max_input_vars=5000\n",
            "memory_limit=256M\n",
            "file_uploads=On\n",
            "max_file_uploads=50\n",
            "post_max_size=128M\n",
            "upload_max_filesize=128M\n",
            "upload_tmp_dir={}\n",
            "sys_temp_dir={}\n",
            "session.save_path={}\n",
            "session.use_strict_mode=1\n",
            "session.cookie_httponly=1\n",
            "session.cookie_samesite=Lax\n",
            "cgi.force_redirect=0\n",
            "cgi.fix_pathinfo=0\n",
            "user_ini.filename=\n",
            "date.timezone=UTC\n",
            "{}",
            "disable_functions=exec,passthru,shell_exec,system,proc_open,popen,pcntl_exec,dl,putenv,{}fsockopen,pfsockopen,stream_socket_client,stream_socket_server,gethostbyname,gethostbynamel,gethostbyaddr,dns_check_record,dns_get_record\n",
            "{}"
        ),
        ini_quoted_path(site_root),
        ini_quoted_path(temporary_dir),
        ini_quoted_path(temporary_dir),
        ini_quoted_path(session_dir),
        mail_settings,
        mail_function,
        extensions,
    )
}

fn ini_quoted_path(path: &Path) -> String {
    format!("\"{}\"", path.to_string_lossy().replace('\\', "/"))
}

fn copy_windows_runtime_environment(command: &mut Command) {
    for variable in ["SystemRoot", "WINDIR", "TEMP", "TMP"] {
        if let Some(value) = std::env::var_os(variable) {
            command.env(variable, value);
        }
    }
}

async fn drain_bounded(
    mut reader: impl AsyncRead + Unpin,
    limit: usize,
) -> io::Result<(Vec<u8>, bool)> {
    let mut stored = Vec::new();
    let mut truncated = false;
    let mut buffer = [0_u8; 16 * 1024];
    loop {
        let read = reader.read(&mut buffer).await?;
        if read == 0 {
            break;
        }
        let remaining = limit.saturating_sub(stored.len());
        stored.extend_from_slice(&buffer[..read.min(remaining)]);
        truncated |= read > remaining;
    }
    Ok((stored, truncated))
}

fn parse_cgi_response(output: &[u8]) -> Result<HostedFile, PhpError> {
    let (header_end, separator_len) = find_header_end(output).ok_or(PhpError::InvalidResponse)?;
    if header_end > CGI_HEADER_ALLOWANCE {
        return Err(PhpError::InvalidResponse);
    }
    let headers =
        std::str::from_utf8(&output[..header_end]).map_err(|_| PhpError::InvalidResponse)?;
    let mut status_code = 200_u16;
    let mut mime_type = "text/html; charset=UTF-8".to_owned();
    let mut response_headers = Vec::new();
    for line in headers.lines() {
        let Some((name, value)) = line.split_once(':') else {
            continue;
        };
        let value = value.trim();
        if name.eq_ignore_ascii_case("status") {
            status_code = value
                .split_whitespace()
                .next()
                .and_then(|value| value.parse().ok())
                .filter(|status| (100..=599).contains(status))
                .ok_or(PhpError::InvalidResponse)?;
        } else if name.eq_ignore_ascii_case("content-type")
            && !value.is_empty()
            && value.len() <= 256
            && !value.chars().any(char::is_control)
        {
            mime_type = value.to_owned();
        } else {
            let name = name.trim().to_ascii_lowercase();
            if response_header_allowed(&name)
                && !value.is_empty()
                && value.len() <= 16 * 1024
                && !value.bytes().any(|byte| matches!(byte, b'\r' | b'\n' | 0))
                && response_headers.len() < 32
            {
                response_headers.push(SiteHeader {
                    name,
                    value: value.to_owned(),
                });
            }
        }
    }
    let body = output[header_end + separator_len..].to_vec();
    if body.len() > MAX_SITE_RESPONSE_BYTES {
        return Err(PhpError::OutputTooLarge);
    }
    let sha256 = Sha256::digest(&body)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect();
    Ok(HostedFile {
        status_code,
        mime_type,
        body,
        sha256,
        www_authenticate: None,
        headers: response_headers,
    })
}

fn cgi_environment_name(name: &str) -> Option<&'static str> {
    match name.to_ascii_lowercase().as_str() {
        "accept" => Some("HTTP_ACCEPT"),
        "accept-language" => Some("HTTP_ACCEPT_LANGUAGE"),
        "cookie" => Some("HTTP_COOKIE"),
        "host" => Some("HTTP_HOST"),
        "if-modified-since" => Some("HTTP_IF_MODIFIED_SINCE"),
        "if-none-match" => Some("HTTP_IF_NONE_MATCH"),
        "if-range" => Some("HTTP_IF_RANGE"),
        "origin" => Some("HTTP_ORIGIN"),
        "range" => Some("HTTP_RANGE"),
        "referer" => Some("HTTP_REFERER"),
        "user-agent" => Some("HTTP_USER_AGENT"),
        "x-requested-with" => Some("HTTP_X_REQUESTED_WITH"),
        _ => None,
    }
}

fn response_header_allowed(name: &str) -> bool {
    matches!(
        name,
        "accept-ranges"
            | "cache-control"
            | "content-disposition"
            | "content-length"
            | "content-range"
            | "etag"
            | "expires"
            | "last-modified"
            | "link"
            | "location"
            | "pragma"
            | "refresh"
            | "set-cookie"
            | "vary"
    )
}

fn find_header_end(output: &[u8]) -> Option<(usize, usize)> {
    output
        .windows(4)
        .position(|window| window == b"\r\n\r\n")
        .map(|index| (index, 4))
        .or_else(|| {
            output
                .windows(2)
                .position(|window| window == b"\n\n")
                .map(|index| (index, 2))
        })
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::sites::SiteRegistry;

    #[test]
    fn parses_php_cgi_status_content_type_and_body() {
        let response = parse_cgi_response(
            b"Status: 201 Created\r\nContent-Type: application/json\r\nSet-Cookie: PHPSESSID=abc; Path=/; HttpOnly\r\nLocation: next.php\r\nX-Powered-By: hidden\r\n\r\n{\"ok\":true}",
        )
        .unwrap();
        assert_eq!(response.status_code, 201);
        assert_eq!(response.mime_type, "application/json");
        assert_eq!(response.body, br#"{"ok":true}"#);
        assert_eq!(
            response.headers,
            vec![
                SiteHeader {
                    name: "set-cookie".into(),
                    value: "PHPSESSID=abc; Path=/; HttpOnly".into(),
                },
                SiteHeader {
                    name: "location".into(),
                    value: "next.php".into(),
                },
            ]
        );
    }

    #[test]
    fn runtime_is_unavailable_when_executable_is_missing() {
        assert!(!PhpRuntime::new(Some(PathBuf::from("missing-php-cgi.exe")), None).available());
    }

    #[tokio::test]
    async fn bundled_runtime_executes_get_and_post_without_exposing_source() {
        let executable = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join(".runtime")
            .join("php")
            .join("php-cgi.exe");
        if !executable.is_file() {
            return;
        }
        let directory = tempfile::tempdir().unwrap();
        std::fs::write(
            directory.path().join("index.php"),
            br#"<?php header('Content-Type: application/json'); echo json_encode(['name'=>$_GET['name'] ?? '', 'posted'=>$_POST['message'] ?? '', 'sqlite'=>extension_loaded('pdo_sqlite'), 'peer'=>$_SERVER['FREEDOM_PEER_ID'] ?? '']);"#,
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry
            .register("php-test", "PHP test", directory.path(), true)
            .unwrap();
        let resolved = registry.resolve("php-test", "").unwrap();
        let runtime = PhpRuntime::new(Some(executable), None);

        let get = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-alice",
                    method: "GET",
                    query: "name=Alice",
                    content_type: "",
                    headers: &[],
                    body: &[],
                },
            )
            .await
            .unwrap();
        assert_eq!(get.status_code, 200);
        assert_eq!(get.mime_type, "application/json");
        let get_json = serde_json::from_slice::<serde_json::Value>(&get.body).unwrap();
        assert_eq!(get_json["name"], "Alice");
        assert_eq!(get_json["posted"], "");
        assert_eq!(get_json["sqlite"], true);
        assert_eq!(get_json["peer"], "test-peer-alice");

        let post = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-bob",
                    method: "POST",
                    query: "name=Bob",
                    content_type: "application/x-www-form-urlencoded",
                    headers: &[],
                    body: b"message=hello+Freedom",
                },
            )
            .await
            .unwrap();
        let post_json = serde_json::from_slice::<serde_json::Value>(&post.body).unwrap();
        assert_eq!(post_json["name"], "Bob");
        assert_eq!(post_json["posted"], "hello Freedom");
        assert_eq!(post_json["sqlite"], true);
    }

    #[tokio::test]
    async fn bundled_runtime_persists_sessions_and_forwards_browser_headers() {
        let executable = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join(".runtime")
            .join("php")
            .join("php-cgi.exe");
        if !executable.is_file() {
            return;
        }
        let directory = tempfile::tempdir().unwrap();
        std::fs::write(
            directory.path().join("session.php"),
            br#"<?php session_start(); if ($_SERVER['REQUEST_METHOD']==='POST') $_SESSION['value']=$_POST['value'] ?? ''; header('Content-Type: application/json'); echo json_encode(['value'=>$_SESSION['value'] ?? '', 'range'=>$_SERVER['HTTP_RANGE'] ?? '', 'xhr'=>$_SERVER['HTTP_X_REQUESTED_WITH'] ?? '']);"#,
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry
            .register("php-test", "PHP test", directory.path(), true)
            .unwrap();
        let resolved = registry.resolve("php-test", "session.php").unwrap();
        let runtime = PhpRuntime::new(Some(executable), None);
        let browser_headers = vec![
            SiteHeader {
                name: "range".into(),
                value: "bytes=0-4095".into(),
            },
            SiteHeader {
                name: "x-requested-with".into(),
                value: "XMLHttpRequest".into(),
            },
        ];
        let first = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-session",
                    method: "GET",
                    query: "",
                    content_type: "",
                    headers: &browser_headers,
                    body: &[],
                },
            )
            .await
            .unwrap();
        let first_json = serde_json::from_slice::<serde_json::Value>(&first.body).unwrap();
        assert_eq!(first_json["range"], "bytes=0-4095");
        assert_eq!(first_json["xhr"], "XMLHttpRequest");
        let cookie = first
            .headers
            .iter()
            .find(|header| header.name == "set-cookie")
            .unwrap()
            .value
            .split(';')
            .next()
            .unwrap()
            .to_owned();
        let cookie_headers = vec![SiteHeader {
            name: "cookie".into(),
            value: cookie,
        }];
        let second = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-session",
                    method: "POST",
                    query: "",
                    content_type: "application/x-www-form-urlencoded",
                    headers: &cookie_headers,
                    body: b"value=remembered",
                },
            )
            .await
            .unwrap();
        assert_eq!(
            serde_json::from_slice::<serde_json::Value>(&second.body).unwrap()["value"],
            "remembered"
        );
        assert!(directory.path().join(".freedom-runtime/sessions").is_dir());
    }

    #[tokio::test]
    async fn bundled_runtime_accepts_multipart_uploads_over_the_old_limit() {
        let executable = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join(".runtime")
            .join("php")
            .join("php-cgi.exe");
        if !executable.is_file() {
            return;
        }
        let directory = tempfile::tempdir().unwrap();
        std::fs::create_dir(directory.path().join("uploads")).unwrap();
        std::fs::write(
            directory.path().join("upload.php"),
            br#"<?php $f=$_FILES['media'] ?? null; $ok=is_array($f) && move_uploaded_file($f['tmp_name'], __DIR__.'/uploads/upload.bin'); header('Content-Type: application/json'); echo json_encode(['ok'=>$ok,'size'=>$f['size'] ?? 0,'zip'=>extension_loaded('zip'),'gd'=>extension_loaded('gd')]);"#,
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry
            .register("php-test", "PHP test", directory.path(), true)
            .unwrap();
        let resolved = registry.resolve("php-test", "upload.php").unwrap();
        let runtime = PhpRuntime::new(Some(executable), None);
        let boundary = "----FreedomCompatibilityBoundary";
        let payload = vec![0x5a; 2 * 1024 * 1024];
        let mut body = format!(
            "--{boundary}\r\nContent-Disposition: form-data; name=\"media\"; filename=\"upload.bin\"\r\nContent-Type: application/octet-stream\r\n\r\n"
        )
        .into_bytes();
        body.extend_from_slice(&payload);
        body.extend_from_slice(format!("\r\n--{boundary}--\r\n").as_bytes());
        let response = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-upload",
                    method: "POST",
                    query: "",
                    content_type: &format!("multipart/form-data; boundary={boundary}"),
                    headers: &[],
                    body: &body,
                },
            )
            .await
            .unwrap();
        let response_json = serde_json::from_slice::<serde_json::Value>(&response.body).unwrap();
        assert_eq!(response_json["ok"], true);
        assert_eq!(response_json["size"], payload.len());
        assert_eq!(response_json["zip"], true);
        assert_eq!(response_json["gd"], true);
        assert_eq!(
            std::fs::metadata(directory.path().join("uploads/upload.bin"))
                .unwrap()
                .len(),
            payload.len() as u64
        );
    }

    #[tokio::test]
    async fn bundled_php_mail_submits_to_the_private_freedom_mail_service() {
        let executable = Path::new(env!("CARGO_MANIFEST_DIR"))
            .join("..")
            .join(".runtime")
            .join("php")
            .join("php-cgi.exe");
        if !executable.is_file() {
            return;
        }

        let recipient_peer = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id();
        let sender_peer = libp2p::identity::Keypair::generate_ed25519()
            .public()
            .to_peer_id();
        let recipient = crate::mailbox_address(&recipient_peer);
        let sender = crate::mailbox_address(&sender_peer);
        let (submission_tx, mut submission_rx) = tokio::sync::mpsc::channel(1);
        let submission_server = crate::mail::start_submission_server(submission_tx)
            .await
            .unwrap();
        let received = tokio::spawn(async move {
            let mail = submission_rx.recv().await.unwrap();
            (mail.recipient, mail.subject, mail.body)
        });

        let directory = tempfile::tempdir().unwrap();
        std::fs::write(
            directory.path().join("mail.php"),
            format!(
                "<?php echo mail('{}', 'PHP mail test', 'Created by a hosted site') ? 'sent' : 'failed';",
                recipient
            ),
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry
            .register("php-mail", "PHP mail", directory.path(), true)
            .unwrap();
        let resolved = registry.resolve("php-mail", "mail.php").unwrap();
        let runtime = PhpRuntime::new(Some(executable), Some((submission_server.port, sender)));
        let response = runtime
            .execute(
                &resolved,
                PhpRequest {
                    peer_id: "test-peer-mail",
                    method: "GET",
                    query: "",
                    content_type: "",
                    headers: &[],
                    body: &[],
                },
            )
            .await
            .unwrap();
        assert_eq!(response.body, b"sent");
        let (submitted_recipient, subject, body) = received.await.unwrap();
        assert_eq!(submitted_recipient, recipient);
        assert_eq!(subject, "PHP mail test");
        assert_eq!(body, "Created by a hosted site");
        submission_server.task.abort();
    }
}
