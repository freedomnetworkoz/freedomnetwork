use std::{io, time::Duration};

#[cfg(feature = "authority")]
use std::{
    fs,
    path::{Path, PathBuf},
};

use libp2p::PeerId;
#[cfg(feature = "authority")]
use rusqlite::{Connection, OptionalExtension, params};
use thiserror::Error;
use tokio::{
    io::{AsyncBufReadExt, AsyncReadExt, AsyncWriteExt, BufReader},
    net::{TcpListener, TcpStream},
    sync::mpsc,
    task::JoinHandle,
};

#[cfg(feature = "authority")]
use crate::models::MailRecord;
use crate::protocol::{MAX_MAIL_BODY_BYTES, MAX_MAIL_SUBJECT_BYTES};

const SMTP_LINE_LIMIT: usize = 8 * 1024;
const SMTP_MESSAGE_LIMIT: usize = MAX_MAIL_BODY_BYTES + 24 * 1024;

#[derive(Debug, Error)]
pub enum MailAddressError {
    #[error("mail address must use the username@freedom.net form")]
    InvalidFormat,
    #[error("mail address contains an invalid peer route")]
    InvalidPeer,
    #[error("the Freedom Mail authority has not been configured")]
    AuthorityUnavailable,
}

#[derive(Clone, Debug)]
pub(crate) struct MailRoute {
    pub canonical: String,
    pub provider_peer: PeerId,
    pub legacy_direct: bool,
}

pub fn mailbox_address(peer: &PeerId) -> String {
    format!("p{}@freedom.net", encode_base32(&peer.to_bytes()))
}

pub fn peer_from_mailbox(address: &str) -> Result<PeerId, MailAddressError> {
    let address = address.trim();
    if address.len() > 254 || address.chars().any(char::is_control) {
        return Err(MailAddressError::InvalidFormat);
    }
    let (local, domain) = address
        .rsplit_once('@')
        .ok_or(MailAddressError::InvalidFormat)?;
    let route = local
        .strip_prefix('p')
        .filter(|route| !route.is_empty())
        .ok_or(MailAddressError::InvalidFormat)?;
    if !domain.eq_ignore_ascii_case("freedom.net") {
        return Err(MailAddressError::InvalidFormat);
    }
    let bytes = decode_base32(route).ok_or(MailAddressError::InvalidPeer)?;
    PeerId::from_bytes(&bytes).map_err(|_| MailAddressError::InvalidPeer)
}

pub(crate) fn route_mailbox(
    address: &str,
    official_provider: Option<&PeerId>,
) -> Result<MailRoute, MailAddressError> {
    let (canonical, legacy_peer) = canonical_mailbox(address)?;
    if let Some(peer) = legacy_peer {
        return Ok(MailRoute {
            canonical,
            provider_peer: peer,
            legacy_direct: true,
        });
    }
    let provider_peer = official_provider
        .copied()
        .ok_or(MailAddressError::AuthorityUnavailable)?;
    Ok(MailRoute {
        canonical,
        provider_peer,
        legacy_direct: false,
    })
}

fn canonical_mailbox(address: &str) -> Result<(String, Option<PeerId>), MailAddressError> {
    let address = address.trim();
    if let Ok(peer) = peer_from_mailbox(address) {
        return Ok((mailbox_address(&peer), Some(peer)));
    }
    if address.len() > 254 || address.chars().any(char::is_control) {
        return Err(MailAddressError::InvalidFormat);
    }
    let (local, domain) = address
        .rsplit_once('@')
        .ok_or(MailAddressError::InvalidFormat)?;
    let local = local.to_ascii_lowercase();
    if !domain.eq_ignore_ascii_case("freedom.net") || !valid_account_name(&local) {
        return Err(MailAddressError::InvalidFormat);
    }
    Ok((format!("{local}@freedom.net"), None))
}

fn valid_account_name(value: &str) -> bool {
    let bytes = value.as_bytes();
    (3..=32).contains(&bytes.len())
        && bytes.first().is_some_and(u8::is_ascii_alphanumeric)
        && bytes.last().is_some_and(u8::is_ascii_alphanumeric)
        && bytes
            .iter()
            .all(|byte| byte.is_ascii_alphanumeric() || matches!(byte, b'.' | b'_' | b'-'))
        && !value.contains("..")
}

#[cfg(feature = "authority")]
pub(crate) struct OfficialMailProvider {
    connection: Connection,
    path: PathBuf,
    provider_peer: PeerId,
}

#[cfg(feature = "authority")]
impl OfficialMailProvider {
    pub(crate) fn open(htdocs_root: &Path, provider_peer: PeerId) -> Result<Self, String> {
        let directory = htdocs_root.join("freedom").join("mail").join("data");
        fs::create_dir_all(&directory).map_err(|error| error.to_string())?;
        let path = directory.join("mail.sqlite");
        let connection = Connection::open(&path).map_err(|error| error.to_string())?;
        connection
            .busy_timeout(Duration::from_secs(5))
            .map_err(|error| error.to_string())?;
        connection
            .execute_batch(
                "PRAGMA journal_mode=WAL;
                 PRAGMA synchronous=NORMAL;
                 PRAGMA foreign_keys=ON;
                 CREATE TABLE IF NOT EXISTS accounts (
                   id INTEGER PRIMARY KEY AUTOINCREMENT,
                   username TEXT NOT NULL COLLATE NOCASE UNIQUE,
                   address TEXT NOT NULL COLLATE NOCASE UNIQUE,
                   password_hash TEXT NOT NULL,
                   created_peer_id TEXT NOT NULL,
                   last_peer_id TEXT NOT NULL,
                   created_at INTEGER NOT NULL,
                   last_login_at INTEGER,
                   active INTEGER NOT NULL DEFAULT 1,
                   is_admin INTEGER NOT NULL DEFAULT 0,
                   deleted_at INTEGER
                 );
                 CREATE INDEX IF NOT EXISTS accounts_peer_active
                   ON accounts(created_peer_id, active);
                 CREATE TABLE IF NOT EXISTS peer_bans (
                   peer_id TEXT PRIMARY KEY,
                   reason TEXT NOT NULL,
                   created_at INTEGER NOT NULL
                 );
                 CREATE TABLE IF NOT EXISTS mailbox_messages (
                   id TEXT PRIMARY KEY,
                   account_id INTEGER NOT NULL,
                   direction TEXT NOT NULL CHECK(direction IN ('in','out')),
                   sender TEXT NOT NULL,
                   recipient TEXT NOT NULL,
                   timestamp INTEGER NOT NULL,
                   subject TEXT NOT NULL,
                   body TEXT NOT NULL,
                   state TEXT NOT NULL,
                   is_read INTEGER NOT NULL DEFAULT 0,
                   FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
                 );
                 CREATE INDEX IF NOT EXISTS mailbox_account_time
                   ON mailbox_messages(account_id, timestamp DESC);
                 CREATE TRIGGER IF NOT EXISTS accounts_limit_per_peer
                 BEFORE INSERT ON accounts
                 WHEN NEW.active = 1 AND NEW.is_admin = 0 AND
                   (SELECT COUNT(*) FROM accounts
                    WHERE created_peer_id = NEW.created_peer_id AND active = 1) >= 3
                 BEGIN
                   SELECT RAISE(ABORT, 'peer address limit reached');
                 END;
                 CREATE TRIGGER IF NOT EXISTS accounts_reject_banned_peer
                 BEFORE INSERT ON accounts
                 WHEN NEW.is_admin = 0 AND EXISTS
                   (SELECT 1 FROM peer_bans WHERE peer_id = NEW.created_peer_id)
                 BEGIN
                   SELECT RAISE(ABORT, 'peer is banned from mail signup');
                 END;",
            )
            .map_err(|error| error.to_string())?;
        Ok(Self {
            connection,
            path,
            provider_peer,
        })
    }

    pub(crate) fn path(&self) -> &Path {
        &self.path
    }

    pub(crate) fn sender_allowed(&self, address: &str, sending_peer: &PeerId) -> bool {
        let Ok(route) = route_mailbox(address, Some(&self.provider_peer)) else {
            return false;
        };
        if route.legacy_direct {
            return route.provider_peer == *sending_peer;
        }
        let allow_provider = sending_peer == &self.provider_peer;
        self.connection
            .query_row(
                "SELECT 1 FROM accounts
                 WHERE address = ?1 COLLATE NOCASE AND active = 1
                   AND (?2 = 1 OR created_peer_id = ?3)",
                params![route.canonical, allow_provider, sending_peer.to_string()],
                |_| Ok(()),
            )
            .optional()
            .ok()
            .flatten()
            .is_some()
    }

    pub(crate) fn deliver(&self, mail: &MailRecord) -> Result<Option<bool>, String> {
        let account_id = self
            .connection
            .query_row(
                "SELECT id FROM accounts WHERE address = ?1 COLLATE NOCASE AND active = 1",
                [&mail.recipient],
                |row| row.get::<_, i64>(0),
            )
            .optional()
            .map_err(|error| error.to_string())?;
        let Some(account_id) = account_id else {
            return Ok(None);
        };
        self.connection
            .execute(
                "INSERT OR IGNORE INTO mailbox_messages
                   (id, account_id, direction, sender, recipient, timestamp, subject, body, state, is_read)
                 VALUES (?1, ?2, 'in', ?3, ?4, ?5, ?6, ?7, 'received', 0)",
                params![
                    mail.id,
                    account_id,
                    mail.sender,
                    mail.recipient,
                    mail.timestamp,
                    mail.subject,
                    mail.body,
                ],
            )
            .map(|rows| Some(rows > 0))
            .map_err(|error| error.to_string())
    }
}

fn encode_base32(value: &[u8]) -> String {
    let mut output = String::with_capacity(value.len().div_ceil(5) * 8);
    let mut buffer = 0_u32;
    let mut bits = 0_u8;
    for byte in value {
        buffer = (buffer << 8) | u32::from(*byte);
        bits += 8;
        while bits >= 5 {
            bits -= 5;
            output.push(
                b"abcdefghijklmnopqrstuvwxyz234567"[((buffer >> bits) & 31) as usize] as char,
            );
            buffer &= (1_u32 << bits) - 1;
        }
    }
    if bits > 0 {
        output.push(
            b"abcdefghijklmnopqrstuvwxyz234567"[((buffer << (5 - bits)) & 31) as usize] as char,
        );
    }
    output
}

fn decode_base32(value: &str) -> Option<Vec<u8>> {
    let mut output = Vec::with_capacity(value.len() * 5 / 8);
    let mut buffer = 0_u32;
    let mut bits = 0_u8;
    for byte in value.bytes() {
        let digit = match byte.to_ascii_lowercase() {
            b'a'..=b'z' => byte.to_ascii_lowercase() - b'a',
            b'2'..=b'7' => byte - b'2' + 26,
            _ => return None,
        };
        buffer = (buffer << 5) | u32::from(digit);
        bits += 5;
        if bits >= 8 {
            bits -= 8;
            output.push((buffer >> bits) as u8);
            buffer &= (1_u32 << bits) - 1;
        }
    }
    (bits == 0 || buffer == 0).then_some(output)
}

pub(crate) struct SubmittedMail {
    pub sender: Option<String>,
    pub recipient: String,
    pub subject: String,
    pub body: String,
}

pub(crate) struct SubmissionServer {
    pub port: u16,
    pub task: JoinHandle<()>,
}

pub(crate) async fn start_submission_server(
    submissions: mpsc::Sender<SubmittedMail>,
) -> io::Result<SubmissionServer> {
    let listener = TcpListener::bind(("127.0.0.1", 0)).await?;
    let port = listener.local_addr()?.port();
    let task = tokio::spawn(async move {
        while let Ok((stream, address)) = listener.accept().await {
            if !address.ip().is_loopback() {
                continue;
            }
            let submissions = submissions.clone();
            tokio::spawn(async move {
                let _ = tokio::time::timeout(
                    Duration::from_secs(30),
                    handle_submission(stream, submissions),
                )
                .await;
            });
        }
    });
    Ok(SubmissionServer { port, task })
}

async fn handle_submission(
    stream: TcpStream,
    submissions: mpsc::Sender<SubmittedMail>,
) -> io::Result<()> {
    let mut stream = BufReader::new(stream);
    write_reply(&mut stream, "220 Freedom Mail submission ready\r\n").await?;
    let mut greeted = false;
    let mut sender = None;
    let mut recipient = None;

    loop {
        let Some(line) = read_line(&mut stream).await? else {
            return Ok(());
        };
        let command = line.trim_end_matches(['\r', '\n']);
        let upper = command.to_ascii_uppercase();
        if upper.starts_with("EHLO ") || upper.starts_with("HELO ") {
            greeted = true;
            sender = None;
            recipient = None;
            write_reply(
                &mut stream,
                &format!("250-Freedom Mail\r\n250 SIZE {SMTP_MESSAGE_LIMIT}\r\n"),
            )
            .await?;
        } else if upper.starts_with("MAIL FROM:") && greeted {
            let Some(value) = smtp_path(command).filter(|value| canonical_mailbox(value).is_ok())
            else {
                write_reply(&mut stream, "501 Invalid Freedom sender\r\n").await?;
                continue;
            };
            sender = Some(value.to_owned());
            recipient = None;
            write_reply(&mut stream, "250 Sender accepted\r\n").await?;
        } else if upper.starts_with("RCPT TO:") && sender.is_some() {
            let Some(value) = smtp_path(command) else {
                write_reply(&mut stream, "501 Invalid recipient\r\n").await?;
                continue;
            };
            if canonical_mailbox(value).is_err() {
                write_reply(&mut stream, "550 Unknown Freedom mail route\r\n").await?;
                continue;
            }
            if recipient.is_some() {
                write_reply(&mut stream, "452 One recipient per message\r\n").await?;
                continue;
            }
            recipient = Some(value.to_owned());
            write_reply(&mut stream, "250 Recipient accepted\r\n").await?;
        } else if upper == "DATA" && recipient.is_some() {
            write_reply(&mut stream, "354 End data with <CRLF>.<CRLF>\r\n").await?;
            let Some(data) = read_message_data(&mut stream).await? else {
                write_reply(&mut stream, "552 Message too large\r\n").await?;
                return Ok(());
            };
            let (header_sender, subject, body) = parse_message(&data);
            let recipient = recipient.take().unwrap_or_default();
            let submission = SubmittedMail {
                sender: header_sender.or_else(|| sender.clone()),
                recipient,
                subject,
                body,
            };
            if submissions.send(submission).await.is_err() {
                write_reply(&mut stream, "451 Mail service unavailable\r\n").await?;
                continue;
            }
            write_reply(&mut stream, "250 Queued by Freedom\r\n").await?;
            sender = None;
        } else if upper == "RSET" {
            sender = None;
            recipient = None;
            write_reply(&mut stream, "250 Reset\r\n").await?;
        } else if upper == "NOOP" {
            write_reply(&mut stream, "250 OK\r\n").await?;
        } else if upper == "QUIT" {
            write_reply(&mut stream, "221 Goodbye\r\n").await?;
            return Ok(());
        } else {
            write_reply(&mut stream, "503 Bad command sequence\r\n").await?;
        }
    }
}

async fn read_line(stream: &mut BufReader<TcpStream>) -> io::Result<Option<String>> {
    let mut line = String::new();
    let read = (&mut *stream)
        .take((SMTP_LINE_LIMIT + 1) as u64)
        .read_line(&mut line)
        .await?;
    if read == 0 {
        return Ok(None);
    }
    if read > SMTP_LINE_LIMIT || !line.ends_with('\n') {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            "SMTP line too long",
        ));
    }
    Ok(Some(line))
}

async fn read_message_data(stream: &mut BufReader<TcpStream>) -> io::Result<Option<Vec<String>>> {
    let mut lines = Vec::new();
    let mut size = 0_usize;
    loop {
        let Some(mut line) = read_line(stream).await? else {
            return Ok(None);
        };
        if line == ".\r\n" || line == ".\n" {
            return Ok(Some(lines));
        }
        if line.starts_with("..") {
            line.remove(0);
        }
        size = size.saturating_add(line.len());
        if size > SMTP_MESSAGE_LIMIT {
            return Ok(None);
        }
        lines.push(line);
    }
}

async fn write_reply(stream: &mut BufReader<TcpStream>, value: &str) -> io::Result<()> {
    stream.get_mut().write_all(value.as_bytes()).await
}

fn smtp_path(command: &str) -> Option<&str> {
    let start = command.find('<')? + 1;
    let end = command[start..].find('>')? + start;
    (end > start).then_some(command[start..end].trim())
}

fn parse_message(lines: &[String]) -> (Option<String>, String, String) {
    let split = lines
        .iter()
        .position(|line| line == "\r\n" || line == "\n")
        .unwrap_or(lines.len());
    let subject = lines[..split]
        .iter()
        .find_map(|line| {
            let (name, value) = line.split_once(':')?;
            name.eq_ignore_ascii_case("subject")
                .then(|| value.trim().to_owned())
        })
        .filter(|subject| subject.len() <= MAX_MAIL_SUBJECT_BYTES)
        .unwrap_or_else(|| "(no subject)".into());
    let sender = lines[..split].iter().find_map(|line| {
        let (name, value) = line.split_once(':')?;
        if !name.eq_ignore_ascii_case("from") {
            return None;
        }
        let value = value.trim();
        let address = if let Some(start) = value.find('<') {
            let end = value[start + 1..].find('>')? + start + 1;
            value.get(start + 1..end)?
        } else {
            value
        };
        canonical_mailbox(address)
            .ok()
            .map(|(canonical, _)| canonical)
    });
    let body = lines
        .get(split.saturating_add(1)..)
        .unwrap_or_default()
        .join("")
        .trim_end_matches(['\r', '\n'])
        .to_owned();
    let body = if body.len() <= MAX_MAIL_BODY_BYTES {
        body
    } else {
        String::new()
    };
    (sender, subject, body)
}

#[cfg(test)]
mod tests {
    use super::*;
    use libp2p::identity::Keypair;

    #[test]
    fn routable_mailbox_round_trips_the_peer_id() {
        let peer = Keypair::generate_ed25519().public().to_peer_id();
        let address = mailbox_address(&peer);
        assert!(address.starts_with('p'));
        assert!(address.ends_with("@freedom.net"));
        assert_eq!(peer_from_mailbox(&address).unwrap(), peer);
        assert!(peer_from_mailbox("alice@example.com").is_err());
        let authority = Keypair::generate_ed25519().public().to_peer_id();
        let friendly = route_mailbox("Alice.Smith@FREEDOM.NET", Some(&authority)).unwrap();
        assert_eq!(friendly.canonical, "alice.smith@freedom.net");
        assert_eq!(friendly.provider_peer, authority);
        assert!(!friendly.legacy_direct);
        assert!(route_mailbox("bad..name@freedom.net", Some(&authority)).is_err());
        assert!(matches!(
            route_mailbox("alice@freedom.net", None),
            Err(MailAddressError::AuthorityUnavailable)
        ));
    }

    #[test]
    fn smtp_message_parser_separates_subject_and_body() {
        let lines = vec![
            "From: Alice <alice@freedom.net>\r\n".into(),
            "Subject: Welcome to Freedom\r\n".into(),
            "\r\n".into(),
            "Hello from a PHP site.\r\n".into(),
        ];
        assert_eq!(
            parse_message(&lines),
            (
                Some("alice@freedom.net".into()),
                "Welcome to Freedom".into(),
                "Hello from a PHP site.".into()
            )
        );
    }

    #[cfg(feature = "authority")]
    #[test]
    fn official_provider_delivers_only_to_active_accounts_and_deduplicates() {
        let root = tempfile::tempdir().unwrap();
        let provider_peer = Keypair::generate_ed25519().public().to_peer_id();
        let provider = OfficialMailProvider::open(root.path(), provider_peer).unwrap();
        let created_peer = Keypair::generate_ed25519().public().to_peer_id();
        provider
            .connection
            .execute(
                "INSERT INTO accounts
                   (username,address,password_hash,created_peer_id,last_peer_id,created_at,active,is_admin)
                 VALUES ('alice','alice@freedom.net','hash',?1,?1,1,1,0)",
                [created_peer.to_string()],
            )
            .unwrap();
        let mail = MailRecord {
            id: uuid::Uuid::new_v4().to_string(),
            direction: "in".into(),
            peer_id: created_peer.to_string(),
            sender: mailbox_address(&created_peer),
            recipient: "alice@freedom.net".into(),
            timestamp: 1,
            subject: "Hello".into(),
            body: "Provider delivery".into(),
            state: "received".into(),
            read: false,
        };
        assert_eq!(provider.deliver(&mail).unwrap(), Some(true));
        assert_eq!(provider.deliver(&mail).unwrap(), Some(false));
        let mut unknown = mail;
        unknown.id = uuid::Uuid::new_v4().to_string();
        unknown.recipient = "nobody@freedom.net".into();
        assert_eq!(provider.deliver(&unknown).unwrap(), None);
        assert!(provider.sender_allowed("alice@freedom.net", &created_peer));

        for username in ["alice2", "alice3"] {
            provider
                .connection
                .execute(
                    "INSERT INTO accounts
                       (username,address,password_hash,created_peer_id,last_peer_id,created_at,active,is_admin)
                     VALUES (?1,?2,'hash',?3,?3,1,1,0)",
                    params![
                        username,
                        format!("{username}@freedom.net"),
                        created_peer.to_string()
                    ],
                )
                .unwrap();
        }
        assert!(
            provider
                .connection
                .execute(
                    "INSERT INTO accounts
                       (username,address,password_hash,created_peer_id,last_peer_id,created_at,active,is_admin)
                     VALUES ('alice4','alice4@freedom.net','hash',?1,?1,1,1,0)",
                    [created_peer.to_string()],
                )
                .is_err()
        );

        let banned_peer = Keypair::generate_ed25519().public().to_peer_id();
        provider
            .connection
            .execute(
                "INSERT INTO peer_bans(peer_id,reason,created_at) VALUES (?1,'test',1)",
                [banned_peer.to_string()],
            )
            .unwrap();
        assert!(
            provider
                .connection
                .execute(
                    "INSERT INTO accounts
                       (username,address,password_hash,created_peer_id,last_peer_id,created_at,active,is_admin)
                     VALUES ('banned','banned@freedom.net','hash',?1,?1,1,1,0)",
                    [banned_peer.to_string()],
                )
                .is_err()
        );
    }
}
