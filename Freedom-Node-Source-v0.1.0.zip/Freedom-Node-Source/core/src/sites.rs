use std::{
    collections::BTreeMap,
    fs::{self, File, OpenOptions},
    io::{Read, Seek, SeekFrom, Write},
    path::{Component, Path, PathBuf},
};

use base64::{Engine as _, engine::general_purpose::STANDARD};
use md5::Md5;
use serde::{Deserialize, Serialize};
use sha1::Sha1;
use sha2::{Digest, Sha256};
use subtle::ConstantTimeEq;
use thiserror::Error;
use uuid::Uuid;

use crate::{
    models::SiteConfig,
    protocol::{MAX_SITE_RANGE_BYTES, MAX_SITE_RESPONSE_BYTES, SiteHeader},
};

pub const MAX_SITE_FILE_BYTES: u64 = 128 * 1024 * 1024;
const MAX_ACCESS_FILE_BYTES: u64 = 64 * 1024;

#[derive(Clone, Debug, PartialEq, Eq)]
pub(crate) enum AccessPolicy {
    Public,
    Denied,
    Basic {
        realm: String,
        user_file: PathBuf,
        allowed_users: Option<Vec<String>>,
    },
}

#[derive(Default)]
struct AccessConfig {
    denied: bool,
    auth_type_basic: bool,
    auth_seen: bool,
    realm: Option<String>,
    user_file: Option<PathBuf>,
    user_requirement: Option<UserRequirement>,
}

enum UserRequirement {
    Any,
    Named(Vec<String>),
}

#[derive(Clone, Debug)]
pub struct HostedFile {
    pub status_code: u16,
    pub mime_type: String,
    pub body: Vec<u8>,
    pub sha256: String,
    pub www_authenticate: Option<String>,
    pub headers: Vec<SiteHeader>,
}

impl HostedFile {
    pub(crate) fn text(status_code: u16, message: &str, www_authenticate: Option<String>) -> Self {
        let body = message.as_bytes().to_vec();
        Self {
            status_code,
            mime_type: "text/plain; charset=utf-8".to_owned(),
            sha256: hex_digest(&body),
            body,
            www_authenticate,
            headers: Vec::new(),
        }
    }
}

#[derive(Clone, Debug)]
pub(crate) struct ResolvedSiteFile {
    pub root: PathBuf,
    pub path: PathBuf,
    pub relative_path: String,
    pub is_php: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct UploadedFile {
    pub path: String,
    pub bytes: usize,
    pub sha256: String,
}

#[derive(Debug, Error)]
pub enum SiteError {
    #[error("site identifier must contain 1-48 lowercase letters, digits, or hyphens")]
    InvalidId,
    #[error("site name must contain 1-80 printable characters")]
    InvalidName,
    #[error("site root is not a readable directory")]
    InvalidRoot,
    #[error("site is unknown or disabled")]
    Unavailable,
    #[error("a site with that identifier already exists")]
    AlreadyExists,
    #[error("requested path is unsafe")]
    UnsafePath,
    #[error("file was not found")]
    NotFound,
    #[error("PHP source cannot be served without the built-in PHP runtime")]
    PhpRuntimeRequired,
    #[error("file exceeds the {MAX_SITE_FILE_BYTES} byte limit")]
    TooLarge,
    #[error("site file I/O failed: {0}")]
    Io(#[from] std::io::Error),
    #[error("site access configuration is invalid or unsupported")]
    InvalidAccessConfiguration,
}

pub struct SiteRegistry {
    sites: BTreeMap<String, SiteConfig>,
}

impl SiteRegistry {
    pub fn new(sites: Vec<SiteConfig>) -> Self {
        Self {
            sites: sites
                .into_iter()
                .map(|site| (site.site_id.clone(), site))
                .collect(),
        }
    }

    pub fn register(
        &mut self,
        site_id: &str,
        name: &str,
        root: &Path,
        enabled: bool,
    ) -> Result<SiteConfig, SiteError> {
        validate_id(site_id)?;
        if name.trim().is_empty() || name.chars().count() > 80 || name.chars().any(char::is_control)
        {
            return Err(SiteError::InvalidName);
        }
        let canonical = fs::canonicalize(root).map_err(|_| SiteError::InvalidRoot)?;
        if !canonical.is_dir() {
            return Err(SiteError::InvalidRoot);
        }
        let site = SiteConfig {
            site_id: site_id.to_owned(),
            name: name.trim().to_owned(),
            root: canonical.to_string_lossy().into_owned(),
            enabled,
        };
        self.sites.insert(site_id.to_owned(), site.clone());
        Ok(site)
    }

    /// Register valid site directories that were copied directly into htdocs.
    /// The desktop uploader remains the normal path, but a portable web root
    /// should also work when its owner copies an existing site folder into it.
    pub fn discover_managed(&mut self, htdocs_root: &Path) -> Result<Vec<SiteConfig>, SiteError> {
        let root = fs::canonicalize(htdocs_root).map_err(|_| SiteError::InvalidRoot)?;
        let mut site_ids = fs::read_dir(&root)?
            .filter_map(Result::ok)
            .filter_map(|entry| {
                entry
                    .file_type()
                    .ok()
                    .filter(|kind| kind.is_dir())
                    .and_then(|_| entry.file_name().into_string().ok())
            })
            .collect::<Vec<_>>();
        site_ids.sort();

        let mut discovered = Vec::new();
        for site_id in site_ids {
            if self.sites.contains_key(&site_id) || validate_id(&site_id).is_err() {
                continue;
            }
            let candidate = fs::canonicalize(root.join(&site_id))?;
            if !candidate.starts_with(&root) || !candidate.is_dir() {
                continue;
            }
            discovered.push(self.register(&site_id, &site_id, &candidate, true)?);
        }
        Ok(discovered)
    }

    pub fn create_managed(
        &mut self,
        site_id: &str,
        name: &str,
        htdocs_root: &Path,
    ) -> Result<SiteConfig, SiteError> {
        validate_id(site_id)?;
        if self.sites.contains_key(site_id) {
            return Err(SiteError::AlreadyExists);
        }
        fs::create_dir_all(htdocs_root)?;
        let htdocs_root = fs::canonicalize(htdocs_root).map_err(|_| SiteError::InvalidRoot)?;
        let requested_root = htdocs_root.join(site_id);
        if !requested_root.exists() {
            fs::create_dir(&requested_root)?;
        }
        let site_root = fs::canonicalize(&requested_root).map_err(|_| SiteError::InvalidRoot)?;
        if !site_root.starts_with(&htdocs_root) || !site_root.is_dir() {
            return Err(SiteError::InvalidRoot);
        }
        let site = self.register(site_id, name, &site_root, true)?;
        let index = site_root.join("index.html");
        if !index.exists() {
            let starter = format!(
                "<!doctype html><html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width\"><title>{}</title><style>body{{font:18px system-ui;max-width:760px;margin:12vh auto;padding:28px;background:#071018;color:#edf8f3}}code{{color:#72e0ad}}</style></head><body><h1>{}</h1><p>Your Freedom site is ready.</p><p>Upload files here or edit <code>index.html</code> in this site's htdocs folder.</p></body></html>",
                escape_html(name),
                escape_html(name)
            );
            let mut file = OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(index)?;
            file.write_all(starter.as_bytes())?;
            file.sync_all()?;
        }
        Ok(site)
    }

    pub fn write_file(
        &self,
        site_id: &str,
        request_path: &str,
        body: &[u8],
    ) -> Result<UploadedFile, SiteError> {
        if body.len() as u64 > MAX_SITE_FILE_BYTES {
            return Err(SiteError::TooLarge);
        }
        let site = self.sites.get(site_id).ok_or(SiteError::Unavailable)?;
        let root = fs::canonicalize(&site.root).map_err(|_| SiteError::Unavailable)?;
        let relative = safe_upload_path(request_path)?;
        let mut components = relative.components().collect::<Vec<_>>();
        let Some(Component::Normal(file_name)) = components.pop() else {
            return Err(SiteError::UnsafePath);
        };
        let mut parent = root.clone();
        for component in components {
            let Component::Normal(name) = component else {
                return Err(SiteError::UnsafePath);
            };
            let next = parent.join(name);
            if !next.exists() {
                fs::create_dir(&next)?;
            }
            let canonical = fs::canonicalize(&next).map_err(|_| SiteError::UnsafePath)?;
            if !canonical.starts_with(&root) || !canonical.is_dir() {
                return Err(SiteError::UnsafePath);
            }
            parent = canonical;
        }

        let target = parent.join(file_name);
        if target.exists() {
            let canonical = fs::canonicalize(&target).map_err(|_| SiteError::UnsafePath)?;
            if !canonical.starts_with(&root) || !canonical.is_file() {
                return Err(SiteError::UnsafePath);
            }
        }

        let nonce = Uuid::new_v4();
        let temporary = parent.join(format!(".freedom-upload-{nonce}.tmp"));
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(&temporary)?;
        file.write_all(body)?;
        file.sync_all()?;
        drop(file);

        if target.exists() {
            let backup = parent.join(format!(".freedom-upload-{nonce}.bak"));
            fs::rename(&target, &backup)?;
            if let Err(error) = fs::rename(&temporary, &target) {
                let _ = fs::rename(&backup, &target);
                let _ = fs::remove_file(&temporary);
                return Err(SiteError::Io(error));
            }
            fs::remove_file(backup)?;
        } else {
            fs::rename(&temporary, &target)?;
        }

        Ok(UploadedFile {
            path: relative.to_string_lossy().replace('\\', "/"),
            bytes: body.len(),
            sha256: hex_digest(body),
        })
    }

    pub(crate) fn resolve(
        &self,
        site_id: &str,
        request_path: &str,
    ) -> Result<ResolvedSiteFile, SiteError> {
        let site = self
            .sites
            .get(site_id)
            .filter(|site| site.enabled)
            .ok_or(SiteError::Unavailable)?;
        let root = fs::canonicalize(&site.root).map_err(|_| SiteError::Unavailable)?;
        let relative = safe_relative_path(request_path)?;
        let mut candidate = root.join(relative);
        if candidate.is_dir() || request_path.is_empty() || request_path.ends_with('/') {
            let php_index = candidate.join("index.php");
            candidate = if php_index.is_file() {
                php_index
            } else {
                candidate.join("index.html")
            };
        }
        let candidate = fs::canonicalize(candidate).map_err(|error| {
            if error.kind() == std::io::ErrorKind::NotFound {
                SiteError::NotFound
            } else {
                SiteError::Io(error)
            }
        })?;
        if !candidate.starts_with(&root) || !candidate.is_file() {
            return Err(SiteError::UnsafePath);
        }
        let relative_path = candidate
            .strip_prefix(&root)
            .map_err(|_| SiteError::UnsafePath)?
            .to_string_lossy()
            .replace('\\', "/");
        let is_php = candidate
            .extension()
            .is_some_and(|extension| extension.eq_ignore_ascii_case("php"));
        Ok(ResolvedSiteFile {
            root,
            path: candidate,
            relative_path,
            is_php,
        })
    }

    pub(crate) fn access_policy(
        &self,
        site_id: &str,
        request_path: &str,
    ) -> Result<AccessPolicy, SiteError> {
        let site = self
            .sites
            .get(site_id)
            .filter(|site| site.enabled)
            .ok_or(SiteError::Unavailable)?;
        let root = fs::canonicalize(&site.root).map_err(|_| SiteError::Unavailable)?;
        let relative = safe_relative_path(request_path)?;
        if sensitive_public_path(&relative) {
            return Ok(AccessPolicy::Denied);
        }

        let requested = root.join(&relative);
        let requested_directory =
            if request_path.is_empty() || request_path.ends_with('/') || requested.is_dir() {
                requested.clone()
            } else {
                requested
                    .parent()
                    .map(Path::to_path_buf)
                    .unwrap_or_else(|| root.clone())
            };
        let relative_directory = requested_directory
            .strip_prefix(&root)
            .map_err(|_| SiteError::UnsafePath)?;
        let mut directories = vec![root.clone()];
        let mut current = root.clone();
        for component in relative_directory.components() {
            let Component::Normal(name) = component else {
                return Err(SiteError::UnsafePath);
            };
            let next = current.join(name);
            if !next.exists() {
                break;
            }
            let canonical = fs::canonicalize(next).map_err(|_| SiteError::UnsafePath)?;
            if !canonical.starts_with(&root) || !canonical.is_dir() {
                return Err(SiteError::UnsafePath);
            }
            directories.push(canonical.clone());
            current = canonical;
        }

        let mut config = AccessConfig::default();
        let requested_file_name = relative
            .file_name()
            .and_then(|name| name.to_str())
            .unwrap_or_default();
        for directory in directories {
            apply_access_file(&root, &directory, requested_file_name, &mut config)?;
        }
        if config.denied {
            return Ok(AccessPolicy::Denied);
        }
        if !config.auth_seen {
            return Ok(AccessPolicy::Public);
        }
        if !config.auth_type_basic {
            return Err(SiteError::InvalidAccessConfiguration);
        }
        let user_file = config
            .user_file
            .ok_or(SiteError::InvalidAccessConfiguration)?;
        let allowed_users = match config
            .user_requirement
            .ok_or(SiteError::InvalidAccessConfiguration)?
        {
            UserRequirement::Any => None,
            UserRequirement::Named(users) => Some(users),
        };

        if let Ok(candidate) = fs::canonicalize(&requested)
            && candidate == user_file
        {
            return Ok(AccessPolicy::Denied);
        }
        Ok(AccessPolicy::Basic {
            realm: config.realm.unwrap_or_else(|| "Restricted".to_owned()),
            user_file,
            allowed_users,
        })
    }

    pub fn read(&self, site_id: &str, request_path: &str) -> Result<HostedFile, SiteError> {
        self.read_for_request(site_id, request_path, None, false)
    }

    pub(crate) fn read_for_request(
        &self,
        site_id: &str,
        request_path: &str,
        range: Option<&str>,
        head_only: bool,
    ) -> Result<HostedFile, SiteError> {
        let resolved = self.resolve(site_id, request_path)?;
        if resolved.is_php {
            return Err(SiteError::PhpRuntimeRequired);
        }
        let metadata = fs::metadata(&resolved.path)?;
        let file_size = metadata.len();
        if file_size > MAX_SITE_FILE_BYTES {
            return Err(SiteError::TooLarge);
        }
        let mut status_code = 200;
        let mut headers = vec![SiteHeader {
            name: "accept-ranges".to_owned(),
            value: "bytes".to_owned(),
        }];
        let selected = match range {
            Some(value) => match parse_byte_range(value, file_size) {
                Some(value) => {
                    status_code = 206;
                    headers.push(SiteHeader {
                        name: "content-range".to_owned(),
                        value: format!("bytes {}-{}/{file_size}", value.0, value.1),
                    });
                    Some(value)
                }
                None => {
                    headers.push(SiteHeader {
                        name: "content-range".to_owned(),
                        value: format!("bytes */{file_size}"),
                    });
                    return Ok(HostedFile {
                        status_code: 416,
                        mime_type: "text/plain; charset=utf-8".to_owned(),
                        body: Vec::new(),
                        sha256: hex_digest(&[]),
                        www_authenticate: None,
                        headers,
                    });
                }
            },
            None => None,
        };
        let response_length = selected
            .map(|(start, end)| end - start + 1)
            .unwrap_or(file_size);
        if response_length > MAX_SITE_RESPONSE_BYTES as u64 && !head_only {
            return Err(SiteError::TooLarge);
        }
        headers.push(SiteHeader {
            name: "content-length".to_owned(),
            value: response_length.to_string(),
        });
        let body = if head_only {
            Vec::new()
        } else if let Some((start, _)) = selected {
            let mut file = File::open(&resolved.path)?;
            file.seek(SeekFrom::Start(start))?;
            let mut body = Vec::with_capacity(response_length as usize);
            file.take(response_length).read_to_end(&mut body)?;
            body
        } else {
            fs::read(&resolved.path)?
        };
        let sha256 = hex_digest(&body);
        let mime_type = mime_guess::from_path(&resolved.path)
            .first_or_octet_stream()
            .essence_str()
            .to_owned();
        Ok(HostedFile {
            status_code,
            mime_type,
            body,
            sha256,
            www_authenticate: None,
            headers,
        })
    }

    pub fn list(&self) -> Vec<SiteConfig> {
        self.sites.values().cloned().collect()
    }

    pub fn set_enabled(&mut self, site_id: &str, enabled: bool) -> Result<SiteConfig, SiteError> {
        let site = self.sites.get_mut(site_id).ok_or(SiteError::Unavailable)?;
        site.enabled = enabled;
        Ok(site.clone())
    }
}

fn parse_byte_range(value: &str, file_size: u64) -> Option<(u64, u64)> {
    if file_size == 0 {
        return None;
    }
    let range = value.trim().strip_prefix("bytes=")?;
    if range.contains(',') {
        return None;
    }
    let (start, end) = range.split_once('-')?;
    let (start, requested_end) = if start.is_empty() {
        let suffix = end.parse::<u64>().ok()?.min(MAX_SITE_RANGE_BYTES);
        if suffix == 0 {
            return None;
        }
        (file_size.saturating_sub(suffix), file_size - 1)
    } else {
        let start = start.parse::<u64>().ok()?;
        if start >= file_size {
            return None;
        }
        let requested_end = if end.is_empty() {
            file_size - 1
        } else {
            end.parse::<u64>().ok()?.min(file_size - 1)
        };
        if requested_end < start {
            return None;
        }
        (start, requested_end)
    };
    let capped_end = start
        .saturating_add(MAX_SITE_RANGE_BYTES - 1)
        .min(requested_end);
    Some((start, capped_end))
}

pub(crate) fn basic_credentials(header_value: Option<&str>) -> Option<(String, String)> {
    let value = header_value?.trim();
    let separator = value.find(char::is_whitespace)?;
    let (scheme, encoded) = value.split_at(separator);
    if !scheme.eq_ignore_ascii_case("basic") {
        return None;
    }
    let encoded = encoded.trim();
    if encoded.is_empty() || encoded.len() > 4096 {
        return None;
    }
    let decoded = STANDARD.decode(encoded).ok()?;
    if decoded.len() > 1024 {
        return None;
    }
    let decoded = String::from_utf8(decoded).ok()?;
    let (username, password) = decoded.split_once(':')?;
    if username.is_empty()
        || username.len() > 128
        || password.len() > 768
        || username.chars().any(char::is_control)
        || password.chars().any(char::is_control)
    {
        return None;
    }
    Some((username.to_owned(), password.to_owned()))
}

pub(crate) fn authorize_basic(
    policy: &AccessPolicy,
    username: &str,
    password: &str,
) -> Result<bool, SiteError> {
    let AccessPolicy::Basic {
        user_file,
        allowed_users,
        ..
    } = policy
    else {
        return Ok(false);
    };
    if allowed_users
        .as_ref()
        .is_some_and(|users| !users.iter().any(|user| user == username))
    {
        return Ok(false);
    }
    let metadata = fs::metadata(user_file)?;
    if !metadata.is_file() || metadata.len() > MAX_ACCESS_FILE_BYTES {
        return Err(SiteError::InvalidAccessConfiguration);
    }
    let contents =
        fs::read_to_string(user_file).map_err(|_| SiteError::InvalidAccessConfiguration)?;
    let Some(hash) = contents.lines().find_map(|line| {
        let line = line.trim_end_matches('\r');
        let (candidate, hash) = line.split_once(':')?;
        (candidate == username && !hash.is_empty()).then_some(hash)
    }) else {
        return Ok(false);
    };
    Ok(verify_password(password, hash))
}

fn apply_access_file(
    root: &Path,
    directory: &Path,
    requested_file_name: &str,
    config: &mut AccessConfig,
) -> Result<(), SiteError> {
    let path = directory.join(".htaccess");
    if !path.exists() {
        return Ok(());
    }
    let path = fs::canonicalize(path).map_err(|_| SiteError::InvalidAccessConfiguration)?;
    if !path.starts_with(root) || !path.is_file() {
        return Err(SiteError::InvalidAccessConfiguration);
    }
    let metadata = fs::metadata(&path)?;
    if metadata.len() > MAX_ACCESS_FILE_BYTES {
        return Err(SiteError::InvalidAccessConfiguration);
    }
    let contents = fs::read_to_string(path).map_err(|_| SiteError::InvalidAccessConfiguration)?;
    let inherited_denial = config.denied;
    let mut local_denial = false;
    let mut active_scopes = vec![true];
    for original in contents.lines() {
        let line = original.trim();
        if line.is_empty() || line.starts_with('#') {
            continue;
        }
        let lower = line.to_ascii_lowercase();
        if lower.starts_with("<ifmodule ") {
            let parent = active_scopes.last().copied().unwrap_or(false);
            let module = tag_argument(line).to_ascii_lowercase();
            let enabled = matches!(module.as_str(), "mod_authz_core.c" | "mod_authz_core");
            active_scopes.push(parent && enabled);
            continue;
        }
        if lower.starts_with("</ifmodule") {
            if active_scopes.len() > 1 {
                active_scopes.pop();
            }
            continue;
        }
        if lower.starts_with("<filesmatch ") || lower.starts_with("<files ") {
            let parent = active_scopes.last().copied().unwrap_or(false);
            active_scopes
                .push(parent && file_pattern_matches(&tag_argument(line), requested_file_name));
            continue;
        }
        if lower.starts_with("</filesmatch") || lower.starts_with("</files") {
            if active_scopes.len() > 1 {
                active_scopes.pop();
            }
            continue;
        }
        if line.starts_with('<') || !active_scopes.last().copied().unwrap_or(false) {
            continue;
        }
        let mut pieces = line.splitn(2, char::is_whitespace);
        let name = pieces.next().unwrap_or_default().to_ascii_lowercase();
        let value = pieces.next().unwrap_or_default().trim();
        match name.as_str() {
            "deny" => {
                if value.to_ascii_lowercase().starts_with("from") {
                    local_denial = true;
                }
            }
            "require" => {
                let normalized = value.to_ascii_lowercase();
                if normalized == "all denied" {
                    local_denial = true;
                } else if normalized == "all granted" {
                    // A more-specific matching Files/FilesMatch section may override
                    // a denial from this same .htaccess file. It cannot weaken a
                    // denial inherited from a parent directory.
                    local_denial = false;
                } else if normalized == "valid-user" {
                    config.auth_seen = true;
                    config.user_requirement = Some(UserRequirement::Any);
                } else if normalized.starts_with("user ") {
                    let users = value[5..]
                        .split_whitespace()
                        .filter(|user| !user.is_empty() && user.len() <= 128)
                        .map(str::to_owned)
                        .collect::<Vec<_>>();
                    if users.is_empty() {
                        return Err(SiteError::InvalidAccessConfiguration);
                    }
                    config.auth_seen = true;
                    config.user_requirement = Some(UserRequirement::Named(users));
                } else {
                    // IP, host, group and expression providers do not have safe
                    // equivalents in Freedom's authenticated peer transport.
                    local_denial = true;
                }
            }
            "authtype" => {
                config.auth_seen = true;
                config.auth_type_basic = value.eq_ignore_ascii_case("basic");
                if !config.auth_type_basic {
                    local_denial = true;
                }
            }
            "authname" => {
                config.auth_seen = true;
                let realm = unquote(value);
                if realm.is_empty() || realm.len() > 120 || realm.chars().any(char::is_control) {
                    return Err(SiteError::InvalidAccessConfiguration);
                }
                config.realm = Some(realm.to_owned());
            }
            "authuserfile" => {
                config.auth_seen = true;
                config.user_file = Some(resolve_user_file(root, directory, unquote(value))?);
            }
            _ => {}
        }
    }
    config.denied = inherited_denial || local_denial;
    Ok(())
}

fn tag_argument(line: &str) -> String {
    let line = line.trim().trim_end_matches('>').trim();
    let argument = line
        .find(char::is_whitespace)
        .map(|index| line[index..].trim())
        .unwrap_or_default();
    argument
        .strip_prefix('"')
        .and_then(|value| value.strip_suffix('"'))
        .or_else(|| {
            argument
                .strip_prefix('\'')
                .and_then(|value| value.strip_suffix('\''))
        })
        .unwrap_or(argument)
        .to_owned()
}

/// Match the common Apache FilesMatch forms used by legacy PHP sites without
/// turning the Freedom host into a general-purpose Apache configuration parser.
fn file_pattern_matches(pattern: &str, file_name: &str) -> bool {
    let pattern = pattern.trim().to_ascii_lowercase();
    let file_name = file_name.to_ascii_lowercase();
    if pattern.starts_with("^\\.") {
        return file_name.starts_with('.');
    }

    let extension = file_name.rsplit_once('.').map(|(_, value)| value);
    let group = pattern
        .find("(?i:")
        .and_then(|start| {
            let rest = &pattern[start + 4..];
            rest.find(')').map(|end| &rest[..end])
        })
        .or_else(|| {
            let start = pattern.find('(')?;
            let rest = &pattern[start + 1..];
            rest.find(')').map(|end| &rest[..end])
        });
    if let (Some(extension), Some(group)) = (extension, group) {
        return group
            .split('|')
            .any(|candidate| optional_suffix_matches(candidate, extension));
    }

    if let (Some(extension), Some(start)) = (extension, pattern.find("\\.")) {
        let literal = pattern[start + 2..]
            .trim_end_matches('$')
            .trim_matches(|character: char| !character.is_ascii_alphanumeric());
        if !literal.is_empty() {
            return optional_suffix_matches(literal, extension);
        }
    }
    false
}

fn optional_suffix_matches(pattern: &str, value: &str) -> bool {
    let pattern = pattern.trim().trim_matches('^').trim_matches('$');
    if let Some(optional) = pattern.strip_suffix('?')
        && let Some((last, prefix)) = optional.chars().last().map(|last| {
            let prefix = &optional[..optional.len() - last.len_utf8()];
            (last, prefix)
        })
    {
        return value == prefix || value == format!("{prefix}{last}");
    }
    value == pattern
}

fn resolve_user_file(
    root: &Path,
    directory: &Path,
    configured: &str,
) -> Result<PathBuf, SiteError> {
    if configured.is_empty() || configured.len() > 512 || configured.contains('\0') {
        return Err(SiteError::InvalidAccessConfiguration);
    }
    let configured_path = Path::new(configured);
    let mut candidates = Vec::new();
    if configured_path.is_absolute()
        || configured_path.has_root()
        || configured.starts_with('/')
        || configured.starts_with('\\')
    {
        candidates.push(configured_path.to_path_buf());
        if let Some(name) = configured_path.file_name() {
            candidates.push(directory.join(name));
            candidates.push(root.join(name));
        }
    } else {
        candidates.push(directory.join(configured_path));
        candidates.push(root.join(configured_path));
    }
    for candidate in candidates {
        let Ok(canonical) = fs::canonicalize(candidate) else {
            continue;
        };
        if canonical.starts_with(root) && canonical.is_file() {
            return Ok(canonical);
        }
    }
    Err(SiteError::InvalidAccessConfiguration)
}

fn unquote(value: &str) -> &str {
    let value = value.trim();
    if value.len() >= 2
        && ((value.starts_with('"') && value.ends_with('"'))
            || (value.starts_with('\'') && value.ends_with('\'')))
    {
        &value[1..value.len() - 1]
    } else {
        value
    }
}

fn sensitive_public_path(path: &Path) -> bool {
    path.components().any(|component| {
        let Component::Normal(name) = component else {
            return true;
        };
        let name = name.to_string_lossy();
        if name.starts_with('.') {
            return true;
        }
        Path::new(name.as_ref())
            .extension()
            .and_then(|extension| extension.to_str())
            .is_some_and(|extension| {
                matches!(
                    extension.to_ascii_lowercase().as_str(),
                    "db" | "sqlite"
                        | "sqlite3"
                        | "sql"
                        | "env"
                        | "ini"
                        | "log"
                        | "bak"
                        | "backup"
                        | "old"
                        | "orig"
                        | "swp"
                )
            })
    })
}

fn verify_password(password: &str, hash: &str) -> bool {
    if hash.starts_with("$2a$") || hash.starts_with("$2b$") || hash.starts_with("$2y$") {
        let cost = hash
            .split('$')
            .nth(2)
            .and_then(|value| value.parse::<u32>().ok());
        if !cost.is_some_and(|cost| (4..=14).contains(&cost)) {
            return false;
        }
        return bcrypt::verify(password, hash).unwrap_or(false);
    }
    if let Some(expected) = hash.strip_prefix("{SHA}") {
        let actual = STANDARD.encode(Sha1::digest(password.as_bytes()));
        return constant_time_equal(actual.as_bytes(), expected.as_bytes());
    }
    if hash.starts_with("$apr1$") {
        return apr1_hash(password.as_bytes(), hash)
            .is_some_and(|actual| constant_time_equal(actual.as_bytes(), hash.as_bytes()));
    }
    // Apache permits plaintext htpasswd records on Windows. They are weak, but
    // accepting an existing record is safer for compatibility than silently
    // exposing a directory after failing to understand its authentication file.
    !hash.starts_with('$') && constant_time_equal(password.as_bytes(), hash.as_bytes())
}

fn constant_time_equal(left: &[u8], right: &[u8]) -> bool {
    left.len() == right.len() && bool::from(left.ct_eq(right))
}

fn apr1_hash(password: &[u8], encoded: &str) -> Option<String> {
    let mut parts = encoded.split('$');
    if !parts.next()?.is_empty() || parts.next()? != "apr1" {
        return None;
    }
    let salt = parts.next()?;
    if salt.is_empty()
        || salt.len() > 8
        || !salt
            .bytes()
            .all(|byte| byte.is_ascii_alphanumeric() || byte == b'.' || byte == b'/')
    {
        return None;
    }

    let mut initial = Md5::new();
    initial.update(password);
    initial.update(b"$apr1$");
    initial.update(salt.as_bytes());

    let mut alternate = Md5::new();
    alternate.update(password);
    alternate.update(salt.as_bytes());
    alternate.update(password);
    let alternate = alternate.finalize();
    let mut remaining = password.len();
    while remaining > 0 {
        let take = remaining.min(16);
        initial.update(&alternate[..take]);
        remaining -= take;
    }

    let first = password.first().copied().unwrap_or_default();
    let mut length = password.len();
    while length > 0 {
        if length & 1 == 1 {
            initial.update([0]);
        } else {
            initial.update([first]);
        }
        length >>= 1;
    }
    let mut digest: [u8; 16] = initial.finalize().into();

    for round in 0..1000 {
        let mut next = Md5::new();
        if round & 1 == 1 {
            next.update(password);
        } else {
            next.update(digest);
        }
        if round % 3 != 0 {
            next.update(salt.as_bytes());
        }
        if round % 7 != 0 {
            next.update(password);
        }
        if round & 1 == 1 {
            next.update(digest);
        } else {
            next.update(password);
        }
        digest = next.finalize().into();
    }

    let mut result = format!("$apr1${salt}$");
    crypt_base64(&mut result, digest[0], digest[6], digest[12], 4);
    crypt_base64(&mut result, digest[1], digest[7], digest[13], 4);
    crypt_base64(&mut result, digest[2], digest[8], digest[14], 4);
    crypt_base64(&mut result, digest[3], digest[9], digest[15], 4);
    crypt_base64(&mut result, digest[4], digest[10], digest[5], 4);
    crypt_base64(&mut result, 0, 0, digest[11], 2);
    Some(result)
}

fn crypt_base64(output: &mut String, high: u8, middle: u8, low: u8, count: usize) {
    const ALPHABET: &[u8; 64] = b"./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
    let mut value = (u32::from(high) << 16) | (u32::from(middle) << 8) | u32::from(low);
    for _ in 0..count {
        output.push(char::from(ALPHABET[(value & 0x3f) as usize]));
        value >>= 6;
    }
}

pub fn verify_hash(body: &[u8], expected: &str) -> bool {
    hex_digest(body) == expected
}

fn validate_id(site_id: &str) -> Result<(), SiteError> {
    if site_id.is_empty()
        || site_id.len() > 48
        || site_id.starts_with('-')
        || site_id.ends_with('-')
        || !site_id.chars().all(|character| {
            character.is_ascii_lowercase() || character.is_ascii_digit() || character == '-'
        })
    {
        return Err(SiteError::InvalidId);
    }
    Ok(())
}

fn safe_relative_path(request_path: &str) -> Result<PathBuf, SiteError> {
    if request_path.len() > 512 {
        return Err(SiteError::UnsafePath);
    }
    let decoded = percent_decode(request_path)?;
    relative_path_from_decoded(&decoded)
}

fn relative_path_from_decoded(decoded: &str) -> Result<PathBuf, SiteError> {
    if decoded.starts_with('/')
        || decoded.contains('\0')
        || decoded.contains('\\')
        || decoded.contains(':')
    {
        return Err(SiteError::UnsafePath);
    }
    let path = Path::new(&decoded);
    if path.is_absolute()
        || path.components().any(|component| {
            matches!(
                component,
                Component::ParentDir | Component::RootDir | Component::Prefix(_)
            )
        })
    {
        return Err(SiteError::UnsafePath);
    }
    Ok(path.to_path_buf())
}

fn safe_upload_path(request_path: &str) -> Result<PathBuf, SiteError> {
    if request_path.len() > 512 {
        return Err(SiteError::UnsafePath);
    }
    let decoded = percent_decode(request_path)?;
    if decoded
        .split('/')
        .any(|component| component.is_empty() || component == "." || component == "..")
    {
        return Err(SiteError::UnsafePath);
    }
    let path = relative_path_from_decoded(&decoded)?;
    if path.as_os_str().is_empty()
        || path.components().count() > 32
        || path
            .components()
            .any(|component| !matches!(component, Component::Normal(_)))
        || path.components().any(|component| {
            matches!(component, Component::Normal(name) if name.to_string_lossy().starts_with(".freedom-upload-"))
        })
    {
        return Err(SiteError::UnsafePath);
    }
    Ok(path)
}

fn escape_html(value: &str) -> String {
    value
        .replace('&', "&amp;")
        .replace('<', "&lt;")
        .replace('>', "&gt;")
        .replace('"', "&quot;")
        .replace('\'', "&#39;")
}

fn percent_decode(value: &str) -> Result<String, SiteError> {
    let bytes = value.as_bytes();
    let mut output = Vec::with_capacity(bytes.len());
    let mut index = 0;
    while index < bytes.len() {
        if bytes[index] == b'%' {
            if index + 2 >= bytes.len() {
                return Err(SiteError::UnsafePath);
            }
            let high = hex_value(bytes[index + 1]).ok_or(SiteError::UnsafePath)?;
            let low = hex_value(bytes[index + 2]).ok_or(SiteError::UnsafePath)?;
            output.push((high << 4) | low);
            index += 3;
        } else {
            output.push(bytes[index]);
            index += 1;
        }
    }
    String::from_utf8(output).map_err(|_| SiteError::UnsafePath)
}

fn hex_value(value: u8) -> Option<u8> {
    match value {
        b'0'..=b'9' => Some(value - b'0'),
        b'a'..=b'f' => Some(value - b'a' + 10),
        b'A'..=b'F' => Some(value - b'A' + 10),
        _ => None,
    }
}

fn hex_digest(body: &[u8]) -> String {
    Sha256::digest(body)
        .iter()
        .map(|byte| format!("{byte:02x}"))
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn serves_index_and_hashes_content() {
        let dir = tempfile::tempdir().unwrap();
        fs::write(dir.path().join("index.html"), b"<h1>Freedom</h1>").unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();
        let file = registry.read("home", "").unwrap();
        assert_eq!(file.mime_type, "text/html");
        assert!(verify_hash(&file.body, &file.sha256));
    }

    #[test]
    fn serves_large_static_media_as_bounded_byte_ranges() {
        let dir = tempfile::tempdir().unwrap();
        let media_path = dir.path().join("movie.webm");
        let mut media = File::create(&media_path).unwrap();
        media.set_len(12 * 1024 * 1024).unwrap();
        media.seek(SeekFrom::Start(5 * 1024 * 1024)).unwrap();
        media.write_all(b"FREEDOM").unwrap();
        drop(media);
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();

        let response = registry
            .read_for_request("home", "movie.webm", Some("bytes=5242880-"), false)
            .unwrap();
        assert_eq!(response.status_code, 206);
        assert_eq!(response.mime_type, "video/webm");
        assert_eq!(response.body.len(), MAX_SITE_RANGE_BYTES as usize);
        assert_eq!(&response.body[..7], b"FREEDOM");
        assert!(response.headers.iter().any(|header| {
            header.name == "content-range" && header.value == "bytes 5242880-9437183/12582912"
        }));

        let unsatisfied = registry
            .read_for_request("home", "movie.webm", Some("bytes=12582912-"), false)
            .unwrap();
        assert_eq!(unsatisfied.status_code, 416);
        assert!(unsatisfied.headers.iter().any(|header| {
            header.name == "content-range" && header.value == "bytes */12582912"
        }));
    }

    #[test]
    fn php_index_takes_precedence_and_is_never_returned_as_source() {
        let dir = tempfile::tempdir().unwrap();
        fs::write(dir.path().join("index.html"), b"static fallback").unwrap();
        fs::write(dir.path().join("index.php"), b"<?php echo 'secret';").unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();
        let resolved = registry.resolve("home", "").unwrap();
        assert!(resolved.is_php);
        assert!(matches!(
            registry.read("home", ""),
            Err(SiteError::PhpRuntimeRequired)
        ));
    }

    #[test]
    fn rejects_traversal_even_when_encoded() {
        let dir = tempfile::tempdir().unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();
        assert!(matches!(
            registry.read("home", "../secret"),
            Err(SiteError::UnsafePath)
        ));
        assert!(matches!(
            registry.read("home", "%2e%2e/secret"),
            Err(SiteError::UnsafePath)
        ));
        assert!(matches!(
            registry.read("home", "C:%5csecret"),
            Err(SiteError::UnsafePath)
        ));
    }

    #[test]
    fn disabled_site_is_not_served() {
        let dir = tempfile::tempdir().unwrap();
        fs::write(dir.path().join("index.html"), "hello").unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();
        registry.set_enabled("home", false).unwrap();
        assert!(matches!(
            registry.read("home", ""),
            Err(SiteError::Unavailable)
        ));
    }

    #[test]
    fn managed_sites_create_htdocs_and_accept_nested_uploads() {
        let dir = tempfile::tempdir().unwrap();
        let htdocs = dir.path().join("htdocs");
        let mut registry = SiteRegistry::new(Vec::new());
        let first = registry
            .create_managed("first", "First & Friends", &htdocs)
            .unwrap();
        let second = registry
            .create_managed("second", "Second", &htdocs)
            .unwrap();
        assert!(Path::new(&first.root).join("index.html").is_file());
        assert!(Path::new(&second.root).join("index.html").is_file());

        let uploaded = registry
            .write_file("first", "assets%2Fsite.css", b"body{color:green}")
            .unwrap();
        assert_eq!(uploaded.path, "assets/site.css");
        assert_eq!(
            registry.read("first", "assets/site.css").unwrap().body,
            b"body{color:green}"
        );
        registry
            .write_file("first", "assets/site.css", b"body{color:blue}")
            .unwrap();
        assert_eq!(
            registry.read("first", "assets/site.css").unwrap().body,
            b"body{color:blue}"
        );
    }

    #[test]
    fn copied_htdocs_directories_are_discovered_as_enabled_sites() {
        let dir = tempfile::tempdir().unwrap();
        let htdocs = dir.path().join("htdocs");
        fs::create_dir_all(htdocs.join("circle")).unwrap();
        fs::create_dir_all(htdocs.join("not_a_site")).unwrap();
        fs::write(htdocs.join("circle/index.html"), "Circle").unwrap();
        let mut registry = SiteRegistry::new(Vec::new());

        let discovered = registry.discover_managed(&htdocs).unwrap();

        assert_eq!(discovered.len(), 1);
        assert_eq!(discovered[0].site_id, "circle");
        assert!(discovered[0].enabled);
        assert_eq!(registry.read("circle", "").unwrap().body, b"Circle");
    }

    #[test]
    fn uploads_reject_unsafe_paths_and_oversized_files() {
        let dir = tempfile::tempdir().unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry
            .create_managed("home", "Home", &dir.path().join("htdocs"))
            .unwrap();
        for path in ["../outside", "/absolute", "C:%5coutside", "a/./b", ""] {
            assert!(matches!(
                registry.write_file("home", path, b"bad"),
                Err(SiteError::UnsafePath)
            ));
        }
        assert!(matches!(
            registry.write_file(
                "home",
                "large.bin",
                &vec![0; MAX_SITE_FILE_BYTES as usize + 1]
            ),
            Err(SiteError::TooLarge)
        ));
    }

    #[test]
    fn htaccess_denial_and_sensitive_files_are_never_public() {
        let dir = tempfile::tempdir().unwrap();
        let data = dir.path().join("data");
        fs::create_dir(&data).unwrap();
        fs::write(data.join(".htaccess"), "Order allow,deny\nDeny from all\n").unwrap();
        fs::write(data.join("notes.txt"), "private").unwrap();
        fs::write(dir.path().join("site.sqlite"), "private").unwrap();
        fs::write(dir.path().join(".env"), "SECRET=value").unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();

        for path in ["data/notes.txt", "data/.htaccess", "site.sqlite", ".env"] {
            assert_eq!(
                registry.access_policy("home", path).unwrap(),
                AccessPolicy::Denied,
                "{path} must not be public"
            );
        }
    }

    #[test]
    fn filesmatch_rules_apply_only_to_matching_files() {
        let dir = tempfile::tempdir().unwrap();
        let uploads = dir.path().join("uploads");
        fs::create_dir(&uploads).unwrap();
        fs::write(dir.path().join("index.html"), "public").unwrap();
        fs::write(
            dir.path().join(".htaccess"),
            "<FilesMatch \"^\\\\.\">\n  Require all denied\n</FilesMatch>\n",
        )
        .unwrap();
        fs::write(
            uploads.join(".htaccess"),
            "<IfModule mod_authz_core.c>\nRequire all denied\n<FilesMatch \"\\\\.(jpg|png|woff2?)$\">\nRequire all granted\n</FilesMatch>\n</IfModule>\n<IfModule !mod_authz_core.c>\nDeny from all\n</IfModule>\n",
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();

        assert_eq!(
            registry.access_policy("home", "index.html").unwrap(),
            AccessPolicy::Public
        );
        assert_eq!(
            registry.access_policy("home", "uploads/photo.png").unwrap(),
            AccessPolicy::Public
        );
        assert_eq!(
            registry
                .access_policy("home", "uploads/font.woff2")
                .unwrap(),
            AccessPolicy::Public
        );
        assert_eq!(
            registry.access_policy("home", "uploads/shell.php").unwrap(),
            AccessPolicy::Denied
        );
    }

    #[test]
    fn htaccess_basic_auth_inherits_and_uses_existing_htpasswd() {
        let dir = tempfile::tempdir().unwrap();
        let admin = dir.path().join("admin");
        fs::create_dir(&admin).unwrap();
        fs::write(admin.join("index.php"), "<?php echo 'admin';").unwrap();
        fs::write(
            admin.join(".htaccess"),
            "AuthType Basic\nAuthName \"Site Admin\"\nAuthUserFile /old/server/path/.htpasswd\nRequire valid-user\n",
        )
        .unwrap();
        fs::write(
            admin.join(".htpasswd"),
            "user1:$apr1$gxNb79DX$6wi9QaGNM5TA0kBKiC4710\n",
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();

        let policy = registry.access_policy("home", "admin/index.php").unwrap();
        assert!(matches!(
            &policy,
            AccessPolicy::Basic { realm, .. } if realm == "Site Admin"
        ));
        assert!(authorize_basic(&policy, "user1", "mickey5").unwrap());
        assert!(!authorize_basic(&policy, "user1", "wrong").unwrap());
        assert_eq!(
            registry.access_policy("home", "admin/.htpasswd").unwrap(),
            AccessPolicy::Denied
        );
    }

    #[test]
    fn parses_basic_credentials_and_common_apache_hashes() {
        let encoded = STANDARD.encode("admin:correct horse battery staple");
        assert_eq!(
            basic_credentials(Some(&format!("Basic {encoded}"))),
            Some((
                "admin".to_owned(),
                "correct horse battery staple".to_owned()
            ))
        );
        assert_eq!(basic_credentials(Some("Bearer token")), None);

        assert!(verify_password(
            "mickey5",
            "$apr1$gxNb79DX$6wi9QaGNM5TA0kBKiC4710"
        ));
        assert!(verify_password(
            "mickey5",
            "{SHA}D9rQ8iK6feNAniulHNKdr5V38ok="
        ));
        assert!(verify_password(
            "mickey5",
            "$2y$05$fpu.jNd5fPlx3ggfZ2BWR.Wc3/hc7ke7LsIpwZM6/e0B6VniqFRIW"
        ));
        assert!(verify_password("mickey5", "mickey5"));
        assert!(!verify_password("wrong", "mickey5"));
    }

    #[test]
    fn incomplete_or_unsupported_access_rules_fail_closed() {
        let dir = tempfile::tempdir().unwrap();
        fs::write(dir.path().join("index.html"), "public").unwrap();
        fs::write(
            dir.path().join(".htaccess"),
            "AuthType Digest\nRequire valid-user\n",
        )
        .unwrap();
        let mut registry = SiteRegistry::new(Vec::new());
        registry.register("home", "Home", dir.path(), true).unwrap();
        assert_eq!(
            registry.access_policy("home", "index.html").unwrap(),
            AccessPolicy::Denied
        );
    }
}
