use serde::{Deserialize, Serialize};

pub const EXCHANGE_PROTOCOL: &str = "/freedom/exchange/1";
pub const PEER_EXCHANGE_PROTOCOL: &str = "/freedom/peer-exchange/1";
pub const MAIL_PROTOCOL: &str = "/freedom/mail/1";
pub const AUTHORITY_RECORDS_PROTOCOL: &str = "/freedom/authority-records/1";
pub const MAX_MESSAGE_BYTES: usize = 16 * 1024;
pub const MAX_MAIL_SUBJECT_BYTES: usize = 240;
pub const MAX_MAIL_BODY_BYTES: usize = 64 * 1024;
pub const MAX_SITE_REQUEST_BYTES: usize = 128 * 1024 * 1024;
pub const MAX_SITE_RESPONSE_BYTES: usize = 8 * 1024 * 1024;
pub const MAX_SITE_RANGE_BYTES: u64 = 4 * 1024 * 1024;
pub const MAX_PEER_ADVERTISEMENTS: usize = 32;
pub const MAX_AUTHORITY_MANIFEST_BYTES: usize = 1024 * 1024;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SiteHeader {
    pub name: String,
    pub value: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum FreedomRequest {
    Message {
        id: String,
        recipient: String,
        sent_at: i64,
        body: String,
    },
    Site {
        site_id: String,
        path: String,
        #[serde(default = "default_site_method")]
        method: String,
        #[serde(default)]
        query: String,
        #[serde(default)]
        content_type: String,
        #[serde(default)]
        authorization: Option<String>,
        #[serde(default)]
        headers: Vec<SiteHeader>,
        #[serde(default)]
        body: Vec<u8>,
    },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum FreedomResponse {
    MessageAck {
        id: String,
        accepted: bool,
        reason: Option<String>,
    },
    Site {
        found: bool,
        #[serde(default = "default_site_status")]
        status_code: u16,
        mime_type: String,
        body: Vec<u8>,
        sha256: String,
        #[serde(default)]
        www_authenticate: Option<String>,
        #[serde(default)]
        headers: Vec<SiteHeader>,
        error: Option<String>,
    },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum MailRequest {
    Deliver {
        id: String,
        sender: String,
        recipient: String,
        sent_at: i64,
        subject: String,
        body: String,
    },
}

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum MailResponse {
    DeliveryAck {
        id: String,
        accepted: bool,
        reason: Option<String>,
    },
}

fn default_site_method() -> String {
    "GET".to_owned()
}

const fn default_site_status() -> u16 {
    200
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PeerExchangeRequest {
    pub limit: u16,
    pub requester_name: String,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PeerAdvertisement {
    pub peer_id: String,
    pub address: String,
    pub display_name: Option<String>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct PeerExchangeResponse {
    pub responder_name: String,
    pub peers: Vec<PeerAdvertisement>,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AuthorityRecordsRequest {
    pub after_sequence: u64,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct AuthorityRecordsResponse {
    pub sequence: u64,
    pub manifest_json: Option<Vec<u8>>,
}
