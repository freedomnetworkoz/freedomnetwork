use std::{fs, io, path::Path};

use libp2p::{PeerId, identity::Keypair};
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use thiserror::Error;
use zeroize::Zeroize;

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct IdentityProfile {
    pub display_name: String,
}

#[derive(Clone)]
pub struct FreedomIdentity {
    keypair: Keypair,
    profile: IdentityProfile,
    fingerprint: String,
}

#[derive(Debug, Error)]
pub enum IdentityError {
    #[error("identity I/O failed: {0}")]
    Io(#[from] io::Error),
    #[error("identity data is invalid: {0}")]
    Invalid(String),
    #[error("Windows identity protection failed: {0}")]
    Protection(String),
}

impl FreedomIdentity {
    pub fn load_or_create(data_dir: &Path, requested_name: &str) -> Result<Self, IdentityError> {
        fs::create_dir_all(data_dir)?;
        let key_path = data_dir.join("identity.key");
        let profile_path = data_dir.join("profile.json");
        let profile_backup = profile_path.with_extension("bak");
        if !profile_path.exists() && profile_backup.exists() {
            fs::rename(&profile_backup, &profile_path)?;
        }

        let keypair = if key_path.exists() {
            let encrypted = fs::read(&key_path)?;
            let mut plain = unprotect(&encrypted)?;
            let result = Keypair::from_protobuf_encoding(&plain)
                .map_err(|error| IdentityError::Invalid(error.to_string()));
            plain.zeroize();
            result?
        } else {
            let keypair = Keypair::generate_ed25519();
            let mut plain = keypair
                .to_protobuf_encoding()
                .map_err(|error| IdentityError::Invalid(error.to_string()))?;
            let encrypted = protect(&plain)?;
            plain.zeroize();
            atomic_write(&key_path, &encrypted)?;
            keypair
        };

        let profile = if profile_path.exists() {
            serde_json::from_slice::<IdentityProfile>(&fs::read(&profile_path)?)
                .map_err(|error| IdentityError::Invalid(error.to_string()))?
        } else {
            let display_name = sanitize_display_name(requested_name)?;
            let profile = IdentityProfile { display_name };
            let encoded = serde_json::to_vec_pretty(&profile)
                .map_err(|error| IdentityError::Invalid(error.to_string()))?;
            atomic_write(&profile_path, &encoded)?;
            profile
        };

        let peer_id = keypair.public().to_peer_id();
        Ok(Self {
            keypair,
            profile,
            fingerprint: fingerprint_for_peer(&peer_id),
        })
    }

    pub fn keypair(&self) -> &Keypair {
        &self.keypair
    }

    pub fn peer_id(&self) -> PeerId {
        self.keypair.public().to_peer_id()
    }

    pub fn display_name(&self) -> &str {
        &self.profile.display_name
    }

    pub fn fingerprint(&self) -> &str {
        &self.fingerprint
    }

    pub fn short_id(&self) -> &str {
        &self.fingerprint[..3]
    }

    pub fn update_display_name(data_dir: &Path, value: &str) -> Result<String, IdentityError> {
        let display_name = sanitize_display_name(value)?;
        let encoded = serde_json::to_vec_pretty(&IdentityProfile {
            display_name: display_name.clone(),
        })
        .map_err(|error| IdentityError::Invalid(error.to_string()))?;
        atomic_write(&data_dir.join("profile.json"), &encoded)?;
        Ok(display_name)
    }
}

pub fn fingerprint_for_peer(peer_id: &PeerId) -> String {
    let digest = Sha256::digest(peer_id.to_bytes());
    let compact = base32(&digest)[..15].to_owned();
    compact
        .as_bytes()
        .chunks(3)
        .map(|chunk| String::from_utf8_lossy(chunk))
        .collect::<Vec<_>>()
        .join("-")
}

fn sanitize_display_name(value: &str) -> Result<String, IdentityError> {
    let value = value.trim();
    if value.is_empty() || value.chars().count() > 64 || value.chars().any(char::is_control) {
        return Err(IdentityError::Invalid(
            "display name must contain 1-64 printable characters".into(),
        ));
    }
    Ok(value.to_owned())
}

fn base32(bytes: &[u8]) -> String {
    const ALPHABET: &[u8; 32] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
    let mut output = String::new();
    let mut buffer = 0_u32;
    let mut bits = 0_u8;
    for byte in bytes {
        buffer = (buffer << 8) | u32::from(*byte);
        bits += 8;
        while bits >= 5 {
            bits -= 5;
            output.push(ALPHABET[((buffer >> bits) & 31) as usize] as char);
        }
    }
    if bits > 0 {
        output.push(ALPHABET[((buffer << (5 - bits)) & 31) as usize] as char);
    }
    output
}

fn atomic_write(path: &Path, bytes: &[u8]) -> io::Result<()> {
    let temporary = path.with_extension("tmp");
    fs::write(&temporary, bytes)?;
    if !path.exists() {
        return fs::rename(temporary, path);
    }

    let backup = path.with_extension("bak");
    if backup.exists() {
        fs::remove_file(&backup)?;
    }
    fs::rename(path, &backup)?;
    match fs::rename(&temporary, path) {
        Ok(()) => {
            fs::remove_file(backup)?;
            Ok(())
        }
        Err(error) => {
            let _ = fs::rename(backup, path);
            let _ = fs::remove_file(temporary);
            Err(error)
        }
    }
}

#[cfg(windows)]
fn protect(data: &[u8]) -> Result<Vec<u8>, IdentityError> {
    crypt_data(data, true)
}

#[cfg(windows)]
fn unprotect(data: &[u8]) -> Result<Vec<u8>, IdentityError> {
    crypt_data(data, false)
}

#[cfg(windows)]
fn crypt_data(data: &[u8], encrypt: bool) -> Result<Vec<u8>, IdentityError> {
    use std::{ptr, slice};
    use windows_sys::Win32::{
        Foundation::LocalFree,
        Security::Cryptography::{
            CRYPT_INTEGER_BLOB, CRYPTPROTECT_UI_FORBIDDEN, CryptProtectData, CryptUnprotectData,
        },
    };

    let input_len = u32::try_from(data.len())
        .map_err(|_| IdentityError::Protection("identity is too large".into()))?;
    let input = CRYPT_INTEGER_BLOB {
        cbData: input_len,
        pbData: data.as_ptr().cast_mut(),
    };
    let mut output = CRYPT_INTEGER_BLOB {
        cbData: 0,
        pbData: ptr::null_mut(),
    };

    let success = unsafe {
        if encrypt {
            CryptProtectData(
                &input,
                ptr::null(),
                ptr::null(),
                ptr::null_mut(),
                ptr::null(),
                CRYPTPROTECT_UI_FORBIDDEN,
                &mut output,
            )
        } else {
            CryptUnprotectData(
                &input,
                ptr::null_mut(),
                ptr::null(),
                ptr::null_mut(),
                ptr::null(),
                CRYPTPROTECT_UI_FORBIDDEN,
                &mut output,
            )
        }
    };

    if success == 0 || output.pbData.is_null() {
        return Err(IdentityError::Protection(
            io::Error::last_os_error().to_string(),
        ));
    }

    let protected =
        unsafe { slice::from_raw_parts(output.pbData, output.cbData as usize) }.to_vec();
    unsafe {
        LocalFree(output.pbData.cast());
    }
    Ok(protected)
}

#[cfg(not(windows))]
fn protect(data: &[u8]) -> Result<Vec<u8>, IdentityError> {
    Ok(data.to_vec())
}

#[cfg(not(windows))]
fn unprotect(data: &[u8]) -> Result<Vec<u8>, IdentityError> {
    Ok(data.to_vec())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn identity_survives_restart() {
        let dir = tempfile::tempdir().unwrap();
        let first = FreedomIdentity::load_or_create(dir.path(), "Alice").unwrap();
        let second = FreedomIdentity::load_or_create(dir.path(), "Ignored rename").unwrap();
        assert_eq!(first.peer_id(), second.peer_id());
        assert_eq!(first.fingerprint(), second.fingerprint());
        assert_eq!(second.display_name(), "Alice");
        assert_ne!(
            fs::read(dir.path().join("identity.key")).unwrap(),
            first.keypair().to_protobuf_encoding().unwrap()
        );
    }

    #[test]
    fn fingerprint_has_human_grouping() {
        let peer = Keypair::generate_ed25519().public().to_peer_id();
        let fingerprint = fingerprint_for_peer(&peer);
        assert_eq!(fingerprint.len(), 19);
        assert_eq!(fingerprint.matches('-').count(), 4);
    }

    #[test]
    fn display_name_can_be_updated_without_changing_identity() {
        let dir = tempfile::tempdir().unwrap();
        let first = FreedomIdentity::load_or_create(dir.path(), "Alice").unwrap();
        FreedomIdentity::update_display_name(dir.path(), "  Alice Cooper  ").unwrap();
        let second = FreedomIdentity::load_or_create(dir.path(), "ignored").unwrap();
        assert_eq!(first.peer_id(), second.peer_id());
        assert_eq!(second.display_name(), "Alice Cooper");
    }
}
