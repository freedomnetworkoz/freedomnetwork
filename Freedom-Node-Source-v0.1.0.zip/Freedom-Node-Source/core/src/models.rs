use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct PeerRecord {
    pub peer_id: String,
    pub display_name: Option<String>,
    pub fingerprint: String,
    pub address: String,
    pub last_seen: i64,
    pub connected: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct MessageRecord {
    pub id: String,
    pub direction: String,
    pub peer_id: String,
    pub timestamp: i64,
    pub body: String,
    pub state: String,
    pub read: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct SiteConfig {
    pub site_id: String,
    pub name: String,
    pub root: String,
    pub enabled: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct ContactRecord {
    pub peer_id: String,
    pub alias: Option<String>,
    pub trust_state: String,
    pub muted: bool,
    pub created_at: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct NameRecord {
    pub hostname: String,
    pub record_type: String,
    pub peer_id: Option<String>,
    pub site_id: Option<String>,
    pub path: String,
    pub official: bool,
    pub active: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct AuthorityAuditRecord {
    pub event_id: String,
    pub sequence: i64,
    pub scope: String,
    pub action: String,
    pub target: String,
    pub payload_json: String,
    pub signer_peer_id: String,
    pub issued_at: i64,
    pub signature: Vec<u8>,
    pub imported_at: i64,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct MailRecord {
    pub id: String,
    pub direction: String,
    pub peer_id: String,
    pub sender: String,
    pub recipient: String,
    pub timestamp: i64,
    pub subject: String,
    pub body: String,
    pub state: String,
    pub read: bool,
}

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct NodeSnapshot {
    pub application_role: String,
    pub authority_signer: Option<String>,
    pub display_name: String,
    pub peer_id: String,
    pub short_id: String,
    pub fingerprint: String,
    pub htdocs_root: String,
    pub php_available: bool,
    pub listen_addresses: Vec<String>,
    pub internet_mode: String,
    pub nat_status: String,
    pub configured_bootstrap_peers: usize,
    pub configured_relay_peers: usize,
    pub relay_reservations: usize,
    pub dht_peers: usize,
    pub bootstrap_manifest_url: Option<String>,
    pub bootstrap_manifest_status: String,
    pub bootstrap_manifest_last_checked: Option<i64>,
    pub bootstrap_manifest_last_success: Option<i64>,
    pub bootstrap_manifest_peer_count: usize,
    pub bootstrap_manifest_listed: bool,
    pub bootstrap_recovery_checks: u64,
    pub bootstrap_server_status: String,
    pub peers: Vec<PeerRecord>,
    pub messages: Vec<MessageRecord>,
    pub sites: Vec<SiteConfig>,
    pub contacts: Vec<ContactRecord>,
    pub mail_address: String,
    pub mail_messages: Vec<MailRecord>,
    pub names: Vec<NameRecord>,
    pub recent_events: Vec<String>,
}

impl NodeSnapshot {
    pub fn empty(
        display_name: impl Into<String>,
        peer_id: impl Into<String>,
        fingerprint: impl Into<String>,
    ) -> Self {
        let fingerprint = fingerprint.into();
        Self {
            application_role: "node".into(),
            authority_signer: None,
            display_name: display_name.into(),
            peer_id: peer_id.into(),
            short_id: fingerprint.chars().take(3).collect(),
            fingerprint,
            htdocs_root: String::new(),
            php_available: false,
            listen_addresses: Vec::new(),
            internet_mode: "Direct/LAN".into(),
            nat_status: "Unknown".into(),
            configured_bootstrap_peers: 0,
            configured_relay_peers: 0,
            relay_reservations: 0,
            dht_peers: 0,
            bootstrap_manifest_url: None,
            bootstrap_manifest_status: "Not configured".into(),
            bootstrap_manifest_last_checked: None,
            bootstrap_manifest_last_success: None,
            bootstrap_manifest_peer_count: 0,
            bootstrap_manifest_listed: false,
            bootstrap_recovery_checks: 0,
            bootstrap_server_status: "Not enabled".into(),
            peers: Vec::new(),
            messages: Vec::new(),
            sites: Vec::new(),
            contacts: Vec::new(),
            mail_address: String::new(),
            mail_messages: Vec::new(),
            names: Vec::new(),
            recent_events: Vec::new(),
        }
    }
}
