use std::{
    collections::HashSet,
    fs, io,
    path::{Path, PathBuf},
    str::FromStr,
};

#[cfg(feature = "authority")]
use std::collections::BTreeMap;

use base64::{Engine as _, engine::general_purpose::STANDARD};
#[cfg(any(feature = "authority", test))]
use libp2p::identity::Keypair;
use libp2p::{PeerId, identity::PublicKey};
use serde::{Deserialize, Serialize};
use thiserror::Error;

use crate::models::NameRecord;

pub const RESERVED_OFFICIAL_NAMES: [&str; 6] = [
    "freedom.net",
    "mail.freedom.net",
    "ftube.net",
    "circle.net",
    "games.net",
    "news.net",
];

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct AuthorityTrustRoot {
    pub version: u16,
    pub signer_peer_id: String,
    pub public_key: String,
}

#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct SignedNameManifest {
    pub version: u16,
    pub sequence: u64,
    pub issued_at: i64,
    pub signer_peer_id: String,
    pub public_key: String,
    pub records: Vec<NameRecord>,
    pub signature: String,
}

#[cfg(feature = "authority")]
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub struct AuthorityNameAssignments {
    pub version: u16,
    pub records: Vec<NameRecord>,
}

#[derive(Debug, Error)]
pub enum AuthorityManifestError {
    #[error("authority manifest I/O failed: {0}")]
    Io(#[from] io::Error),
    #[error("authority manifest JSON is invalid: {0}")]
    Json(#[from] serde_json::Error),
    #[error("authority signer PeerID is invalid")]
    InvalidSigner,
    #[error("authority public key is invalid")]
    InvalidPublicKey,
    #[error("authority manifest signer does not match its public key")]
    SignerKeyMismatch,
    #[error("authority manifest is not signed by the configured trust root")]
    UntrustedSigner,
    #[error("authority manifest signature is invalid")]
    InvalidSignature,
    #[error("authority manifest contains an invalid official record")]
    InvalidRecord,
    #[error("authority signing failed: {0}")]
    Signing(String),
}

#[derive(Serialize)]
struct ManifestPayload<'a> {
    version: u16,
    sequence: u64,
    issued_at: i64,
    signer_peer_id: &'a str,
    public_key: &'a str,
    records: &'a [NameRecord],
}

impl SignedNameManifest {
    #[cfg(feature = "authority")]
    pub fn sign(
        signer: &Keypair,
        sequence: u64,
        issued_at: i64,
        records: Vec<NameRecord>,
    ) -> Result<Self, AuthorityManifestError> {
        validate_records(&records)?;
        let public_key = STANDARD.encode(signer.public().encode_protobuf());
        let signer_peer_id = signer.public().to_peer_id().to_string();
        let mut manifest = Self {
            version: 1,
            sequence,
            issued_at,
            signer_peer_id,
            public_key,
            records,
            signature: String::new(),
        };
        let payload = manifest.payload()?;
        manifest.signature = STANDARD.encode(
            signer
                .sign(&payload)
                .map_err(|error| AuthorityManifestError::Signing(error.to_string()))?,
        );
        Ok(manifest)
    }

    pub fn verify(
        &self,
        expected_signer: Option<&PeerId>,
    ) -> Result<PeerId, AuthorityManifestError> {
        if self.version != 1 || self.sequence == 0 {
            return Err(AuthorityManifestError::InvalidRecord);
        }
        validate_records(&self.records)?;
        let claimed = PeerId::from_str(&self.signer_peer_id)
            .map_err(|_| AuthorityManifestError::InvalidSigner)?;
        let public_bytes = STANDARD
            .decode(&self.public_key)
            .map_err(|_| AuthorityManifestError::InvalidPublicKey)?;
        let public_key = PublicKey::try_decode_protobuf(&public_bytes)
            .map_err(|_| AuthorityManifestError::InvalidPublicKey)?;
        if public_key.to_peer_id() != claimed {
            return Err(AuthorityManifestError::SignerKeyMismatch);
        }
        if expected_signer.is_some_and(|expected| expected != &claimed) {
            return Err(AuthorityManifestError::UntrustedSigner);
        }
        let signature = STANDARD
            .decode(&self.signature)
            .map_err(|_| AuthorityManifestError::InvalidSignature)?;
        if !public_key.verify(&self.payload()?, &signature) {
            return Err(AuthorityManifestError::InvalidSignature);
        }
        Ok(claimed)
    }

    #[cfg(feature = "authority")]
    pub fn trust_root(&self) -> AuthorityTrustRoot {
        AuthorityTrustRoot {
            version: self.version,
            signer_peer_id: self.signer_peer_id.clone(),
            public_key: self.public_key.clone(),
        }
    }

    fn payload(&self) -> Result<Vec<u8>, AuthorityManifestError> {
        Ok(serde_json::to_vec(&ManifestPayload {
            version: self.version,
            sequence: self.sequence,
            issued_at: self.issued_at,
            signer_peer_id: &self.signer_peer_id,
            public_key: &self.public_key,
            records: &self.records,
        })?)
    }
}

pub fn official_name_records(
    provider_peer: Option<&PeerId>,
    published_sites: &HashSet<String>,
) -> Vec<NameRecord> {
    vec![
        site(provider_peer, published_sites, "freedom.net", "freedom"),
        mail(provider_peer, published_sites),
        site(provider_peer, published_sites, "ftube.net", "ftube"),
        site(provider_peer, published_sites, "circle.net", "circle"),
        site(provider_peer, published_sites, "games.net", "games"),
        site(provider_peer, published_sites, "news.net", "news"),
    ]
}

pub fn load_verified_manifest(
    path: &Path,
    expected_signer: &PeerId,
) -> Result<SignedNameManifest, AuthorityManifestError> {
    let manifest = serde_json::from_slice::<SignedNameManifest>(&fs::read(path)?)?;
    manifest.verify(Some(expected_signer))?;
    Ok(manifest)
}

pub fn store_verified_manifest_cache(
    path: &Path,
    manifest: &SignedNameManifest,
    expected_signer: &PeerId,
) -> Result<(), AuthorityManifestError> {
    manifest.verify(Some(expected_signer))?;
    atomic_json(path, manifest)
}

#[cfg(feature = "authority")]
pub fn load_authority_name_records(
    authority_dir: &Path,
) -> Result<Vec<NameRecord>, AuthorityManifestError> {
    let path = authority_dir.join("name-records.json");
    if !path.exists() {
        atomic_json(
            &path,
            &AuthorityNameAssignments {
                version: 1,
                records: Vec::new(),
            },
        )?;
        return Ok(Vec::new());
    }
    let assignments = serde_json::from_slice::<AuthorityNameAssignments>(&fs::read(path)?)?;
    if assignments.version != 1 {
        return Err(AuthorityManifestError::InvalidRecord);
    }
    validate_additional_records(&assignments.records)?;
    Ok(assignments.records)
}

#[cfg(feature = "authority")]
pub fn store_authority_name_records(
    authority_dir: &Path,
    records: Vec<NameRecord>,
) -> Result<(), AuthorityManifestError> {
    validate_additional_records(&records)?;
    atomic_json(
        &authority_dir.join("name-records.json"),
        &AuthorityNameAssignments {
            version: 1,
            records,
        },
    )
}

#[cfg(feature = "authority")]
pub fn merge_authority_name_records(
    baseline: Vec<NameRecord>,
    assignments: Vec<NameRecord>,
) -> Result<Vec<NameRecord>, AuthorityManifestError> {
    validate_additional_records(&assignments)?;
    let mut merged = baseline
        .into_iter()
        .map(|record| (record.hostname.clone(), record))
        .collect::<BTreeMap<_, _>>();
    for record in assignments {
        merged.insert(record.hostname.clone(), record);
    }
    let records = merged.into_values().collect::<Vec<_>>();
    validate_records(&records)?;
    Ok(records)
}

#[cfg(feature = "authority")]
pub fn store_authority_manifest(
    authority_dir: &Path,
    signer: &Keypair,
    issued_at: i64,
    records: Vec<NameRecord>,
) -> Result<SignedNameManifest, AuthorityManifestError> {
    fs::create_dir_all(authority_dir)?;
    let manifest_path = authority_dir.join("name-manifest.json");
    let previous = fs::read(&manifest_path)
        .ok()
        .and_then(|bytes| serde_json::from_slice::<SignedNameManifest>(&bytes).ok())
        .filter(|manifest| manifest.verify(Some(&signer.public().to_peer_id())).is_ok());
    if let Some(manifest) = previous
        .as_ref()
        .filter(|manifest| manifest.records == records)
    {
        return Ok(manifest.clone());
    }
    let sequence = previous
        .as_ref()
        .map(|manifest| manifest.sequence.saturating_add(1))
        .unwrap_or(1);
    let manifest = SignedNameManifest::sign(signer, sequence, issued_at, records)?;
    atomic_json(&manifest_path, &manifest)?;
    atomic_json(
        &authority_dir.join("trust-root.json"),
        &manifest.trust_root(),
    )?;
    Ok(manifest)
}

pub fn default_manifest_path(executable_directory: &Path) -> PathBuf {
    executable_directory
        .join("config")
        .join("authority-name-manifest.json")
}

fn site(
    provider_peer: Option<&PeerId>,
    published_sites: &HashSet<String>,
    hostname: &str,
    site_id: &str,
) -> NameRecord {
    let active = provider_peer.is_some() && published_sites.contains(site_id);
    NameRecord {
        hostname: hostname.to_owned(),
        record_type: "site".into(),
        peer_id: active.then(|| provider_peer.expect("active provider").to_string()),
        site_id: Some(site_id.to_owned()),
        path: "/".into(),
        official: true,
        active,
    }
}

fn mail(provider_peer: Option<&PeerId>, published_sites: &HashSet<String>) -> NameRecord {
    let active = provider_peer.is_some() && published_sites.contains("freedom");
    NameRecord {
        hostname: "mail.freedom.net".into(),
        record_type: "mail".into(),
        peer_id: active.then(|| provider_peer.expect("active provider").to_string()),
        site_id: Some("freedom".into()),
        path: "/mail/".into(),
        official: true,
        active,
    }
}

fn validate_records(records: &[NameRecord]) -> Result<(), AuthorityManifestError> {
    if records.len() < RESERVED_OFFICIAL_NAMES.len() || records.len() > 1024 {
        return Err(AuthorityManifestError::InvalidRecord);
    }
    validate_additional_records(records)?;
    for hostname in RESERVED_OFFICIAL_NAMES {
        if records
            .iter()
            .filter(|record| record.hostname == hostname)
            .count()
            != 1
        {
            return Err(AuthorityManifestError::InvalidRecord);
        }
    }
    Ok(())
}

fn validate_additional_records(records: &[NameRecord]) -> Result<(), AuthorityManifestError> {
    let mut seen = HashSet::new();
    for record in records {
        if !seen.insert(record.hostname.as_str())
            || !valid_official_hostname(&record.hostname)
            || !record.official
            || !matches!(record.record_type.as_str(), "site" | "mail")
            || record.path.is_empty()
            || !record.path.starts_with('/')
            || record.path.len() > 512
            || record.path.contains('\0')
            || record.path.split('/').any(|part| part == "..")
            || record.site_id.as_deref().is_none_or(|site| {
                site.is_empty()
                    || site.len() > 64
                    || !site.bytes().all(|byte| {
                        byte.is_ascii_lowercase() || byte.is_ascii_digit() || byte == b'-'
                    })
            })
            || (record.active
                && record
                    .peer_id
                    .as_deref()
                    .is_none_or(|peer| PeerId::from_str(peer).is_err()))
            || (!record.active && record.peer_id.is_some())
        {
            return Err(AuthorityManifestError::InvalidRecord);
        }
    }
    Ok(())
}

fn valid_official_hostname(hostname: &str) -> bool {
    hostname.len() <= 253
        && hostname.ends_with(".net")
        && hostname.bytes().all(|byte| {
            byte.is_ascii_lowercase() || byte.is_ascii_digit() || matches!(byte, b'.' | b'-')
        })
        && hostname.split('.').all(|label| {
            !label.is_empty()
                && label.len() <= 63
                && !label.starts_with('-')
                && !label.ends_with('-')
        })
}

fn atomic_json(path: &Path, value: &impl Serialize) -> Result<(), AuthorityManifestError> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let temporary = path.with_extension("tmp");
    let encoded = serde_json::to_vec_pretty(value)?;
    fs::write(&temporary, encoded)?;
    if path.exists() {
        fs::remove_file(path)?;
    }
    fs::rename(temporary, path)?;
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reserved_names_are_inactive_without_an_authority_provider() {
        let records = official_name_records(None, &HashSet::new());
        assert_eq!(records.len(), 6);
        assert!(
            records
                .iter()
                .all(|record| !record.active && record.peer_id.is_none())
        );
    }

    #[test]
    fn existing_sites_map_to_the_selected_freedom_peer() {
        let peer = Keypair::generate_ed25519().public().to_peer_id();
        let published = HashSet::from(["freedom".to_owned(), "games".to_owned()]);
        let records = official_name_records(Some(&peer), &published);
        assert!(
            records
                .iter()
                .find(|record| record.hostname == "freedom.net")
                .is_some_and(
                    |record| record.active && record.peer_id.as_deref() == Some(&peer.to_string())
                )
        );
        assert!(
            records
                .iter()
                .find(|record| record.hostname == "mail.freedom.net")
                .is_some_and(|record| record.active && record.path == "/mail/")
        );
        assert!(
            records
                .iter()
                .find(|record| record.hostname == "games.net")
                .is_some_and(|record| record.active)
        );
        assert!(
            records
                .iter()
                .find(|record| record.hostname == "news.net")
                .is_some_and(|record| !record.active)
        );
    }

    #[cfg(feature = "authority")]
    #[test]
    fn signed_registry_accepts_additional_official_names() {
        let signer = Keypair::generate_ed25519();
        let provider = Keypair::generate_ed25519().public().to_peer_id();
        let records = merge_authority_name_records(
            official_name_records(None, &HashSet::new()),
            vec![NameRecord {
                hostname: "freecode.net".into(),
                record_type: "site".into(),
                peer_id: Some(provider.to_string()),
                site_id: Some("freecode".into()),
                path: "/".into(),
                official: true,
                active: true,
            }],
        )
        .unwrap();
        assert_eq!(records.len(), 7);
        SignedNameManifest::sign(&signer, 1, 123, records)
            .unwrap()
            .verify(Some(&signer.public().to_peer_id()))
            .unwrap();
    }

    #[cfg(feature = "authority")]
    #[test]
    fn authority_assignments_are_persisted_and_validated() {
        let directory = tempfile::tempdir().unwrap();
        let provider = Keypair::generate_ed25519().public().to_peer_id();
        let record = NameRecord {
            hostname: "bob.net".into(),
            record_type: "site".into(),
            peer_id: Some(provider.to_string()),
            site_id: Some("bob".into()),
            path: "/".into(),
            official: true,
            active: true,
        };
        store_authority_name_records(directory.path(), vec![record.clone()]).unwrap();
        assert_eq!(
            load_authority_name_records(directory.path()).unwrap(),
            vec![record]
        );

        let invalid = NameRecord {
            hostname: "not a domain".into(),
            record_type: "site".into(),
            peer_id: Some(provider.to_string()),
            site_id: Some("bob".into()),
            path: "/".into(),
            official: true,
            active: true,
        };
        assert!(store_authority_name_records(directory.path(), vec![invalid]).is_err());
    }

    #[cfg(feature = "authority")]
    #[test]
    fn signed_manifests_reject_tampering_and_untrusted_signers() {
        let signer = Keypair::generate_ed25519();
        let provider = Keypair::generate_ed25519().public().to_peer_id();
        let records =
            official_name_records(Some(&provider), &HashSet::from(["freedom".to_owned()]));
        let manifest = SignedNameManifest::sign(&signer, 1, 123, records).unwrap();
        assert_eq!(
            manifest
                .verify(Some(&signer.public().to_peer_id()))
                .unwrap(),
            signer.public().to_peer_id()
        );

        let stranger = Keypair::generate_ed25519().public().to_peer_id();
        assert!(matches!(
            manifest.verify(Some(&stranger)),
            Err(AuthorityManifestError::UntrustedSigner)
        ));

        let mut tampered = manifest;
        tampered.records[0].path = "/changed/".into();
        assert!(matches!(
            tampered.verify(Some(&signer.public().to_peer_id())),
            Err(AuthorityManifestError::InvalidSignature)
        ));
    }
}
