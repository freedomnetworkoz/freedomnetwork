#![forbid(unsafe_op_in_unsafe_fn)]

// The owner-controlled Authority edition is deliberately not distributed as a
// supported build from this public Node repository. Authority source branches
// remain compile-time isolated so the same protocol types can be verified, but
// enabling the private edition from this repository is an explicit error.
#[cfg(feature = "authority")]
compile_error!("Freedom Authority is not included in the public Node repository");

pub mod address;
pub mod identity;
pub mod internet;
pub mod mail;
pub mod models;
pub mod naming;
pub mod network;
mod php;
pub mod protocol;
pub mod sites;
pub mod storage;

pub use address::{DEFAULT_FREEDOM_PORT, ManualPeer, parse_manual_peer};
pub use identity::{FreedomIdentity, fingerprint_for_peer};
pub use internet::{InternetConfig, InternetEndpoint};
pub use mail::{MailAddressError, mailbox_address, peer_from_mailbox};
pub use models::{
    AuthorityAuditRecord, ContactRecord, MailRecord, MessageRecord, NameRecord, NodeSnapshot,
    PeerRecord, SiteConfig,
};
pub use naming::{
    AuthorityManifestError, AuthorityTrustRoot, RESERVED_OFFICIAL_NAMES, SignedNameManifest,
    default_manifest_path, load_verified_manifest, official_name_records,
    store_verified_manifest_cache,
};
#[cfg(feature = "authority")]
pub use naming::{
    AuthorityNameAssignments, load_authority_name_records, merge_authority_name_records,
    store_authority_manifest, store_authority_name_records,
};
pub use network::{ApplicationRole, NodeConfig, NodeHandle, SiteRequest, spawn_node};
pub use protocol::{
    AUTHORITY_RECORDS_PROTOCOL, AuthorityRecordsRequest, AuthorityRecordsResponse,
    MAX_SITE_RANGE_BYTES, MAX_SITE_REQUEST_BYTES, MAX_SITE_RESPONSE_BYTES, SiteHeader,
};
pub use sites::{MAX_SITE_FILE_BYTES, UploadedFile};
