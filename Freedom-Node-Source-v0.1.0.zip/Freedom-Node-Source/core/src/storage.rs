use std::{fs, path::Path};

use rusqlite::{Connection, OptionalExtension, params};
use thiserror::Error;

use crate::models::{
    AuthorityAuditRecord, ContactRecord, MailRecord, MessageRecord, PeerRecord, SiteConfig,
};

const MAX_KNOWN_PEERS: i64 = 2_000;

#[derive(Clone, Debug)]
pub(crate) struct ReconnectCandidate {
    pub peer_id: String,
    pub address: String,
}

#[derive(Debug, Error)]
pub enum StorageError {
    #[error("database error: {0}")]
    Database(#[from] rusqlite::Error),
    #[error("database directory error: {0}")]
    Io(#[from] std::io::Error),
    #[error("invalid stored value: {0}")]
    Invalid(String),
}

pub struct Storage {
    connection: Connection,
}

impl Storage {
    pub fn open(path: &Path) -> Result<Self, StorageError> {
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent)?;
        }
        let connection = Connection::open(path)?;
        connection.execute_batch(
            "PRAGMA journal_mode=WAL;
             PRAGMA synchronous=NORMAL;
             PRAGMA foreign_keys=ON;
             CREATE TABLE IF NOT EXISTS peers (
               peer_id TEXT PRIMARY KEY,
               display_name TEXT,
               fingerprint TEXT NOT NULL,
               address TEXT NOT NULL,
               last_seen INTEGER NOT NULL,
               connected INTEGER NOT NULL DEFAULT 0,
               failure_count INTEGER NOT NULL DEFAULT 0,
               next_attempt INTEGER NOT NULL DEFAULT 0
             );
             CREATE TABLE IF NOT EXISTS messages (
               id TEXT PRIMARY KEY,
               direction TEXT NOT NULL CHECK(direction IN ('in','out')),
               peer_id TEXT NOT NULL,
               timestamp INTEGER NOT NULL,
               body TEXT NOT NULL,
               state TEXT NOT NULL,
               read INTEGER NOT NULL DEFAULT 1
             );
             CREATE INDEX IF NOT EXISTS messages_timestamp ON messages(timestamp DESC);
             CREATE INDEX IF NOT EXISTS messages_peer_timestamp ON messages(peer_id, timestamp);
             CREATE TABLE IF NOT EXISTS sites (
               site_id TEXT PRIMARY KEY,
               name TEXT NOT NULL,
               root TEXT NOT NULL,
               enabled INTEGER NOT NULL
             );
             CREATE TABLE IF NOT EXISTS contacts (
               peer_id TEXT PRIMARY KEY,
               alias TEXT,
               trust_state TEXT NOT NULL CHECK(trust_state IN ('unverified','trusted','blocked')),
               muted INTEGER NOT NULL DEFAULT 0,
               created_at INTEGER NOT NULL
             );
             CREATE TABLE IF NOT EXISTS mail_messages (
               id TEXT PRIMARY KEY,
               direction TEXT NOT NULL CHECK(direction IN ('in','out')),
               peer_id TEXT NOT NULL,
               sender TEXT NOT NULL,
               recipient TEXT NOT NULL,
               timestamp INTEGER NOT NULL,
               subject TEXT NOT NULL,
               body TEXT NOT NULL,
               state TEXT NOT NULL,
               read INTEGER NOT NULL DEFAULT 1
             );
             CREATE INDEX IF NOT EXISTS mail_timestamp ON mail_messages(timestamp DESC);
             CREATE INDEX IF NOT EXISTS mail_direction_timestamp ON mail_messages(direction, timestamp DESC);
             CREATE TABLE IF NOT EXISTS chat_groups (
               group_id TEXT PRIMARY KEY,
               name TEXT NOT NULL,
               creator_peer_id TEXT NOT NULL,
               created_at INTEGER NOT NULL,
               epoch INTEGER NOT NULL DEFAULT 1
             );
             CREATE TABLE IF NOT EXISTS group_members (
               group_id TEXT NOT NULL,
               peer_id TEXT NOT NULL,
               role TEXT NOT NULL CHECK(role IN ('owner','moderator','member')),
               membership_state TEXT NOT NULL CHECK(membership_state IN ('active','left','kicked','banned')),
               added_by TEXT NOT NULL,
               added_at INTEGER NOT NULL,
               PRIMARY KEY(group_id, peer_id),
               FOREIGN KEY(group_id) REFERENCES chat_groups(group_id) ON DELETE CASCADE
             );
             CREATE TABLE IF NOT EXISTS group_events (
               event_id TEXT PRIMARY KEY,
               group_id TEXT NOT NULL,
               sequence INTEGER NOT NULL,
               actor_peer_id TEXT NOT NULL,
               event_type TEXT NOT NULL,
               target_peer_id TEXT,
               created_at INTEGER NOT NULL,
               signature BLOB NOT NULL,
               UNIQUE(group_id, sequence),
               FOREIGN KEY(group_id) REFERENCES chat_groups(group_id) ON DELETE CASCADE
             );
             CREATE TABLE IF NOT EXISTS authority_events (
               event_id TEXT PRIMARY KEY,
               sequence INTEGER NOT NULL,
               scope TEXT NOT NULL,
               action TEXT NOT NULL,
               target TEXT NOT NULL,
               payload_json TEXT NOT NULL,
               signer_peer_id TEXT NOT NULL,
               issued_at INTEGER NOT NULL,
               signature BLOB NOT NULL,
               imported_at INTEGER NOT NULL,
               UNIQUE(scope, sequence)
             );
             CREATE INDEX IF NOT EXISTS authority_events_sequence
               ON authority_events(sequence);",
        )?;
        ensure_column(
            &connection,
            "peers",
            "failure_count",
            "INTEGER NOT NULL DEFAULT 0",
        )?;
        ensure_column(
            &connection,
            "messages",
            "read",
            "INTEGER NOT NULL DEFAULT 1",
        )?;
        ensure_column(
            &connection,
            "peers",
            "next_attempt",
            "INTEGER NOT NULL DEFAULT 0",
        )?;
        connection.execute("UPDATE peers SET connected=0", [])?;
        Ok(Self { connection })
    }

    pub fn record_peer(&self, peer: &PeerRecord) -> Result<(), StorageError> {
        self.connection.execute(
            "INSERT INTO peers(peer_id, display_name, fingerprint, address, last_seen, connected)
             VALUES(?1, ?2, ?3, ?4, ?5, ?6)
             ON CONFLICT(peer_id) DO UPDATE SET
               display_name=COALESCE(excluded.display_name, peers.display_name),
               fingerprint=excluded.fingerprint,
               address=CASE WHEN excluded.address='' THEN peers.address ELSE excluded.address END,
               last_seen=excluded.last_seen,
               connected=excluded.connected",
            params![
                peer.peer_id,
                peer.display_name,
                peer.fingerprint,
                peer.address,
                peer.last_seen,
                peer.connected
            ],
        )?;
        Ok(())
    }

    pub fn set_peer_connected(&self, peer_id: &str, connected: bool) -> Result<(), StorageError> {
        self.connection.execute(
            "UPDATE peers SET connected=?2,
               last_seen=CASE WHEN ?2=1 THEN ?3 ELSE last_seen END,
               failure_count=CASE WHEN ?2=1 THEN 0 ELSE failure_count END,
               next_attempt=CASE WHEN ?2=1 THEN 0 ELSE next_attempt END
             WHERE peer_id=?1",
            params![peer_id, connected, unix_timestamp()],
        )?;
        Ok(())
    }

    pub fn mark_dial_started(&self, peer_id: &str) -> Result<(), StorageError> {
        self.connection.execute(
            "UPDATE peers SET next_attempt=?2 WHERE peer_id=?1",
            params![peer_id, unix_timestamp() + 60],
        )?;
        Ok(())
    }

    pub fn mark_dial_failed(&self, peer_id: &str) -> Result<(), StorageError> {
        let previous = self
            .connection
            .query_row(
                "SELECT failure_count FROM peers WHERE peer_id=?1",
                [peer_id],
                |row| row.get::<_, i64>(0),
            )
            .optional()?
            .unwrap_or(0);
        let failures = previous.saturating_add(1);
        let exponent = u32::try_from((failures - 1).clamp(0, 8)).unwrap_or(8);
        let delay = (5_i64.saturating_mul(1_i64 << exponent)).min(1_800);
        self.connection.execute(
            "UPDATE peers SET connected=0, failure_count=?2, next_attempt=?3 WHERE peer_id=?1",
            params![peer_id, failures, unix_timestamp() + delay],
        )?;
        Ok(())
    }

    pub(crate) fn reconnect_candidates(
        &self,
        now: i64,
        limit: usize,
    ) -> Result<Vec<ReconnectCandidate>, StorageError> {
        let limit = i64::try_from(limit).unwrap_or(i64::MAX);
        let mut statement = self.connection.prepare(
            "SELECT p.peer_id, p.address FROM peers p
             LEFT JOIN contacts c ON c.peer_id=p.peer_id
             WHERE p.connected=0 AND p.address<>'' AND p.next_attempt<=?1
               AND COALESCE(c.trust_state, 'unverified')<>'blocked'
             ORDER BY p.last_seen DESC LIMIT ?2",
        )?;
        let rows = statement.query_map(params![now, limit], |row| {
            Ok(ReconnectCandidate {
                peer_id: row.get(0)?,
                address: row.get(1)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn peer_count(&self) -> Result<i64, StorageError> {
        self.connection
            .query_row("SELECT COUNT(*) FROM peers", [], |row| row.get(0))
            .map_err(Into::into)
    }

    pub fn can_accept_introduced_peer(&self) -> Result<bool, StorageError> {
        Ok(self.peer_count()? < MAX_KNOWN_PEERS)
    }

    pub fn peers(&self) -> Result<Vec<PeerRecord>, StorageError> {
        let mut statement = self.connection.prepare(
            "SELECT peer_id, display_name, fingerprint, address, last_seen, connected
             FROM peers ORDER BY connected DESC, last_seen DESC LIMIT 500",
        )?;
        let rows = statement.query_map([], |row| {
            Ok(PeerRecord {
                peer_id: row.get(0)?,
                display_name: row.get(1)?,
                fingerprint: row.get(2)?,
                address: row.get(3)?,
                last_seen: row.get(4)?,
                connected: row.get(5)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn insert_message(&self, message: &MessageRecord) -> Result<bool, StorageError> {
        let changed = self.connection.execute(
            "INSERT OR IGNORE INTO messages(id, direction, peer_id, timestamp, body, state, read)
             VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7)",
            params![
                message.id,
                message.direction,
                message.peer_id,
                message.timestamp,
                message.body,
                message.state,
                message.read
            ],
        )?;
        Ok(changed == 1)
    }

    pub fn set_message_state(&self, id: &str, state: &str) -> Result<(), StorageError> {
        self.connection.execute(
            "UPDATE messages SET state=?2 WHERE id=?1",
            params![id, state],
        )?;
        Ok(())
    }

    pub fn mark_conversation_read(&self, peer_id: &str) -> Result<usize, StorageError> {
        self.connection
            .execute(
                "UPDATE messages SET read=1 WHERE peer_id=?1 AND direction='in' AND read=0",
                [peer_id],
            )
            .map_err(Into::into)
    }

    pub fn message(&self, id: &str) -> Result<Option<MessageRecord>, StorageError> {
        self.connection
            .query_row(
                "SELECT id, direction, peer_id, timestamp, body, state, read FROM messages WHERE id=?1",
                [id],
                |row| {
                    Ok(MessageRecord {
                        id: row.get(0)?,
                        direction: row.get(1)?,
                        peer_id: row.get(2)?,
                        timestamp: row.get(3)?,
                        body: row.get(4)?,
                        state: row.get(5)?,
                        read: row.get(6)?,
                    })
                },
            )
            .optional()
            .map_err(Into::into)
    }

    pub fn messages(&self) -> Result<Vec<MessageRecord>, StorageError> {
        let mut statement = self.connection.prepare(
            "SELECT id, direction, peer_id, timestamp, body, state, read
             FROM messages ORDER BY timestamp DESC LIMIT 500",
        )?;
        let rows = statement.query_map([], |row| {
            Ok(MessageRecord {
                id: row.get(0)?,
                direction: row.get(1)?,
                peer_id: row.get(2)?,
                timestamp: row.get(3)?,
                body: row.get(4)?,
                state: row.get(5)?,
                read: row.get(6)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn insert_mail(&self, message: &MailRecord) -> Result<bool, StorageError> {
        let changed = self.connection.execute(
            "INSERT OR IGNORE INTO mail_messages(
               id, direction, peer_id, sender, recipient, timestamp, subject, body, state, read
             ) VALUES(?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10)",
            params![
                message.id,
                message.direction,
                message.peer_id,
                message.sender,
                message.recipient,
                message.timestamp,
                message.subject,
                message.body,
                message.state,
                message.read,
            ],
        )?;
        Ok(changed == 1)
    }

    pub fn set_mail_state(&self, id: &str, state: &str) -> Result<(), StorageError> {
        self.connection.execute(
            "UPDATE mail_messages SET state=?2 WHERE id=?1 AND direction='out'",
            params![id, state],
        )?;
        Ok(())
    }

    pub fn mark_mail_read(&self, id: &str) -> Result<usize, StorageError> {
        self.connection
            .execute(
                "UPDATE mail_messages SET read=1 WHERE id=?1 AND direction='in'",
                [id],
            )
            .map_err(Into::into)
    }

    pub fn mail_messages(&self) -> Result<Vec<MailRecord>, StorageError> {
        let mut statement = self.connection.prepare(
            "SELECT id, direction, peer_id, sender, recipient, timestamp, subject, body, state, read
             FROM mail_messages ORDER BY timestamp DESC, id DESC LIMIT 500",
        )?;
        let rows = statement.query_map([], |row| {
            Ok(MailRecord {
                id: row.get(0)?,
                direction: row.get(1)?,
                peer_id: row.get(2)?,
                sender: row.get(3)?,
                recipient: row.get(4)?,
                timestamp: row.get(5)?,
                subject: row.get(6)?,
                body: row.get(7)?,
                state: row.get(8)?,
                read: row.get(9)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub(crate) fn queued_mail(&self, limit: usize) -> Result<Vec<MailRecord>, StorageError> {
        let limit = i64::try_from(limit).unwrap_or(i64::MAX);
        let mut statement = self.connection.prepare(
            "SELECT id, direction, peer_id, sender, recipient, timestamp, subject, body, state, read
             FROM mail_messages WHERE direction='out' AND state='queued'
             ORDER BY timestamp LIMIT ?1",
        )?;
        let rows = statement.query_map([limit], |row| {
            Ok(MailRecord {
                id: row.get(0)?,
                direction: row.get(1)?,
                peer_id: row.get(2)?,
                sender: row.get(3)?,
                recipient: row.get(4)?,
                timestamp: row.get(5)?,
                subject: row.get(6)?,
                body: row.get(7)?,
                state: row.get(8)?,
                read: row.get(9)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn upsert_site(&self, site: &SiteConfig) -> Result<(), StorageError> {
        self.connection.execute(
            "INSERT INTO sites(site_id, name, root, enabled) VALUES(?1, ?2, ?3, ?4)
             ON CONFLICT(site_id) DO UPDATE SET name=excluded.name, root=excluded.root, enabled=excluded.enabled",
            params![site.site_id, site.name, site.root, site.enabled],
        )?;
        Ok(())
    }

    pub fn set_site_root(&self, site_id: &str, root: &str) -> Result<(), StorageError> {
        self.connection.execute(
            "UPDATE sites SET root=?2 WHERE site_id=?1",
            params![site_id, root],
        )?;
        Ok(())
    }

    pub fn upsert_contact(&self, contact: &ContactRecord) -> Result<(), StorageError> {
        if !matches!(
            contact.trust_state.as_str(),
            "unverified" | "trusted" | "blocked"
        ) {
            return Err(StorageError::Invalid("unknown contact trust state".into()));
        }
        if contact
            .alias
            .as_ref()
            .is_some_and(|alias| alias.chars().count() > 80 || alias.chars().any(char::is_control))
        {
            return Err(StorageError::Invalid("contact alias is invalid".into()));
        }
        self.connection.execute(
            "INSERT INTO contacts(peer_id, alias, trust_state, muted, created_at)
             VALUES(?1, ?2, ?3, ?4, ?5)
             ON CONFLICT(peer_id) DO UPDATE SET
               alias=excluded.alias,
               trust_state=excluded.trust_state,
               muted=excluded.muted",
            params![
                contact.peer_id,
                contact.alias,
                contact.trust_state,
                contact.muted,
                contact.created_at
            ],
        )?;
        Ok(())
    }

    pub fn contacts(&self) -> Result<Vec<ContactRecord>, StorageError> {
        let mut statement = self.connection.prepare(
            "SELECT peer_id, alias, trust_state, muted, created_at
             FROM contacts ORDER BY COALESCE(alias, peer_id)",
        )?;
        let rows = statement.query_map([], |row| {
            Ok(ContactRecord {
                peer_id: row.get(0)?,
                alias: row.get(1)?,
                trust_state: row.get(2)?,
                muted: row.get(3)?,
                created_at: row.get(4)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }

    pub fn is_blocked(&self, peer_id: &str) -> Result<bool, StorageError> {
        let state = self
            .connection
            .query_row(
                "SELECT trust_state FROM contacts WHERE peer_id=?1",
                [peer_id],
                |row| row.get::<_, String>(0),
            )
            .optional()?;
        Ok(state.as_deref() == Some("blocked"))
    }

    pub fn sites(&self) -> Result<Vec<SiteConfig>, StorageError> {
        let mut statement = self
            .connection
            .prepare("SELECT site_id, name, root, enabled FROM sites ORDER BY name")?;
        let rows = statement.query_map([], |row| {
            Ok(SiteConfig {
                site_id: row.get(0)?,
                name: row.get(1)?,
                root: row.get(2)?,
                enabled: row.get(3)?,
            })
        })?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }
    pub fn insert_authority_event(
        &self,
        event: &AuthorityAuditRecord,
    ) -> Result<bool, StorageError> {
        if event.scope.is_empty()
            || event.scope.len() > 64
            || event.action.is_empty()
            || event.action.len() > 64
            || event.target.len() > 512
            || event.payload_json.len() > 64 * 1024
            || event.signature.is_empty()
            || event.signature.len() > 16 * 1024
        {
            return Err(StorageError::Invalid(
                "authority event is outside its bounds".into(),
            ));
        }
        self.connection
            .execute(
                "INSERT OR IGNORE INTO authority_events
                   (event_id,sequence,scope,action,target,payload_json,signer_peer_id,issued_at,signature,imported_at)
                 VALUES (?1,?2,?3,?4,?5,?6,?7,?8,?9,?10)",
                params![
                    event.event_id,
                    event.sequence,
                    event.scope,
                    event.action,
                    event.target,
                    event.payload_json,
                    event.signer_peer_id,
                    event.issued_at,
                    event.signature,
                    event.imported_at,
                ],
            )
            .map(|rows| rows > 0)
            .map_err(Into::into)
    }

    pub fn authority_events(
        &self,
        after_sequence: i64,
        limit: u16,
    ) -> Result<Vec<AuthorityAuditRecord>, StorageError> {
        let mut statement = self.connection.prepare(
            "SELECT event_id,sequence,scope,action,target,payload_json,signer_peer_id,issued_at,signature,imported_at
             FROM authority_events WHERE sequence > ?1 ORDER BY sequence LIMIT ?2",
        )?;
        let rows = statement.query_map(
            params![after_sequence, i64::from(limit.clamp(1, 256))],
            |row| {
                Ok(AuthorityAuditRecord {
                    event_id: row.get(0)?,
                    sequence: row.get(1)?,
                    scope: row.get(2)?,
                    action: row.get(3)?,
                    target: row.get(4)?,
                    payload_json: row.get(5)?,
                    signer_peer_id: row.get(6)?,
                    issued_at: row.get(7)?,
                    signature: row.get(8)?,
                    imported_at: row.get(9)?,
                })
            },
        )?;
        rows.collect::<Result<Vec<_>, _>>().map_err(Into::into)
    }
}

fn ensure_column(
    connection: &Connection,
    table: &str,
    column: &str,
    declaration: &str,
) -> Result<(), StorageError> {
    let mut statement = connection.prepare(&format!("PRAGMA table_info({table})"))?;
    let columns = statement
        .query_map([], |row| row.get::<_, String>(1))?
        .collect::<Result<Vec<_>, _>>()?;
    if !columns.iter().any(|existing| existing == column) {
        connection.execute(
            &format!("ALTER TABLE {table} ADD COLUMN {column} {declaration}"),
            [],
        )?;
    }
    Ok(())
}

pub fn unix_timestamp() -> i64 {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs() as i64
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn message_ids_are_deduplicated() {
        let dir = tempfile::tempdir().unwrap();
        let storage = Storage::open(&dir.path().join("freedom.db")).unwrap();
        let message = MessageRecord {
            id: "same-id".into(),
            direction: "in".into(),
            peer_id: "peer".into(),
            timestamp: 1,
            body: "hello".into(),
            state: "received".into(),
            read: false,
        };
        assert!(storage.insert_message(&message).unwrap());
        assert!(!storage.insert_message(&message).unwrap());
        assert_eq!(storage.messages().unwrap().len(), 1);
        assert!(!storage.message("same-id").unwrap().unwrap().read);
        assert_eq!(storage.mark_conversation_read("peer").unwrap(), 1);
        assert!(storage.message("same-id").unwrap().unwrap().read);
        assert_eq!(storage.mark_conversation_read("peer").unwrap(), 0);
    }

    #[test]
    fn mail_is_persistent_deduplicated_and_marked_read() {
        let dir = tempfile::tempdir().unwrap();
        let storage = Storage::open(&dir.path().join("freedom.db")).unwrap();
        let message = MailRecord {
            id: "mail-id".into(),
            direction: "in".into(),
            peer_id: "peer".into(),
            sender: "sender@freedom.net".into(),
            recipient: "recipient@freedom.net".into(),
            timestamp: 1,
            subject: "Hello".into(),
            body: "Persistent mail".into(),
            state: "received".into(),
            read: false,
        };
        assert!(storage.insert_mail(&message).unwrap());
        assert!(!storage.insert_mail(&message).unwrap());
        assert_eq!(storage.mail_messages().unwrap().len(), 1);
        assert_eq!(storage.mark_mail_read("mail-id").unwrap(), 1);
        assert!(storage.mail_messages().unwrap()[0].read);
    }

    #[test]
    fn sites_survive_reopen() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("freedom.db");
        {
            let storage = Storage::open(&path).unwrap();
            storage
                .upsert_site(&SiteConfig {
                    site_id: "home".into(),
                    name: "Home".into(),
                    root: "C:\\sites\\home".into(),
                    enabled: true,
                })
                .unwrap();
        }
        assert_eq!(Storage::open(&path).unwrap().sites().unwrap().len(), 1);
    }

    #[test]
    fn stale_connections_are_reset_and_failures_back_off() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("freedom.db");
        let peer = PeerRecord {
            peer_id: "peer-a".into(),
            display_name: None,
            fingerprint: "ABC-DEF".into(),
            address: "/ip4/127.0.0.1/tcp/42100".into(),
            last_seen: 10,
            connected: true,
        };
        {
            let storage = Storage::open(&path).unwrap();
            storage.record_peer(&peer).unwrap();
            storage.mark_dial_failed("peer-a").unwrap();
            assert!(
                storage
                    .reconnect_candidates(unix_timestamp(), 10)
                    .unwrap()
                    .is_empty()
            );
        }
        let reopened = Storage::open(&path).unwrap();
        assert!(!reopened.peers().unwrap()[0].connected);
    }

    #[test]
    fn blocked_contacts_are_persistent_and_not_reconnect_candidates() {
        let dir = tempfile::tempdir().unwrap();
        let storage = Storage::open(&dir.path().join("freedom.db")).unwrap();
        storage
            .record_peer(&PeerRecord {
                peer_id: "peer-a".into(),
                display_name: None,
                fingerprint: "ABC-DEF".into(),
                address: "/ip4/127.0.0.1/tcp/42100".into(),
                last_seen: 10,
                connected: false,
            })
            .unwrap();
        storage
            .upsert_contact(&ContactRecord {
                peer_id: "peer-a".into(),
                alias: Some("Alice".into()),
                trust_state: "blocked".into(),
                muted: true,
                created_at: unix_timestamp(),
            })
            .unwrap();
        assert!(storage.is_blocked("peer-a").unwrap());
        assert!(
            storage
                .reconnect_candidates(i64::MAX, 10)
                .unwrap()
                .is_empty()
        );
        assert_eq!(
            storage.contacts().unwrap()[0].alias.as_deref(),
            Some("Alice")
        );
    }

    #[test]
    fn older_peer_schema_is_migrated_in_place() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("freedom.db");
        {
            let connection = Connection::open(&path).unwrap();
            connection
                .execute_batch(
                    "CREATE TABLE peers (
                       peer_id TEXT PRIMARY KEY,
                       display_name TEXT,
                       fingerprint TEXT NOT NULL,
                       address TEXT NOT NULL,
                       last_seen INTEGER NOT NULL,
                       connected INTEGER NOT NULL DEFAULT 0
                     );",
                )
                .unwrap();
        }
        let storage = Storage::open(&path).unwrap();
        let columns = storage
            .connection
            .prepare("PRAGMA table_info(peers)")
            .unwrap()
            .query_map([], |row| row.get::<_, String>(1))
            .unwrap()
            .collect::<Result<Vec<_>, _>>()
            .unwrap();
        assert!(columns.iter().any(|column| column == "failure_count"));
        assert!(columns.iter().any(|column| column == "next_attempt"));
    }
}
