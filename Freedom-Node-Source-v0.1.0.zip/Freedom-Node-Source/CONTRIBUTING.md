# Contributing

This repository contains the public Freedom Node. Owner-only Authority assets, keys and administration tooling are intentionally outside its supported build.

Before proposing a change:

1. Keep protocol inputs bounded and fail closed on malformed data.
2. Never add private keys, credentials, databases, logs, AppData, WebView profiles or live website data.
3. Do not weaken signed-name verification, PeerID matching, site-root containment, loopback capability checks or protected-file denial.
4. Do not describe Freedom as anonymous, untraceable or impossible to block.
5. Run formatting, tests and clippy before submitting a pull request.

```powershell
.\tools\cargo.ps1 fmt --all -- --check
.\tools\cargo.ps1 test --workspace
.\tools\cargo.ps1 clippy --workspace --all-targets
```

Security reports must follow [SECURITY.md](SECURITY.md), not a public exploit disclosure.

Unless explicitly agreed otherwise in writing, contributions submitted to this repository are offered under the same `AGPL-3.0-only` licence that covers Freedom Node. Contributors must have the right to submit their work and must preserve applicable third-party notices.
